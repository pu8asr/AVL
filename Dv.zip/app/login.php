<?php
	header("Content-Type: text/html;  charset=ISO-8859-1", true);
?>

<!DOCTYPE HTML>
<!--
	Ion by TEMPLATED
	templated.co @templatedco
	Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
-->

<!-- Permitir somente a entrada de n�meros -->
<script language='JavaScript'>
function SomenteNumero(e){
    var tecla=(window.event)?event.keyCode:e.which;   
    if((tecla>47 && tecla<58)) return true;
    else{
    	if (tecla==8 || tecla==0) return true;
	else  return false;
    }
}
</script>

<html>
	<head>
		<title>Divulgador Alain Cruz 2020</title>
		<!--
			CODIFICA��O UTF-8 permite conte�do com acentua��o
		-->
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="author" content="Airam - airamcosta@gmail.com" />
		<meta name="description" content="Divulgador de campanha Alain Cruz para prefeito de Iranduba 2020" />
		<meta name="keywords" content="Alain, Alain Cruz, Cruz, Thiago, Thiago Allende, Allende" />
		<!--[if lte IE 8]><script src="js/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<link rel="stylesheet" type="text/css" href="css/system.css" />
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
			<link rel="stylesheet" type="text/css" href="css/system.css" />
		</noscript>		
	</head>
	<body id="top">

		<!-- One -->
			<section id="one" class="wrapper style1">
				<header class="major">
					<center>
					<h3>Divulgador Alain Cruz 2020</h3>
						<form class="form" action="valida_login.php" method="post">
							<fieldset>
								<legend>Informe seus dados de acesso</legend></br>
									<label>Whatsapp (com DDD): 
										<input type="text" name="telefone" id="txTelefone" class="entrada" maxlength="11" placeholder="Digite seu whatsapp aqui" onkeypress="return SomenteNumero(event)" required autofocus/>
									</label>
									<label>Senha: 
										<input type="password" name="senha" id="txSenha" class="entrada" maxlength="40" placeholder="******" required />
									</label>
			
								<!-- Bot�o -->
								<center>
									<input type="submit" class="submit" value="ENTRAR"/>
								</center>
								<p align="center"></br>
									<a href="password_recovery.php" target="_self" class="link">Esqueceu a senha?</a>
								</p>
								<!--<center><h4><font color="blue"><a href='http://pu8asr.ddns.net:1080/portal.html' target='_blank'><strong>Powered By WebServer Raspberry Pi B+</strong></a></font></h4></center>-->
						</form>
					</center>
				</header>
			</section>			
			
		<!-- Footer -->
			<footer id="footer">
				<div class="container">					
					<ul class="copyright">
						<li>Alain Cruz&copy; <?php echo $data = date("Y"); ?>.</br>Todos os direitos reservados.</li>
					</ul>
				</div>
			</footer>

	</body>
</html>