<?php

header("Content-Type: text/html;  charset=UFT-8", true);

// A sessão precisa ser iniciada em cada página diferente
if (!isset($_SESSION)) session_start();

$nivel_necessario = 1;

// Verifica se não há a variável da sessão que identifica o usuário
if (!isset($_SESSION['UsuarioID']) OR ($_SESSION['UsuarioNivel'] < $nivel_necessario)) {
	// Destrói a sessão por segurança
	session_destroy();
	// Redireciona o visitante de volta pro login
	header("Location: login.php"); exit;
}

?>

<!DOCTYPE HTML>
<!--
	Ion by TEMPLATED
	templated.co @templatedco
	Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
-->

<!-- Permitir somente a entrada de números -->
<script language='JavaScript'>
function SomenteNumero(e){
    var tecla=(window.event)?event.keyCode:e.which;   
    if((tecla>47 && tecla<58)) return true;
    else{
    	if (tecla==8 || tecla==0) return true;
	else  return false;
    }
}
</script>

<html>
	<head>
		<title>Divulgador Alain Cruz 2020</title>
		<!--
			CODIFICAÇÃO UTF-8 permite conteúdo com acentuação
		-->
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="author" content="Airam - airamcosta@gmail.com" />
		<meta name="description" content="Divulgador de campanha Alain Cruz para prefeito de Iranduba 2020" />
		<meta name="keywords" content="Alain, Alain Cruz, Cruz, Thiago, Thiago Allende, Allende" />
		<!--[if lte IE 8]><script src="js/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<link rel="stylesheet" type="text/css" href="css/system.css" />
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
			<link rel="stylesheet" type="text/css" href="css/system.css" />
		</noscript>		
	</head>
	<body id="top">

		<!-- Menu -->
			<header id="header" class="skel-layers-fixed">
				<h1><a href="#">Divulgador Alain Cruz 2020</a></h1>
				<nav id="nav">
					<ul>
						<li><a href="logout.php" target="principal" class="button special">Sair do sistema</a></li>
					</ul>
				</nav>
			</header>
			
		<!-- Body -->
			<font color="Black">

		<h2></h2>
		
				<header class="major">
					<center>
					<h3>Cadastro de contatos para divulgação</h3>
						<form class="form" action="registra_contato.php" method="post">
							<fieldset>
								<legend>Informe os dados do contato</legend></br>
									<label>Nome: 
										<input type="text" name="nome" id="txNome" class="entrada" maxlength="30" placeholder="Digite o nome do contato aqui" required autofocus />
									</label>
									<label>Whatsapp (com DDD): 
										<input type="text" name="telefone" id="txTelefone" class="entrada" maxlength="11" placeholder="Digite o whatsapp do contato aqui" onkeypress="return SomenteNumero(event)" required />
									</label>
			
								<!-- Botão -->
								<center>
									<input type="submit" class="submit" value="REGISTRAR"/>
								</center>
						</form>
						
						<?php
						
							// Parâmetros de conexão ao banco de dados
							$server = "localhost";
							$username = "alaincruz";
							$PW = "Alain2020";
							$DB = "alaincruz";
	
							// Realiza a conexão com o banco de dados
							$connection = mysqli_connect($server, $username, $PW, $DB);
							//mysqli_set_charset('UTF8');
							
							// Verifica se a conexão foi bem-sucedida para obter a agenda do usuário
							if($connection == false) {
								//die("Erro: " . mysqli_connect_error());
								die("Banco de Dados inacessível.</br>
								Por favor, notifique o suporte!</br>
								Whatsapp: <a href='https://api.whatsapp.com/send?phone=5592994243062&text=O%20*Divulgador*%20*Alain*%20não%20conseguiu%20exibir%20minha%20agenda%20pois%20o%20Banco%20de%20Dados%20está%20inoperante.'>+5592994240362</a>");
								//echo"<script language='javascript' type='text/javascript'>alert('Ocorreu um erro na conexão com o servidor. Tente novamente mais tarde!');window.location.href='index.php';</script>";
							} else {
								//Verifica se o usuário possui agenda
								$sqlAgendaUser = "SELECT * FROM `contacts` WHERE (`usuario` = '".$_SESSION['UsuarioID']."') ORDER BY `nome` ASC";
								if(mysqli_query($connection, $sqlAgendaUser) == false) {
									die("Não foi possível obter sua agenda de contatos.</br>
									Por favor, notifique o suporte!</br>
									Whatsapp: <a href='https://api.whatsapp.com/send?phone=5592994243062&text=O%20*Divulgador*%20*Alain*%20não%20conseguiu%20exibir%20minha%20agenda%20de%20contatos.'>+5592994240362</a>");
								} else {
									// Verifica se o usuário possui contatos
									$quantRegistros = mysqli_num_rows(mysqli_query($connection, $sqlAgendaUser));
									if($quantRegistros != 0) {
										//Caso possui contatos
										echo "Você possui '$quantRegistros' contatos na sua agenda.</br>";
										echo "<table><tr><td><strong>Nome</strong></td><td><strong>Whatsapp</strong></td></tr>";
										while($linha = mysqli_fetch_assoc(mysqli_query($connection, $sqlAgendaUser))){
											echo '<tr><td>' . $linha['nome'] . '</td><td>' . $linha['telefone'] . '</td></tr>';
										}
										echo "</table>";
									} else {
										//Caso não possua contatos
										die("Sua agenda de contatos está vazia.</br>
										Seus contatos aparecerão aqui quando você os cadastrar...");
									}
								}
								// Encerra a conexão com o banco de dados
								mysqli_close($connection);
							}
						
						?>
		
					</center>
				</header>
		
		<center>
		
		</center>
		</font>

	</body>
</html>