<?php

	//Problemas de acentua��o, obedecendo ao padr�o UTF-8 de todo o sistema
	//header('Content-Type: text/html;  charset=utf-8', true);
	header('Content-Type: text/html;  charset=ISO-8859-1', true);

	/* Ativa a exibi��o de erros na p�gina */
	/* Ativar apenas para testes pois pode exibir dados sigilosos que o usu�rio n�o pode ter acesso */
	//error_reporting(E_ALL);
	//ini_set('display_errors', 1);
	/* Ativa a exibi��o de erros na p�gina */

	// Define data e hora da atividade no fuso hor�rio brasileiro
	date_default_timezone_set('America/Manaus');
	$SystemDateTime = date('Y-m-d H:i:s');
	$ano = date('Y');
	
	// Verifica se houve post (Impedir o acesso direto)
	if (!empty($_POST) AND (empty($_POST['telefone']) OR empty($_POST['senha']))) {
		echo"<script language='javascript' type='text/javascript'>alert('Informe todos os dados de login!');window.location.href='http://divulgadoralain.ddns.net';</script>";
	}
	
	// Par�metro recebido do formul�rio na p�gina principal
	$telefone = utf8_encode($_POST['telefone']);
	$senha = utf8_encode($_POST['senha']);
	
	// Par�metros de conex�o ao banco de dados
	$server = "localhost";
	$username = "alaincruz";
	$PW = "Alain2020";
	$DB = "alaincruz";
	
	// Realiza a conex�o com o banco de dados
	$connection = mysqli_connect($server, $username, $PW, $DB);
	//mysqli_set_charset('UTF8');
	
	// Verifica se a conex�o foi bem-sucedida
	if($connection == false) {
		//die("Erro: " . mysqli_connect_error());
		die("Banco de Dados inacess�vel.</br></br>
		Por favor, notifique o suporte!</br>
		Whatsapp: <a href='https://api.whatsapp.com/send?phone=5592994243062&text=Tentei%20acessar%20o%20Divulgador%20Alain%20mas%20o%20Banco%20de%20Dados%20est�%20inoperante.'>+5592994240362</a></br>
		<a href='http://divulgadoralain.ddns.net'>Clique aqui para voltar para o site</a>");
		//echo"<script language='javascript' type='text/javascript'>alert('Ocorreu um erro na conex�o com o servidor. Tente novamente mais tarde!');window.location.href='index.php';</script>";
	} else {
		//Valida��o do login
		$sqlSearch = "SELECT * FROM `users` WHERE (`telefone` = '$telefone') LIMIT 1";
		if(mysqli_query($connection, $sqlSearch) == false) {
			die("N�o foi poss�vel validar o login.</br></br>
			Por favor, notifique o suporte!</br>
			Whatsapp: <a href='https://api.whatsapp.com/send?phone=5592994243062&text=Tentei%20acessar%20o%20*Divulgador*%20*Alain*%20mas%20os%20login%20n�o%20pode%20ser%20validado.'>+5592994240362</a></br></br>
			<a href='http://divulgadoralain.ddns.net'>Clique aqui para voltar para o site</a>");
		} else {
			// Verifica se o telefone j� foi adastrado
			$quantRegistros = mysqli_num_rows(mysqli_query($connection, $sqlSearch));
			if($quantRegistros != 0) {

				// Verifica��es se o cadastro foi ativado
				// Salva os dados encontados na vari�vel $status
				$result = mysqli_fetch_assoc(mysqli_query($connection, $sqlSearch));
				$actived = $result['ativo'];
				$pass = $result['senha'];

				if($actived == 0) {
					die("O cadastro ainda n�o foi aprovado.</br></br>
					Por favor, notifique o suporte!</br>
					Whatsapp: <a href='https://api.whatsapp.com/send?phone=5592994243062&text=Preciso%20que%20meu%20cadastro%20seja%20aprovado%20para%20acessar%20o%20*Divulgador*%20*Alain*.'>+5592994240362</a></br></br>
					<a href='http://divulgadoralain.ddns.net'>Clique aqui para voltar para o site</a>");
				}
				
				if($actived == 1) {
					//Valida��o da senha
					if($senha == $pass) {
						// Se a sess�o n�o existir, inicia uma
						if (!isset($_SESSION)) session_start();

						// Salva os dados encontrados na sess�o
						$_SESSION['UsuarioID'] = $result['id'];
						$_SESSION['UsuarioNome'] = $result['nome'];
						$_SESSION['UsuarioTelefone'] = $result['telefone'];
						$_SESSION['UsuarioNivel'] = $result['nivel'];
						$user = $_SESSION['UsuarioID'];
						
						// Redireciona o visitante
						header("Location: manager.php"); exit;
	
					} else {
						echo"<script language='javascript' type='text/javascript'>alert('A senha n�o confere. Tente novamente!');window.location.href='login.php';</script>";
					}
					
				}
			} else {
				die("O telefone n�o consta no Banco de Dados.</br></br>
				<a href='http://divulgadoralain.ddns.net'>Clique aqui para voltar para o site</a>");
			}
		}
		// Encerra a conex�o com o banco de dados
		mysqli_close($connection);
	}

?>