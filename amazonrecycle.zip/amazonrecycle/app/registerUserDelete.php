<?php

	//Problemas de acentuação, obedecendo ao padrão UTF-8 de todo o sistema
	header('Content-Type: text/html;  charset=utf-8', true);

	/* Ativa a exibição de erros na página */
	/* Ativar apenas para testes pois pode exibir dados sigilosos que o usuário não pode ter acesso */
	//error_reporting(E_ALL);
	//ini_set('display_errors', 1);
	/* Ativa a exibição de erros na página */

	// Define data e hora da atividade no fuso horário brasileiro
	date_default_timezone_set('America/Sao_Paulo');
	$SystemDateTime = date('Y-m-d H:i:s');
	$ano = date('Y');
	
	// Verifica se houve post (Impedir o acesso direto ao newsletterRegisterDelete.php)
	if (!empty($_POST) AND (empty($_POST['code']))) {
		echo"<script language='javascript' type='text/javascript'>alert('Nenhum dado foi informado!');window.location.href='/index.php';</script>";
	}
	
	// Parâmetro recebido do formulário na página principal
	$Deleta = $_REQUEST['code'];
	
	// Parâmetros de conexão ao banco de dados
	$server = "localhost";
	$username = "3ch0n0m1z4r";
	$PW = "HaY23Zh4QBgN8v42";
	$DB = "3ch0n0m1z4r";

	// Realiza a conexão com o banco de dados
	$connection = mysqli_connect($server, $username, $PW, $DB);
	mysqli_set_charset('UTF8');

	// Verifica se a conexão foi bem-sucedida
	if($connection == false) {
		//die("Erro: " . mysqli_connect_error());
		die("Erro de conexão com o servidor.</br></br>
		Por favor, notifique o suporte!</br>
		Whatsapp: <a href='https://api.whatsapp.com/send?phone=5592994243062&text=Tentei%20excluir%20meu%20cadastro%20do%20sistema%20*Economize*%20mas%20o%20servidor%20apresentou%20um%20erro%20de%20conex&o%20com%20o%20Banco%20de%20Dados...'>+5592994240362</a></br>
		E-mail: <a href='mailto:economize.suporte@gmail.com?subject=Reportando%20erro%20no%20sistema&body=Tentei%20excluir%20meu%20cadastro%20do%20sistema%20Economize%20mas%20o%20servidor%20apresentou%20um%20erro%20de%20conex&o%20com%20o%20Banco%20de%20Dados...'>economize.suporte@gmail.com</a></br></br>
		<a href='http://economize.net.br'>Clique aqui para voltar para o site</a>");
		//echo"<script language='javascript' type='text/javascript'>alert('Ocorreu um erro na conexão com o servidor. Tente novamente mais tarde!');window.location.href='index.php';</script>";
	} else {
		echo "Conectado ao Banco de Dados.</br>";
		// Verifica se o e-mail consta na base de dados
		$sqlSearch = "SELECT * FROM `users` WHERE (`unique_id` = '$Deleta') LIMIT 1";
		if(mysqli_query($connection, $sqlSearch) == false) {
			//echo "Não foi possível validar o e-mail informado.</br>";
			die("Não foi possível excluir a conta.</br></br>
			Por favor, notifique o suporte!</br>
			Whatsapp: <a href='https://api.whatsapp.com/send?phone=5592994243062&text=Tentei%20excluir%20meu%20cadastro%20do%20sistema%20*Economize*%20com%20o%20link%20que%20recebi%20mas%20ocorreu%20um%20erro%20ao%20localizar%20a%20conta.'>+5592994240362</a></br>
			E-mail: <a href='mailto:economize.suporte@gmail.com?subject=Reportando%20erro%20no%20sistema&body=Tentei%20excluir%20meu%20cadastro%20do%20sistema%20Economize%20com%20o%20link%20que%20recebi%20mas%20ocorreu%20um%20erro%20ao%20localizar%20a%20conta.'>economize.suporte@gmail.com</a></br></br>
			<a href='http://economize.net.br'>Clique aqui para voltar para o site</a>");
		} else {
			$resultSearch = mysqli_num_rows(mysqli_query($connection, $sqlSearch));
			if($resultSearch != 0) {
				echo "A conta foi localizada.</br>";
				// Valida o cadastro
				$sqlDelete = "DELETE FROM `users` WHERE `unique_id` = '$Deleta'";
				if(mysqli_query($connection, $sqlDelete) == false) {
					//echo "Não foi possível validar o e-mail informado.</br>";
					die("Não foi possível excluir a conta.</br></br>
					Por favor, notifique o suporte!</br>
					Whatsapp: <a href='https://api.whatsapp.com/send?phone=5592994243062&text=Tentei%20excluir%20meu%20cadastro%20do%20sistema%20*Economize*%20com%20o%20link%20que%20recebi%20mas%20ocorreu%20um%20erro%20ao%20apagar%20o%20registro.'>+5592994240362</a></br>
					E-mail: <a href='mailto:economize.suporte@gmail.com?subject=Reportando%20erro%20no%20sistema&body=Tentei%20excluir%20meu%20cadastro%20do%20sistema%20Economize%20com%20o%20link%20que%20recebi%20mas%20ocorreu%20um%20erro%20ao%20apagar%20o%20registro.'>economize.suporte@gmail.com</a></br></br>
					<a href='http://economize.net.br'>Clique aqui para voltar para o site</a>");
				} else {
					echo "A conta foi excluída.</br>";
					echo"<script language='javascript' type='text/javascript'>alert('Seu cadastro foi removido do sistema com sucesso!');window.location.href='/index.php';</script>";
				}					
			} else {
				echo "A conta não foi localizada.</br>";
				echo"<script language='javascript' type='text/javascript'>alert('A conta não foi localizada no sistema.');window.location.href='/index.php';</script>";
			}
		}

		// Encerra a conexão com o banco de dados
		mysqli_close($connection);
	}

?>