-- phpMyAdmin SQL Dump
-- version 4.2.12deb2+deb8u2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 12-Jul-2017 às 16:43
-- Versão do servidor: 5.5.54-0+deb8u1
-- PHP Version: 5.6.30-0+deb8u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `eletromix`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `pedidos`
--

CREATE TABLE IF NOT EXISTS `pedidos` (
`id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `local` varchar(100) NOT NULL,
  `musica` varchar(50) NOT NULL,
  `artista` varchar(100) NOT NULL,
  `dedicatoria` varchar(100) NOT NULL,
  `played` tinyint(1) NOT NULL DEFAULT '0',
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='Armazenas os pedidos de músicas dos ouvintes';

--
-- Extraindo dados da tabela `pedidos`
--

INSERT INTO `pedidos` (`id`, `nome`, `local`, `musica`, `artista`, `dedicatoria`, `played`, `data`) VALUES
(1, 'Ellen costa', 'manaus', 'what what me', 'jason Derullo', 'airam Ripardo', 0, '2017-07-12 17:42:33');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int(11) unsigned NOT NULL,
  `nome` varchar(50) NOT NULL,
  `usuario` varchar(50) NOT NULL COMMENT 'CPF ou CNPJ (somente números)',
  `senha` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `nivel` int(1) unsigned NOT NULL DEFAULT '1' COMMENT '1 - Usuário | 2 - Operador | 3 - Administrador | 4 - Proprietário',
  `ativo` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1 - Ativo | 0 - Inativo',
  `cadastro` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ultimo_login` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `usuario`, `senha`, `email`, `nivel`, `ativo`, `cadastro`, `ultimo_login`) VALUES
(1, 'Airam Saile', 'ripardo', '2d998b1a4ef4121597b39cf47e42e0679777e927', 'airamcosta@gmail.com', 4, 1, '2017-06-27 19:47:02', '2017-07-10 08:38:21'),
(1, 'Cristiano', 'Ferraz', '9048ead9080d9b27d6b2b6ed363cbf8cce795f7f', 'fabricadepublicidade@hotmail.com', 1, 1, '2017-06-27 19:47:02', '2017-07-10 08:38:21');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pedidos`
--
ALTER TABLE `pedidos`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pedidos`
--
ALTER TABLE `pedidos`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
