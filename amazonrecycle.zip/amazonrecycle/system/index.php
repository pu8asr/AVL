<!DOCTYPE html>
<html lang="pt-BR">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="KurupyraTech" />
	<meta name="description" content="Amazon Recycle é um sistema que te paga para descartar seu lixo de forma consciente." />
	<meta name="keywords" content="Amazon, preservação, ambiental, reciclagem, pet, garrafa, lata" />
    <meta name="authorUrl" content="http://kurupyratech.ddns.net">
    <link rel="icon" href="assets/img/favicon.ico">

    <title>Amazon Recycle</title>
</head>

<frameset rows="40,*" framespacing="0" border="0" frameborder="0">
  <frame src="http://streaming08.hstbr.net/player/fabricadepublicidade" noresize scrolling="no" name="frameradio" id="frameradio" />
  <frame src="restrito.php" noresize scrolling="auto" name="principal" id="principal" />
  <noframes>
  <body>

  <p>Esta pagina usa quadros mas seu navegador nao aceita quadros.</p>

  </body>
  </noframes>
<frame src="UntitledFrame-3"></frameset>

</html>
