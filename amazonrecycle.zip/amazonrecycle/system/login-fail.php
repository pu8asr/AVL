<!DOCTYPE HTML>
<!--
	Ion by TEMPLATED
	templated.co @templatedco
	Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
-->
<html>
	<head>
		<title>Rádio Eletro Mix - Pedidos</title>
		<!--
			CODIFICAÇÃO UTF-8 permite conteúdo com acentuação
		-->
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="author" content="Airam - airamcosta@gmail.com" />
		<meta name="description" content="Rádio Eletro Mix Digital, Manaus, Novo Aleixo" />
		<meta name="keywords" content="Radio, Eletro, Digital, Mix" />
		<!--[if lte IE 8]><script src="js/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<link rel="stylesheet" type="text/css" href="css/system.css" />
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
		</noscript>		
	</head>
	<body id="top">

		<!-- Header -->
			<header id="header" class="skel-layers-fixed">
				<h1><a href="#">Rádio Eletro Mix - Sistema de gerenciamento de pedidos dos ouvintes</a></h1>
				<nav id="nav">
					<ul>
						<li><a href="manager.php" target="_self" class="button special">Acessar Sistema</a></li>
					</ul>
				</nav>
			</header>

		<!-- One -->
			<section id="one" class="wrapper style1">
				<header class="major">
					<h2>Falha ao logar</h2>
					<p>Os dados informados são inválidos</p>
					<p align="center">
						<!-- <a href="password-recovery.php" target="_self" class="link">Recuperar dados de acesso</a> -->
					</p>
				</header>
			</section>
			
		<!-- Footer -->
			<footer id="footer">
				<div class="container">
					
					<ul class="copyright">
						<li>Rádio Eletro Mix&copy; <?php echo $data = date("Y"); ?>.</br>Todos os direitos reservados.</li>
					</ul>
				</div>
			</footer>

	</body>
</html>