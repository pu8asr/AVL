<?php
	//Problemas de acentua��o, obedecendo ao padr�o UTF-8 de todo o sistema
	header('Content-Type: text/html;  charset=utf-8', true);
	//header("Content-Type: text/html;  charset=ISO-8859-1", true);
?>

<!DOCTYPE HTML>
<!--
	Ion by TEMPLATED
	templated.co @templatedco
	Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
-->
<html>
	<head>
		<title>Amazon Recycle - Login</title>
		<!--
			CODIFICA��O UTF-8 permite conte�do com acentua��o
		-->
		<meta charset="utf-8">
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="author" content="KurupyraTech" />
		<meta name="description" content="Amazon Recycle � um sistema que te paga para descartar seu lixo de forma consciente." />
		<meta name="keywords" content="Amazon, preserva��o, ambiental, reciclagem, pet, garrafa, lata" />
		<meta name="authorUrl" content="http://kurupyratech.ddns.net">
		<link rel="icon" href="assets/img/favicon.ico">
		<!--[if lte IE 8]><script src="js/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<link rel="stylesheet" type="text/css" href="css/system.css" />
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
			<link rel="stylesheet" type="text/css" href="css/system.css" />
		</noscript>		
	</head>
	<body id="top">

		<!-- One -->
			<section id="one" class="wrapper style1">
				<header class="major">
					<center>
						<img src="logo.png"></img>
						<form class="form" action="valida_login.php" method="post">
							<fieldset>
								<legend>Informe seus dados de acesso</legend></br>
									<label>Usu�rio: 
										<input type="text" name="usuario" id="txUsuario" class="entrada" maxlength="25" placeholder="Digite seu usu�rio aqui" required autofocus/>
									</label>
									<label>Senha: 
										<input type="password" name="senha" id="txSenha" class="entrada" maxlength="40" placeholder="******" required />
									</label>
			
								<!-- Bot�o -->
								<center>
									<input type="submit" class="submit" value="ENTRAR"/>
								</center>
								<p align="center"></br>
									<!-- <a href="password-recovery.php" target="_self" class="link">Recuperar dados de acesso</a> -->
								</p>
								<center><h4><font color="blue"><a href='../register' target='_self'><strong>Clique aqui e cadastre-se gratuitamente</strong></a></font></h4></center>
						</form>
					</center>
				</header>
			</section>			
			
		<!-- Footer -->
			<footer id="footer">
				<div class="container">
					
					<ul class="copyright">
						<li>Amazon Recycle&copy; <?php echo $data = date("Y"); ?>.</br>Todos os direitos reservados.</li>
					</ul>
				</div>
			</footer>

	</body>
</html>