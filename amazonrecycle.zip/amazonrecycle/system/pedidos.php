<?php

	include "conexao.php";

?>

<!DOCTYPE HTML>
<!--
	Ion by TEMPLATED
	templated.co @templatedco
	Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
-->
<html>
	<head>
		<title>Rádio Eletro Mix Digital FM</title>
		<!--
			CODIFICAÇÃO UTF-8 permite conteúdo com acentuação
		-->
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="author" content="Airam - airamcosta@gmail.com" />
		<meta name="description" content="Rádio Eletro Mix Digital, Manaus, Novo Aleixo" />
		<meta name="keywords" content="Radio, Eletro, Digital, Mix, Cristiano Heroz Ferraz" />
		<!--[if lte IE 8]><script src="js/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<link rel="stylesheet" type="text/css" href="css/system.css" />
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
			<link rel="stylesheet" type="text/css" href="css/system.css" />
		</noscript>		
	</head>
	<body id="top">

		<!-- Menu -->
			<header id="header" class="skel-layers-fixed">
				<h1><a href="#">Obrigado por sua audiência</a></h1>
				<nav id="nav">
					<ul>
						<li><a href="pedir.php" target="principal" class="button special">Peça sua música</a></li>
						<li><a href="contato.php" target="principal" class="button special">Contato</a></li>
						<li><a href="https://goo.gl/Lrzkqn" target="_blank" class="button special">Whatsapp Group</a></li>
					</ul>
				</nav>
			</header>
			
		<!-- Body -->
			<font color="Black">

		<h2>Pedidos de Músicas</h2>
		<center>
		<?php

			$query = mysql_query("SELECT * FROM pedidos WHERE played='0' ORDER BY data DESC");
			//$num_pedidos = mysql_num_rows($query);
			if (mysql_num_rows($query) != 0){
				echo "<table><tr><td><strong>Nome</strong></td><td><strong>Local</strong></td><td><strong>Música</strong></td><td><strong>Artista</strong></td></tr>";
				while($linha = mysql_fetch_array($query)){
					echo '<tr><td>' . $linha['nome'] . '</td><td>' . $linha['local'] . '</td><td>' . $linha['musica'] . '</td><td>' . $linha['artista'] . '</td></tr>';
				}
				echo "</table>";
				
				?>
				
				<h4><font color="blue"><a href='pedir.php' target='_self'><strong>Peça a sua música agora!</strong></a></font></h4>
		<?php
			} else {
				echo "<center>";
				echo "<h3><font color='blue'>Não temos pedidos de músicas</font></h3>";
				echo "<h4><font color='blue'><a href='pedir.php' target='_self'><strong>Peça a sua música agora!</strong></a></font></h4>";
				echo "</center>";
			}
			
			echo "<meta HTTP-EQUIV='refresh' CONTENT='5;URL=pedidos.php'>";
		?>
		</center>
		</font>

	</body>
</html>