<!DOCTYPE HTML>
<!--
	Ion by TEMPLATED
	templated.co @templatedco
	Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
-->
<html>
	<head>
		<title>Rádio Eletro Mix Digital FM</title>
		<!--
			CODIFICAÇÃO UTF-8 permite conteúdo com acentuação
		-->
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="author" content="Airam - airamcosta@gmail.com" />
		<meta name="description" content="Rádio Eletro Mix Digital, Manaus, Novo Aleixo" />
		<meta name="keywords" content="Radio, Eletro, Digital, Mix, Cristiano Heroz Ferraz" />
		<!--[if lte IE 8]><script src="js/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<link rel="stylesheet" type="text/css" href="css/system.css" />
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
			<link rel="stylesheet" type="text/css" href="css/system.css" />
		</noscript>		
	</head>
	<body id="top">

		<!-- Menu -->
			<header id="header" class="skel-layers-fixed">
				<h1><a href="#">Obrigado por sua audiência</a></h1>
				<nav id="nav">
					<ul>
						<li><a href="pedidos.php" target="principal" class="button special">Pedidos</a></li>
						<li><a href="contato.php" target="principal" class="button special">Contato</a></li>
						<li><a href="https://goo.gl/Lrzkqn" target="principal" class="button special">Whatsapp Group</a></li>
					</ul>
				</nav>
			</header>
			
		<!-- Body -->
			<font color="Black">
			
			<h2>Pedidos de Músicas</h2>
		<center>
			
			<form class="form" action="valida_pedido.php" width="30" method="post">
			<fieldset>
				<legend>Peça sua música</legend></br>
					<label>Nome: 
						<input type="text" name="nome" id="nome" class="btmspace-15" maxlength="30" placeholder="Queremos te agradecer no ar" autofocus required />
					</label>
					<label>Local: 
						<input type="text" name="local" id="local" class="btmspace-15" maxlength="70" placeholder="Onde você está?" required />
					</label>
					<label>Música: 
						<input type="text" name="musica" id="musica" class="btmspace-15" maxlength="40" placeholder="O nome ou alguma referência" required />
					</label>
					<label>Artista: 
						<input type="text" name="artista" id="artista" class="btmspace-15" maxlength="40" placeholder="Sabe o nome do(a) cantor(a)?" />
					</label>
					<label>Dedicatoria: 
						<input type="text" name="dedicatoria" id="dedicatoria" class="btmspace-15" maxlength="80" placeholder="Dedica a alguém?" />
					</label>
			
					<!-- Botão -->
					<center></br>
						<input type="submit" class="submit" value=" Registrar "/>
					</center>

			</form>
		
		</center>
		</font></br></br></br></br></br></br></br></br>

	</body>
</html>