<?php
	//Problemas de acentua��o, obedecendo ao padr�o UTF-8 de todo o sistema
	//header('Content-Type: text/html;  charset=utf-8', true);
	header("Content-Type: text/html;  charset=ISO-8859-1", true);
?>

<!DOCTYPE HTML>
<!--
	Ion by TEMPLATED
	templated.co @templatedco
	Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
-->

<!-- Permitir somente a entrada de n�meros -->
<script language='JavaScript'>
function SomenteNumero(e){
    var tecla=(window.event)?event.keyCode:e.which;   
    if((tecla>47 && tecla<58)) return true;
    else{
    	if (tecla==8 || tecla==0) return true;
	else  return false;
    }
}
</script>

<!-- Email tudo min�sculo -->
<script type="text/javascript">
// INICIO FUN��O DE MASCARA MAIUSCULA
function minuscula(z){
        v = z.value.toLowerCase(); //toUpperCase � Mai�scula
        z.value = v;
		z.value = z.value.replace(/[' ']/g,''); // remove os espa�os em branco
    }
//FIM DA FUN��O MASCARA MAIUSCULA
</script>

<!-- Valida Email -->
<script type="text/javascript">
function verifica() {
  if (document.forms[0].email.value.length == 0) {
    alert('Por favor, informe o seu EMAIL.');
	document.frmEnvia.email.focus();
    return false;
  }
  return true;
}
 
function checarEmail(){
if( document.forms[0].email.value=="" 
   || document.forms[0].email.value.indexOf('@')==-1 
     || document.forms[0].email.value.indexOf('.')==-1 )
	{
	   alert( "Se voc� informou um e-mail inv�lido, n�o poderemos lhe responder!" );
	   return false;
	}
}
</script>

<html>
	<head>
		<title>Amazon Recycle - Registro</title>
		<!--
			CODIFICA��O UTF-8 permite conte�do com acentua��o
		-->
		<meta charset="utf-8">
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="author" content="KurupyraTech" />
		<meta name="description" content="Amazon Recycle � um sistema que te paga para descartar seu lixo de forma consciente." />
		<meta name="keywords" content="Amazon, preserva��o, ambiental, reciclagem, pet, garrafa, lata" />
		<meta name="authorUrl" content="http://kurupyratech.ddns.net">
		<link rel="icon" href="assets/img/favicon.ico">
		<!--[if lte IE 8]><script src="js/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<link rel="stylesheet" type="text/css" href="css/system.css" />
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
			<link rel="stylesheet" type="text/css" href="css/system.css" />
		</noscript>		
	</head>
	<body id="top">

		<!-- One -->
			<section id="one" class="wrapper style1">
				<header class="major">
					<center>
						<img src="logo.png"></img>
						<form class="form" action="registerUserValidation.php" method="post">
							<fieldset>
								<legend>Informe seus dados de acesso</legend></br>
									<label>*Nome completo: 
										<input type="text" name="nome" id="txNome" class="entrada" maxlength="50" placeholder="Digite seu nome completo aqui" required autofocus/>
									</label>
									<label>*Usu�rio (CPF): 
										<input type="text" name="usuario" id="txUsuario" class="entrada" maxlength="11" onkeypress="return SomenteNumero(event)" placeholder="Digite apenas os n�meros do seu CPF" required />
									</label>
									<label>*E-mail: 
										<input type="mail" name="mail" id="txMail" class="entrada" maxlength="100" onblur="checarEmail();" onkeyup="minuscula(this)" placeholder="Digite um e-mail v�lido aqui" required />
										<input type="hidden" name="indicacao" id="txIndicacao" class="entrada" maxlength="50" placeholder="C�digo do usu�rio que lhe indicou" value="<?php echo $indicacao;?>" />
									</label>
									<label>*Senha: 
										<input type="password" name="senha" id="txSenha" class="entrada" maxlength="10" placeholder="******" required />
									</label>
									<label>Whatsapp (com DDD): 
										<input type="text" name="telefone" id="txTelefone" class="entrada" maxlength="12" onkeypress="return SomenteNumero(event)" placeholder="ATEN��O Ex.: 92982020298" />
									</label>
									<label><b>Informe o DDD sem o 0</b> seguido de todos os n�meros como no exemplo</label>
			
								<!-- Bot�o -->
								<center>
									<input type="submit" class="submit" value="ENTRAR"/>
								</center>
								<p align="center"></br>
									<!-- <a href="password-recovery.php" target="_self" class="link">Recuperar dados de acesso</a> -->
								</p>
								<center><h4><font color="blue"><a href='../login' target='_self'><strong>J� � cadastrado? Fa�a Login.</strong></a></font></h4></center>
						</form>
					</center>
				</header>
			</section>			
			
		<!-- Footer -->
			<footer id="footer">
				<div class="container">
					
					<ul class="copyright">
						<li>Amazon Recycle&copy; <?php echo $data = date("Y"); ?>.</br>Todos os direitos reservados.</li>
					</ul>
				</div>
			</footer>

	</body>
</html>