<?php

	//Problemas de acentua��o, obedecendo ao padr�o UTF-8 de todo o sistema
	header('Content-Type: text/html;  charset=utf-8', true);

	/* Ativa a exibi��o de erros na p�gina */
	/* Ativar apenas para testes pois pode exibir dados sigilosos que o usu�rio n�o pode ter acesso */
	//error_reporting(E_ALL);
	//ini_set('display_errors', 1);
	/* Ativa a exibi��o de erros na p�gina */

	// Define data e hora da atividade no fuso hor�rio brasileiro
	date_default_timezone_set('America/Sao_Paulo');
	$SystemDateTime = date('Y-m-d H:i:s');
	//$ano = date('Y');

	// Verifica se houve POST e se o usu�rio ou a senha �(s�o) vazio(s)
	if (!empty($_POST) AND (empty($_POST['nome']) OR empty($_POST['usuario']) OR empty($_POST['mail']) OR empty($_POST['senha']))) {
		//header("Location: login.php"); exit;
		echo"<script language='javascript' type='text/javascript'>alert('Todos os dados s�o obrigat�rios!');window.location.href='login.php';</script>";
	}

	// Par�metro recebido do formul�rio de login
	$nome = utf8_decode($_POST['nome']);
	$usuario = utf8_decode($_POST['usuario']);
	//$usuario = mysql_real_escape_string($_POST['usuario']);
	$mail = utf8_decode($_POST['mail']);
	$senha = utf8_decode($_POST['senha']);
	//$senha = mysql_real_escape_string($_POST['senha']);
	$whatsapp = utf8_decode($_POST['telefone']);
	
	// Gera o unique_email_id
	$unique_email_id = substr(base64_encode(sha1($email)), 0,20);
	
	// Par�metros de conex�o ao banco de dados
	$server = "localhost";
	$username = "asv4m@z0nr3cycl3";
	$PW = "asv100%Clean";
	$DB = "asv4m@z0nr3cycl3";
	
	// Realiza a conex�o com o banco de dados
	$connection = mysqli_connect($server, $username, $PW, $DB);
	mysqli_set_charset('UTF8');
	
	// Verifica se a conex�o foi bem-sucedida
	if($connection == false) {
		//die("Erro: " . mysqli_connect_error());
		die("Erro de conex�o com o servidor.</br></br>
		Por favor, notifique o suporte!</br>
		Whatsapp: <a href='https://api.whatsapp.com/send?phone=5592994243062&text=Tentei%20realizar%20meu%20cadastro%20no%20sistema%20*Amazon*%20*Recycle*%20mas%20o%20servidor%20apresentou%20um%20erro%20de%20conex�o%20com%20o%20Banco%20de%20Dados...'>+5592994240362</a></br>
		E-mail: <a href='mailto:ongasvbr@gmail.com?subject=Reportando%20erro%20no%20sistema&body=Tentei%20realizar%20meu%20cadastro%20no%20sistema%20Amazon%20Recycle%20mas%20o%20servidor%20apresentou%20um%20erro%20de%20conex�o%20com%20o%20Banco%20de%20Dados...'>ongasvbr@gmail.com</a></br></br>
		<a href='https://asv.ong.br'>Clique aqui para voltar para o site</a>");
		//echo"<script language='javascript' type='text/javascript'>alert('Ocorreu um erro na conex�o com o servidor. Tente novamente mais tarde!');window.location.href='index.php';</script>";
	} else {
		echo "Conectado ao Banco de Dados.</br>";
		
		// Valida��o do e-mail antes de inserir
		$sqlSearch = "SELECT * FROM `users` WHERE (`email` = '$email') LIMIT 1";
		if(mysqli_query($connection, $sqlSearch) == false) {
			//echo "N�o foi poss�vel validar o e-mail informado.</br>";
			die("N�o foi poss�vel validar o e-mail informado.</br></br>
			Por favor, notifique o suporte!</br>
			Whatsapp: <a href='https://api.whatsapp.com/send?phone=5592994243062&text=Tentei%20realizar%20meu%20cadastro%20no%20sistema%20*Amazon*%20*Recycle*%20mas%20o%20servidor%20n�o%20conseguiu%20validar%20o%20meu%20e-mail.%20O%20que%20isto%20significa?'>+5592994240362</a></br>
			E-mail: <a href='mailto:ongasvbr@gmail.com?subject=Reportando%20erro%20no%20sistema&body=Tentei%20realizar%20meu%20cadastro%20no%20sistema%20Amazon%20Recycle%20mas%20o%20servidor%20n�o%20conseguiu%20validar%20o%20meu%20e-mail.%20O%20que%20isto%20significa?'>ongasvr@gmail.com</a></br></br>
			<a href='https://asv.ong.br'>Clique aqui para voltar para o site</a>");
		} else {
			// Verifica se o e-mail j� foi adastrado
			$resultSearch = mysqli_num_rows(mysqli_query($connection, $sqlSearch));
			if($resultSearch != 0) {
				// J� foi cadastrado
				echo "O e-mail j� consta na newsletter.</br>";
				
				// Verifica��es se o cadastro foi validado e envia e-mail de valida��o caso ainda n�o tenha sido validado
				$sqlObtainStatus = mysqli_fetch_assoc(mysqli_query($connection, $sqlSearch));
				$code = $sqlObtainStatus['unique_email_id'];
				$actived = $sqlObtainStatus['actived'];

				if($actived == '0') {
					echo "Por�m a inscri��o ainda n�o foi validada.</br>";
					
					// Dados para re-envio do e-mail de valida��o do cadastro
					$Mensagem = '<div><strong>Voc&ecirc; ainda n&atilde;o confirmou sua inscri&ccedil;&atilde;o!<strong></div>
								 <div><h4>Recebemos uma solicita&ccedil;&atilde;o de inscri&ccedil;&atilde;o na Newsletter do sistema <strong><a href="http://economize.net.br/">Economize</a></strong> para o e-mail <strong>'.$Email.'</strong></h4></div>
									 <div>S&oacute; lhe enviaremos comunicados, mediante a sua aprova&ccedil;&atilde;o por meio da valida&ccedil;&atilde;o desta inscri&ccedil;&atilde;o. Esta medida &eacute; necess&aacute;ria para combater o <strong>SPAM</strong> na rede e impedir que terceiros cadastrem seu e-mail sem o seu consentimento.</div>
									 <div>
										<font color="green">
											<h4>Para confirmar sua inscri&ccedil;&atilde;o, <a href="http://economize.net.br/newsletterRegisterConfirm.php?code='.$unique_email_id.'" target="_blank">clique aqui</a></h4>
										</font>
										<font color="red">
											<h4>Se voc&ecirc; n&atilde;o solicitou a inscri&ccedil;&atilde;o do seu e-mail em nossa newsletter, pedimos desculpas pelo incoveniente e por favor, <a href="http://economize.net.br/newsletterRegisterDelete.php?code='.$unique_email_id.'" target="_blank">clique aqui</a> para excluir seu e-mail de nossa lista</h4>
										</font>
									 </div>
									 <div><h5><i>Ao confirmar sua inscri&ccedil;&atilde;o na newsletter, voc&ecirc; aceita a <strong><a href="http://kurupyratech.ddns.net/politica-de-privacidade.php" target="_blank">Pol�tica de Privacidade</a></strong> e os <strong><a href="http://kurupyratech.ddns.net/termos-de-uso.php" target="_blank">Termos de Uso</a></strong> para os sistemas <strong><a href="http://kurupyratech.ddns.net/" target="_blank">KurupyraTech</a></strong> &copy;</i></h5></font></div>
									 <div>
										 <strong><h4><a href="http://economize.net.br/" target="_blank">Economize</a> &copy; '.$ano.'</strong></br>
										 <div>Todos os direitos reservados!</div></h4>
									 </div>';
					$MensagemAlt = 'Clique no link a seguir ou copie e cole no navegador para confirmar o recebimento da Newsletter do sistema Economize. http://economize.net.br/newsletterRegisterConfirm.php?code='.$unique_email_id.'. Para cancelar, clique ou cole no navegador o link http://economize.net.br/newsletterRegisterDelete.php?code='.$unique_email_id.' </br></br><strong><a href="http://economize.net.br/">Economize</a></strong> &copy; '.$ano.'</br>Todos os direitos reservados!</br></br>';

					/* Re-envio de e-mail para que o assinante valide a inscri��o */
					require ('app/include/PHPMailer/class.phpmailer.php');
					$mail = new PHPMailer();
					//$ToEmail = 'economize.suporte@gmail.com';
					$mail->CharSet = 'UTF-8';
					$mail->From = 'economize.suporte@gmail.com';
					$mail->FromName = 'Economize';
					$mail->IsSMTP();
					$mail->SMTPAuth = true; // turn of SMTP authentication
					$mail->Username = 'economize.suporte@gmail.com'; // SMTP username
					$mail->Password = 'Carpe Diem'; // SMTP password
					$mail->SMTPSecure = 'tls';
					$mail->Host = 'smtp.gmail.com';
					$mail->Port = 587;
					//$mail->SMTPDebug = 2; // Enables SMTP debug information (for testing, remove this line on production mode)
					// 1 = errors and messages
					// 2 = messages only
					$mail->Sender = 'economize.suporte@gmail.com'; // $bounce_email;
					$mail->ConfirmReadingTo = 'economize.suporte@gmail.com';
					$mail->AddReplyTo('economize.suporte@gmail.com');
					$mail->IsHTML(true); //turn on to send html email
					$mail->Subject = 'Newsletter';
					$mail->Body = $Mensagem;
					$mail->AltBody = $MensagemAlt;
					$mail->AddAddress($Email,$Email);
					if($mail->Send()){
						echo "O e-mail para valida��o da inscri��o foi re-enviado!</br>";
						echo"<script language='javascript' type='text/javascript'>alert('Seu e-mail j� estava cadastrado, por�m ainda n�o havia sido validado! Confirme sua inscri��o clicando no link que re-enviamos para o seu e-mail.');window.location.href='index.php';</script>";
					} else {
						echo "O e-mail para valida��o da inscri��o n�o p�de ser enviado!</br>";
						echo"<script language='javascript' type='text/javascript'>alert('Detectamos que seu e-mail j� estava cadastrado, por�m ainda n�o confirmado. Infelizmente n�o conseguimos re-enviar um e-mail para confirmar sua inscri��o. Pedimos desculpas pelo incoveniente! Por favor tente novamente mais tarde...');window.location.href='index.php';</script>";
					}
					/* Re-envio de e-mail para que o assinante valide a inscri��o */
				}

				if($actived == '1') {
					echo "A inscri��o j� foi validada.</br>";
					echo"<script language='javascript' type='text/javascript'>alert('Sua inscri��o j� havia sido validada anteriormente. N�o se preocupe! Voc� receber� nossos informativos...');window.location.href='index.php';</script>";
				}
				
			} else {
				// N�o foi cadastrado ainda
				$sqlInsert = "INSERT INTO `newsletter` (`id`, `unique_email_id`, `email`, `created_at`) VALUES (NULL, '$unique_email_id', '$Email', '$SystemDateTime')";
				if(mysqli_query($connection, $sqlInsert) == false) {
					die("N�o foi poss�vel cadastrar o e-mail informado.</br></br>
					Por favor, notifique o suporte!</br>
					Whatsapp: <a href='https://api.whatsapp.com/send?phone=5592994243062&text=Tentei%20cadastrar%20meu%20e-mail%20na%20newsletter%20do%20sistema%20*Economize*.%20Meu%20e-mail%20foi%20validado%20mas%20o%20sistema%20n�o%20conseguiu%20adicion�-lo.%20O%20que%20isto%20significa?'>+5592994240362</a></br>
					E-mail: <a href='mailto:economize.suporte@gmail.com?subject=Reportando%20erro%20no%20sistema&body=Tentei%20cadastrar%20meu%20e-mail%20na%20newsletter%20do%20sistema%20*Economize*.%20Meu%20e-mail%20foi%20validado%20mas%20o%20sistema%20n�o%20conseguiu%20adicion�-lo.%20O%20que%20isto%20significa?'>economize.suporte@gmail.com</a></br></br>
					<a href='http://economize.net.br'>Clique aqui para voltar para o site</a>");
				} else {
					echo "E-mail adicionado na newsletter.</br>";
					
					// Obt�m o unique_email_id que foi gravado na tabela e n�o o gerado no c�digo (para evitar erros)
					$sqlSearchCode = "SELECT * FROM `newsletter` WHERE (`email` = '$Email') LIMIT 1";
					if(mysqli_query($connection, $sqlSearchCode) == false) {
						//echo "N�o foi poss�vel validar o e-mail informado.</br>";
						die("N�o foi poss�vel obter o c�digo da a��o.</br></br>
						Por favor, notifique o suporte!</br>
						Whatsapp: <a href='https://api.whatsapp.com/send?phone=5592994243062&text=Cadastrei%20meu%20e-mail%20na%20newsletter%20do%20sistema%20*Economize*%20mas%20o%20servidor%20n�o%20conseguiu%20obter%20o%20c&oacute;digo%20para%20enviar%20o%20e-mail%20para%valida&ccedil;&atilde;o%20do%cadastro.%20O%20que%20isto%20significa?'>+5592994240362</a></br>
						E-mail: <a href='mailto:economize.suporte@gmail.com?subject=Reportando%20erro%20no%20sistema&body=Cadastrei%20meu%20e-mail%20na%20newsletter%20do%20sistema%20*Economize*%20mas%20o%20servidor%20n�o%20conseguiu%20obter%20o%20c&oacute;digo%20para%20enviar%20o%20e-mail%20para%valida&ccedil;&atilde;o%20do%cadastro.%20O%20que%20isto%20significa?'>economize.suporte@gmail.com</a></br></br>
						<a href='http://economize.net.br'>Clique aqui para voltar para o site</a>");
					} else {
						// Obt�m o c�digo direto da tabela
						$sqlObtainCode = mysqli_fetch_assoc(mysqli_query($connection, $sqlSearch));
						$code = $sqlObtainCode['unique_email_id'];
						
						// Dados para envio do e-mail de valida��o do cadastro
						$Mensagem = '<div><h4>Recebemos uma solicita&ccedil;&atilde;o de inscri&ccedil;&atilde;o na Newsletter do sistema <strong><a href="http://economize.net.br/">Economize</a></strong> para o e-mail <strong>'.$Email.'</strong></h4></div>
									 <div>S&oacute; lhe enviaremos comunicados, mediante a sua aprova&ccedil;&atilde;o por meio da valida&ccedil;&atilde;o desta inscri&ccedil;&atilde;o. Esta medida &eacute; necess&aacute;ria para combater o <strong>SPAM</strong> na rede e impedir que terceiros cadastrem seu e-mail sem o seu consentimento.</div>
									 <div>
										<font color="green">
											<h4>Para confirmar sua inscri&ccedil;&atilde;o, <a href="http://economize.net.br/newsletterRegisterConfirm.php?code='.$unique_email_id.'" target="_blank">clique aqui</a></h4>
										</font>
										<font color="red">
											<h4>Se voc&ecirc; n&atilde;o solicitou a inscri&ccedil;&atilde;o do seu e-mail em nossa newsletter, pedimos desculpas pelo incoveniente e por favor, <a href="http://economize.net.br/newsletterRegisterDelete.php?code='.$unique_email_id.'" target="_blank">clique aqui</a> para excluir seu e-mail de nossa lista</h4>
										</font>
									 </div>
									 <div><h5><i>Ao confirmar sua inscri&ccedil;&atilde;o na newsletter, voc&ecirc; aceita a <strong><a href="http://kurupyratech.ddns.net/politica-de-privacidade.php" target="_blank">Pol�tica de Privacidade</a></strong> e os <strong><a href="http://kurupyratech.ddns.net/termos-de-uso.php" target="_blank">Termos de Uso</a></strong> para os sistemas <strong><a href="http://kurupyratech.ddns.net/" target="_blank">KurupyraTech</a></strong> &copy;</i></h5></font></div>
									 <div>
										 <strong><h4><a href="http://economize.net.br/" target="_blank">Economize</a> &copy; '.$ano.'</strong></br>
										 <div>Todos os direitos reservados!</div></h4>
									 </div>';
						$MensagemAlt = 'Clique no link a seguir ou copie e cole no navegador para confirmar o recebimento da Newsletter do sistema Economize. http://economize.net.br/newsletterRegisterConfirm.php?code='.$unique_email_id.'. Para cancelar, clique ou cole no navegador o link http://economize.net.br/newsletterRegisterDelete.php?code='.$unique_email_id.' </br></br><strong><a href="http://economize.net.br/">Economize</a></strong> &copy; '.$ano.'</br>Todos os direitos reservados!</br></br>';
	
						/* Envio de e-mail para que o assinante valide a inscri��o */
						require ('app/include/PHPMailer/class.phpmailer.php');
						$mail = new PHPMailer();
						//$ToEmail = 'economize.suporte@gmail.com';
						$mail->CharSet = 'UTF-8';
						$mail->From = 'economize.suporte@gmail.com';
						$mail->FromName = 'Economize';
						$mail->IsSMTP();
						$mail->SMTPAuth = true; // turn of SMTP authentication
						$mail->Username = 'economize.suporte@gmail.com'; // SMTP username
						$mail->Password = 'Carpe Diem'; // SMTP password
						$mail->SMTPSecure = 'tls';
						$mail->Host = 'smtp.gmail.com';
						$mail->Port = 587;
						//$mail->SMTPDebug = 2; // Enables SMTP debug information (for testing, remove this line on production mode)
						// 1 = errors and messages
						// 2 = messages only
						$mail->Sender = 'economize.suporte@gmail.com'; // $bounce_email;
						$mail->ConfirmReadingTo = 'economize.suporte@gmail.com';
						$mail->AddReplyTo('economize.suporte@gmail.com');
						$mail->IsHTML(true); //turn on to send html email
						$mail->Subject = 'Newsletter';
						$mail->Body = $Mensagem;
						$mail->AltBody = $MensagemAlt;
						$mail->AddAddress($Email,$Email);
						if($mail->Send()){
							echo "O e-mail para valida��o da inscri��o foi enviado!</br>";
							echo"<script language='javascript' type='text/javascript'>alert('Confirme sua inscri��o clicando no link que enviamos para o seu e-mail.');window.location.href='index.php';</script>";
						} else {
							echo "O e-mail para valida��o da inscri��o n�o p�de ser enviado!</br>";
							echo"<script language='javascript' type='text/javascript'>alert('Seu e-mail foi cadastrado mas n�o conseguimos lhe enviar um e-mail para confirmar sua inscri��o. Pedimos desculpas pelo incoveniente! Por favor tente novamente mais tarde!');window.location.href='index.php';</script>";
						}
						/* Envio de e-mail para que o assinante valide a inscri��o */
					}
				}
			}
		}
		
		// Encerra a conex�o com o banco de dados
		mysqli_close($connection);
		
	}

?>