<?php

	//Problemas de acentua��o, obedecendo ao padr�o UTF-8 de todo o sistema
	header('Content-Type: text/html;  charset=utf-8', true);

	/* Ativa a exibi��o de erros na p�gina */
	/* Ativar apenas para testes pois pode exibir dados sigilosos que o usu�rio n�o pode ter acesso */
	//error_reporting(E_ALL);
	//ini_set('display_errors', 1);
	/* Ativa a exibi��o de erros na p�gina */

	// Define data e hora da atividade no fuso hor�rio brasileiro
	date_default_timezone_set('America/Sao_Paulo');
	$SystemDateTime = date('Y-m-d H:i:s');
	//$ano = date('Y');

	// Verifica se houve POST e se o usu�rio ou a senha �(s�o) vazio(s)
	if (!empty($_POST) AND (empty($_POST['usuario']) OR empty($_POST['senha']))) {
		//header("Location: login.php"); exit;
		echo"<script language='javascript' type='text/javascript'>alert('Todos os dados s�o obrigat�rios!');window.location.href='login.php';</script>";
	}

	// Par�metro recebido do formul�rio de login
	$usuario = utf8_decode($_POST['usuario']);
	//$usuario = mysql_real_escape_string($_POST['usuario']);
	$senha = utf8_decode($_POST['senha']);
	//$senha = mysql_real_escape_string($_POST['senha']);

// Valida��o do usu�rio/senha digitados
$sql = "SELECT `id`, `nome`, `nivel` FROM `usuarios` WHERE (`usuario` = '". $usuario ."') AND (`senha` = '". sha1($senha) ."') AND (`ativo` = 1) LIMIT 1";
$query = mysql_query($sql);
if (mysql_num_rows($query) != 1) {
	// Mensagem de erro quando os dados s�o inv�lidos e/ou o usu�rio n�o foi encontrado
	//echo "Login inv�lido!"; exit;
	header("Location: login-fail.php"); exit;
} else {
	// Salva os dados encontados na vari�vel $resultado
	$resultado = mysql_fetch_assoc($query);

	// Se a sess�o n�o existir, inicia uma
	if (!isset($_SESSION)) session_start();

	// Salva os dados encontrados na sess�o
	$_SESSION['UsuarioID'] = $resultado['id'];
	$_SESSION['UsuarioNome'] = $resultado['nome'];
	$_SESSION['UsuarioNivel'] = $resultado['nivel'];

	// Redireciona o visitante
	header("Location: manager.php"); exit;
}

?>