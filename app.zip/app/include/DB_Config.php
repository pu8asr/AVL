<?php
 
/**
 * Database config variables
 */
define('DB_HOST', "localhost");
define('DB_USER', "asv");
define('DB_PASSWORD', "asv100%Nossa");
define('DB_DATABASE', "asv_recycle");
?>