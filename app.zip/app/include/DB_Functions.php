<?php

//Problemas de acentuação, obedecendo ao padrão UTF-8 de todo o sistema
header('Content-Type: text/html;  charset=utf-8', true);

/* Ativa a exibição de erros na página */
/* Ativar apenas para testes pois pode exibir dados sigilosos que o usuário não pode ter acesso */
//error_reporting(E_ALL);
//ini_set('display_errors', 1);
/* Ativa a exibição de erros na página */

// Define data e hora da atividade no fuso horário brasileiro
date_default_timezone_set('America/Sao_Paulo');
$ano = date('Y');
 
/**
 * @author Ravi Tamada
 * @link https://www.androidhive.info/2012/01/android-login-and-registration-with-php-mysql-and-sqlite/ Complete tutorial
 */
 
class DB_Functions {
 
    private $conn;
 
    // constructor
    function __construct() {
        require_once 'DB_Connect.php';
        // connecting to database
        $db = new Db_Connect();
        $this->conn = $db->connect();
    }
 
    // destructor
    function __destruct() {
         
    }
	
	/**
     * Storing new user
     * returns user details
     */
    public function storeUser($name, $email, $password) {
        $uuid = uniqid('', true);
        $hash = $this->hashSSHA($password);
        $encrypted_password = $hash["encrypted"]; // encrypted password
        $salt = $hash["salt"]; // salt
 
        $stmt = $this->conn->prepare("INSERT INTO users(unique_id, name, email, encrypted_password, salt, created_at) VALUES(?, ?, ?, ?, ?, NOW())");
        $stmt->bind_param("sssss", $uuid, $name, $email, $encrypted_password, $salt);
        $result = $stmt->execute();
        $stmt->close();
 
        // check for successful store
        if ($result) {
            $stmt = $this->conn->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $user = $stmt->get_result()->fetch_assoc();
            $stmt->close();
 
            return $user;
        } else {
            return false;
        }
    }
	
	/**
     * Update password
     */
    public function updatePassword($uuid, $password) {
        $hash = $this->hashSSHA($password);
        $encrypted_password = $hash["encrypted"]; // encrypted password
        $salt = $hash["salt"]; // salt
 
        $stmt = $this->conn->prepare("UPDATE users SET encrypted_password = ?, salt = ? WHERE unique_id = ?");
        $stmt->bind_param("sss", $encrypted_password, $salt, $uuid);
        $result = $stmt->execute();
        $stmt->close();
 
        // check for successful store
        if ($result) {
            $stmt = $this->conn->prepare("SELECT * FROM users WHERE unique_id = ?");
            $stmt->bind_param("s", $uuid);
            $stmt->execute();
            $user = $stmt->get_result()->fetch_assoc();
            $stmt->close();
 
            return $user;
        } else {
            return false;
        }
    }
	
	/**
     * Recover password
     */
    public function recoverPassword($email) {
		$aleatory_password = $this->makeRandomPassword();
		$hash = $this->hashSSHA($aleatory_password);
        $encrypted_password = $hash["encrypted"]; // encrypted password
        $salt = $hash["salt"]; // salt
 
        $stmt = $this->conn->prepare("UPDATE users SET encrypted_password = ?, salt = ? WHERE email = ?");
        $stmt->bind_param("sss", $encrypted_password, $salt, $email);
        $result = $stmt->execute();
        $stmt->close();
 
        // check for successful store
        if ($result) {
            // Send a email with a temporary password
			$Subject = 'Recupere seu acesso';
			$Message = '<div><h4>Voc&ecirc; esqueceu sua senha de acesso ao sistema <strong><a href="http://economize.net.br/">Economize</a></strong>.</h4></div>
						 <div>Acesse o sistema com a senha <strong>'.$aleatory_password.'</strong> e informe uma nova senha após o login.</div>						 
						 <div>
						 <strong><h4><a href="http://economize.net.br/" target="_blank">Economize</a> &copy; '.$ano.'</strong></br>
						 <div>Todos os direitos reservados!</div></h4>
						 </div>';
			$MessageAlt = 'Voc&ecirc; recebeu a senha teporária '.$aleatory_password.' para acessar o sistema Economize e deverá alterá-la após o login.</br></br><strong><a href="http://economize.net.br/">Economize</a></strong> &copy; '.$ano.'</br>Todos os direitos reservados!</br></br>';
			/* Envio de e-mail para que o assinante valide a inscrição */
			require ('PHPMailer/class.phpmailer.php');
			$mail = new PHPMailer();
			//$ToEmail = 'economize.suporte@gmail.com';
			$mail->CharSet = 'UTF-8';
			$mail->From = 'economize.suporte@gmail.com';
			$mail->FromName = 'Economize';
			$mail->IsSMTP();
			$mail->SMTPAuth = true; // turn of SMTP authentication
			$mail->Username = 'economize.suporte@gmail.com'; // SMTP username
			$mail->Password = 'Carpe Diem'; // SMTP password
			$mail->SMTPSecure = 'tls';
			$mail->Host = 'smtp.gmail.com';
			$mail->Port = 587;
			//$mail->SMTPDebug = 2; // Enables SMTP debug information (for testing, remove this line on production mode)
			// 1 = errors and messages
			// 2 = messages only
			$mail->Sender = 'economize.suporte@gmail.com'; // $bounce_email;
			$mail->ConfirmReadingTo = 'economize.suporte@gmail.com';
			$mail->AddReplyTo('economize.suporte@gmail.com');
			$mail->IsHTML(true); //turn on to send html email
			$mail->Subject = $Subject;
			$mail->Body = $Message;
			$mail->AltBody = $MessageAlt;
			$mail->AddAddress($email,$email);
			if($mail->Send()){
				// return user data stored successfully
				return true;
			} else {
				// user failed to store
				return false;
			}
			/* Envio de e-mail para que o assinante valide a inscrição */
        } else {
            return false;
        }
    }
 
    /**
     * Get user by email and password
     */
    public function getUserByEmailAndPassword($email, $password) {
 
        $stmt = $this->conn->prepare("SELECT * FROM users WHERE email = ?");
 
        $stmt->bind_param("s", $email);
 
        if ($stmt->execute()) {
            $user = $stmt->get_result()->fetch_assoc();
            $stmt->close();
 
            // verifying user password
            $salt = $user['salt'];
            $encrypted_password = $user['encrypted_password'];
            $hash = $this->checkhashSSHA($salt, $password);
            // check for password equality
            if ($encrypted_password == $hash) {
                // user authentication details are correct
                return $user;
            }
        } else {
            return NULL;
        }
    }
 
    /**
     * Check user is existed or not
     */
    public function isUserExisted($email) {
        $stmt = $this->conn->prepare("SELECT email from users WHERE email = ?");
 
        $stmt->bind_param("s", $email);
 
        $stmt->execute();
 
        $stmt->store_result();
 
        if ($stmt->num_rows > 0) {
            // user existed 
            $stmt->close();
            return true;
        } else {
            // user not existed
            $stmt->close();
            return false;
        }
    }
	
	/**
     * Check user is actived or not
     */
    public function isUserActived($email) {
        $stmt = $this->conn->prepare("SELECT email from users WHERE email = ? AND actived = '1'");
 
        $stmt->bind_param("s", $email);
 
        $stmt->execute();
 
        $stmt->store_result();
 
        if ($stmt->num_rows > 0) {
            // user actived
            $stmt->close();
            return true;
        } else {
            // user not actived
            $stmt->close();
            return false;
        }
    }
	
	/**
     * Check user is blocked or not
     */
    public function isUserBlocked($email) {
        $stmt = $this->conn->prepare("SELECT email from users WHERE email = ? AND actived = '1' AND blocked = '1'");
 
        $stmt->bind_param("s", $email);
 
        $stmt->execute();
 
        $stmt->store_result();
 
        if ($stmt->num_rows > 0) {
            // user actived
            $stmt->close();
            return true;
        } else {
            // user not actived
            $stmt->close();
            return false;
        }
    }
	
	/*
	* Make Random Password
	*/
	// Gerar uma nova senha aleatória
	public function makeRandomPassword(){

		$salt = "abchefghjkmnpqrstuvwxyz0123456789";
		srand((double)microtime()*1000000);
		$i = 0;

		while ($i <= 7){

			$num = rand() % 33;
			$tmp = substr($salt, $num, 1);
			$pass = $pass . $tmp;
			$i++;

		}

		return $pass;

	}
 
    /**
     * Encrypting password
     * @param password
     * returns salt and encrypted password
     */
    public function hashSSHA($password) {
 
        $salt = sha1(rand());
        $salt = substr($salt, 0, 10);
        $encrypted = base64_encode(sha1($password . $salt, true) . $salt);
        $hash = array("salt" => $salt, "encrypted" => $encrypted);
        return $hash;
    }
 
    /**
     * Decrypting password
     * @param salt, password
     * returns hash string
     */
    public function checkhashSSHA($salt, $password) {
 
        $hash = base64_encode(sha1($password . $salt, true) . $salt);
 
        return $hash;
    }
 
}
 
?>