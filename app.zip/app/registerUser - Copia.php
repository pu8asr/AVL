<?php

	//Problemas de acentuação, obedecendo ao padrão UTF-8 de todo o sistema
	header('Content-Type: text/html;  charset=utf-8', true);

	/* Ativa a exibição de erros na página */
	/* Ativar apenas para testes pois pode exibir dados sigilosos que o usuário não pode ter acesso */
	//error_reporting(E_ALL);
	//ini_set('display_errors', 1);
	/* Ativa a exibição de erros na página */

	// Define data e hora da atividade no fuso horário brasileiro
	date_default_timezone_set('America/Sao_Paulo');
	$SystemDateTime = date('Y-m-d H:i:s');

	// json response array
	$response = array("error" => FALSE);

	// Verifica se houve post (Impedir o acesso direto ao reisterUser.php)
	// Esta verificação também é feita no app para reduzir as requisições ao servidor
	if (isset($_POST['name']) && isset($_POST['email']) && isset($_POST['password'])) {
		// Parâmetros recebidos do app (é necessário codificá-los para não haver caracteres estranhos no Banco de Dados
		$name = utf8_decode($_POST['name']);
		$email = utf8_decode($_POST['email']);
		$password = utf8_decode($_POST['password']);
		// Parâmetros de conexão ao banco de dados
		$server = "localhost";
		$username = "3ch0n0m1z4r";
		$PW = "HaY23Zh4QBgN8v42";
		$DB = "3ch0n0m1z4r";
		// Realiza a conexão com o banco de dados
		$connection = mysqli_connect($server, $username, $PW, $DB);
		mysqli_set_charset('UTF8');
		// Verifica se a conexão não foi realizada
		if($connection == false) {
			$response["error"] = TRUE;
			$response["error_msg"] = "Não foi possível conectar ao Banco de Dados. Lamentamos o incoveniente. Tente novamente mais tarde...";
			echo json_encode($response);
		} else { // Se a conexão foi realizada
			// Verifica se o e-mail já consta na tabela de usuários
			$sqlSearch = "SELECT * FROM `users` WHERE (`email` = '$email') LIMIT 1";
			$querySearch = mysqli_query($connection, $sqlSearch);
			if($querySearch == false) { // Se a consulta não foi realizada
				$response["error"] = TRUE;
				$response["error_msg"] = "Não foi possível validar o seu e-mail internamente. Lamentamos o incoveniente. Tente novamente mais tarde...";
				echo json_encode($response);
			} else { // Se a consulta foi realizada
				// Verifica a quantidade de registros encontrados para os parâmetros informados
				if(mysqli_num_rows($querySearch) != 0) { // Se a quantidade for diferente de 0
					// O e-mail já existe, então é necessário verificar se o mesmo foi validado ou não
					$status = mysqli_fetch_array($querySearch);
					$ativo = utf8_encode($status['actived']);
					if($actived == '0') { // O cadastro ainda não foi confirmado
						// Re-envia o e-mail para ativação da conta
						//Para melhor garantia é melhor obter os dados gravados em vez de usar os recebidos do app
						$sqlGetDataForEmailActivation = "SELECT * FROM `users` WHERE (`email` = '$email') LIMIT 1";
						$queryGetDataForEmailActivation = mysqli_query($connection, $sqlGetDataForEmailActivation);
						if($queryGetDataForEmailActivation == false) { // Não conseguiu resgatar os dados
							$response["error"] = TRUE;
							$response["error_msg"] = "Sua conta foi criada mas não conseguiremos lhe enviar um e-mail para ativação neste momento. Tente novamente mais tarde...";
							echo json_encode($response);
						} else { // Conseguiu resgatar os dados
							// Prepara os dados que irão compor o e-mail
							$data = mysqli_fetch_array($queryGetDataForEmailActivation);
							$id = utf8_encode($data['unique_id']);
							$destinatario = utf8_encode{$data['name']);
							$correio = utf8_encode($data['email']);
							$Mensagem = '<div><h4>Ol&aacute; '.$destinatario.'! Voc&ecirc; tentou criar sua conta no sistema <strong><a href="http://economize.ddns.net/">Economize</a></strong> com o e-mail <strong>'.$correio.'</strong>, mas o mesmo j&aacute; estava cadastrado. Falta apenas você confirmar o seu cadastro!</h4></div>
										 <div>Lhe enviamos este e-mail para validar o seu cadastro. Esta medida &eacute; necess&aacute;ria para combater o <strong>SPAM</strong> na rede e impedir que terceiros cadastrem seu e-mail sem o seu consentimento.</div>
										 <div>
											<font color="green">
												<h4>Para confirmar sua inscri&ccedil;&atilde;o, <a href="http://economize.ddns.net/registerUserConfirm.php?code='.$id.'" target="_blank">clique aqui</a></h4>
											</font>
											<font color="red">
												<h4>Se voc&ecirc; n&atilde;o solicitou este cadastro(ou mesmo se desistiu de fazê-lo), pedimos desculpas pelo incoveniente e por favor, <a href="http://economize.ddns.net/deleteUser.php?code='.$id.'" target="_blank">clique aqui</a> para excluir seu e-mail de nossa lista</h4>
											</font>
										 </div>
										 <div><h5><i>Ao confirmar sua inscri&ccedil;&atilde;o, voc&ecirc; aceita a <strong><a href="http://kurupyratech.ddns.net/politica-de-privacidade.php" target="_blank">Política de Privacidade</a></strong> e os <strong><a href="http://kurupyratech.ddns.net/termos-de-uso.php" target="_blank">Termos de Uso</a></strong> para os sistemas <strong><a href="http://kurupyratech.ddns.net/" target="_blank">KurupyraTech</a></strong> &copy;</i></h5></font></div>
										 <div>
											<strong><h4><a href="http://economize.ddns.net/" target="_blank">Economize</a> &copy; '.$ano.'</strong></br>
											<div>Todos os direitos reservados!</div></h4>
										 </div>';
							$MensagemAlt = 'Clique no link a seguir ou copie e cole no navegador para confirmar o seu cadastro no sistema Economize. http://economize.ddns.net/newsletterRegisterConfirm.php?code='.$id.'. Para cancelar e excluir seu cadastro, clique ou cole no navegador o link http://economize.ddns.net/deleteUser.php?code='.$id.' </br></br><strong><a href="http://economize.ddns.net/">Economize</a></strong> &copy; '.$ano.'</br>Todos os direitos reservados!</br></br>';
							/* Envio de e-mail para que o assinante valide a inscrição */
							require ('../PHPMailer/class.phpmailer.php');
							$mail = new PHPMailer();
							//$ToEmail = 'economize.suporte@gmail.com';
							$mail->CharSet = 'UTF-8';
							$mail->From = 'economize.suporte@gmail.com';
							$mail->FromName = 'Economize';
							$mail->IsSMTP();
							$mail->SMTPAuth = true; // turn of SMTP authentication
							$mail->Username = 'economize.suporte@gmail.com'; // SMTP username
							$mail->Password = 'Carpe Diem'; // SMTP password
							$mail->SMTPSecure = 'tls';
							$mail->Host = 'smtp.gmail.com';
							$mail->Port = 587;
							//$mail->SMTPDebug = 2; // Enables SMTP debug information (for testing, remove this line on production mode)
							// 1 = errors and messages
							// 2 = messages only
							$mail->Sender = 'economize.suporte@gmail.com'; // $bounce_email;
							$mail->ConfirmReadingTo = 'economize.suporte@gmail.com';
							$mail->AddReplyTo('economize.suporte@gmail.com');
							$mail->IsHTML(true); //turn on to send html email
							$mail->Subject = 'Confirme seu cadastro';
							$mail->Body = $Mensagem;
							$mail->AltBody = $MensagemAlt;
							$mail->AddAddress($correio,$correio);
							if($mail->Send()){
								$response["error"] = FALSE;
								$response["msg"] = "Sua conta já havia sido criada! Falta apenas validar seu cadastro. Verifique seu e-mail.";
								echo json_encode($response);
							} else {
								$response["error"] = TRUE;
								$response["error_msg"] = "Sua conta havia sido criada! É necessário apenas validar seu cadastro, mas não conseguimos lhe enviar o e-mail de ativação. Tente novamente mais tarde...";
								echo json_encode($response);
							}
							/* Envio de e-mail para que o assinante valide a inscrição */
					}
					if($actived == '1') { // O cadastro já foi confirmado
						$response["error"] = TRUE;
						$response["error_msg"] = "Seu cadastro já foi confirmado anteriormente. Faça login";
						echo json_encode($response);
					}					
				} else { // O e-mail ainda não consta no Banco de Dados e pode ser cadastrado
					// Prepara os dados para serem inseridos no Banco de Dados
					$unique_id = substr(base64_encode(sha1($email)), 0,23);
					$salt = md5($password);
					$encrypted = base64_encode(sha1($password . $salt, true) . $salt);
					$hash = array("salt" => $salt, "encrypted" => $encrypted);
					$encrypted_password = substr($hash["encrypted"], 0,80);
					$salt = substr(hash["salt"], 0,10);
					// Prepara os dados para serem inseridos na tabela
					$sqlInsert = "INSERT INTO `newsletter` (`unique_id`, `name`, `email`, `encrypted_password`, `salt`, `created_at`) VALUES ('$unique_id', '$name', '$email', '$encrypted_password', '$salt', '$SystemDateTime')";
					$queryInsert = mysqli_query($connection, $sqlInsert);
					if($queryInsert == false) { // Se os dados não foram gravados na tabela
						$response["error"] = TRUE;
						$response["error_msg"] = "Ocorreu um erro ao criar sua conta. Tente novamente mais tarde ou entre em contato com o suporte acessando nosso site.";
						echo json_encode($response);
					} else { // Se os dados foram gravados na tabela
						// Envia o e-mail para ativação da conta
						//Para melhor garantia é melhor obter os dados gravados em vez de usar os recebidos do app
						$sqlGetDataForEmailActivation = "SELECT * FROM `users` WHERE (`email` = '$email') LIMIT 1";
						$queryGetDataForEmailActivation = mysqli_query($connection, $sqlGetDataForEmailActivation);
						if($queryGetDataForEmailActivation == false) { // Não conseguiu resgatar os dados
							$response["error"] = TRUE;
							$response["error_msg"] = "Sua conta foi criada mas não conseguiremos lhe enviar um e-mail para ativação neste momento. Tente novamente mais tarde...";
							echo json_encode($response);
						} else { // Conseguiu resgatar os dados
							// Prepara os dados que irão compor o e-mail
							$data = mysqli_fetch_array($queryGetDataForEmailActivation);
							$id = utf8_encode($data['unique_id']);
							$destinatario = utf8_encode{$data['name']);
							$correio = utf8_encode($data['email']);
							$Mensagem = '<div><h4>Ol&aacute; '.$destinatario.'! Recebemos uma solicita&ccedil;&atilde;o de inscri&ccedil;&atilde;o no sistema <strong><a href="http://economize.ddns.net/">Economize</a></strong> para o e-mail <strong>'.$correio.'</strong></h4></div>
										 <div>Lhe enviamos este e-mail para validar o seu cadastro. Esta medida &eacute; necess&aacute;ria para combater o <strong>SPAM</strong> na rede e impedir que terceiros cadastrem seu e-mail sem o seu consentimento.</div>
										 <div>
											<font color="green">
												<h4>Para confirmar sua inscri&ccedil;&atilde;o, <a href="http://economize.ddns.net/registerUserConfirm.php?code='.$id.'" target="_blank">clique aqui</a></h4>
											</font>
											<font color="red">
												<h4>Se voc&ecirc; n&atilde;o solicitou este cadastro(ou mesmo se desistiu de fazê-lo), pedimos desculpas pelo incoveniente e por favor, <a href="http://economize.ddns.net/deleteUser.php?code='.$id.'" target="_blank">clique aqui</a> para excluir seu e-mail de nossa lista</h4>
											</font>
										 </div>
										 <div><h5><i>Ao confirmar sua inscri&ccedil;&atilde;o, voc&ecirc; aceita a <strong><a href="http://kurupyratech.ddns.net/politica-de-privacidade.php" target="_blank">Política de Privacidade</a></strong> e os <strong><a href="http://kurupyratech.ddns.net/termos-de-uso.php" target="_blank">Termos de Uso</a></strong> para os sistemas <strong><a href="http://kurupyratech.ddns.net/" target="_blank">KurupyraTech</a></strong> &copy;</i></h5></font></div>
										 <div>
											<strong><h4><a href="http://economize.ddns.net/" target="_blank">Economize</a> &copy; '.$ano.'</strong></br>
											<div>Todos os direitos reservados!</div></h4>
										 </div>';
							$MensagemAlt = 'Clique no link a seguir ou copie e cole no navegador para confirmar o seu cadastro no sistema Economize. http://economize.ddns.net/newsletterRegisterConfirm.php?code='.$id.'. Para cancelar e excluir seu cadastro, clique ou cole no navegador o link http://economize.ddns.net/deleteUser.php?code='.$id.' </br></br><strong><a href="http://economize.ddns.net/">Economize</a></strong> &copy; '.$ano.'</br>Todos os direitos reservados!</br></br>';
							/* Envio de e-mail para que o assinante valide a inscrição */
							require ('../PHPMailer/class.phpmailer.php');
							$mail = new PHPMailer();
							//$ToEmail = 'economize.suporte@gmail.com';
							$mail->CharSet = 'UTF-8';
							$mail->From = 'economize.suporte@gmail.com';
							$mail->FromName = 'Economize';
							$mail->IsSMTP();
							$mail->SMTPAuth = true; // turn of SMTP authentication
							$mail->Username = 'economize.suporte@gmail.com'; // SMTP username
							$mail->Password = 'Carpe Diem'; // SMTP password
							$mail->SMTPSecure = 'tls';
							$mail->Host = 'smtp.gmail.com';
							$mail->Port = 587;
							//$mail->SMTPDebug = 2; // Enables SMTP debug information (for testing, remove this line on production mode)
							// 1 = errors and messages
							// 2 = messages only
							$mail->Sender = 'economize.suporte@gmail.com'; // $bounce_email;
							$mail->ConfirmReadingTo = 'economize.suporte@gmail.com';
							$mail->AddReplyTo('economize.suporte@gmail.com');
							$mail->IsHTML(true); //turn on to send html email
							$mail->Subject = 'Confirme seu cadastro';
							$mail->Body = $Mensagem;
							$mail->AltBody = $MensagemAlt;
							$mail->AddAddress($correio,$correio);
							if($mail->Send()){
								$response["error"] = FALSE;
								$response["msg"] = "Sua conta foi criada! Clique no link que enviamos para o seu e-mail para confirmar o seu cadastro.";
								echo json_encode($response);
							} else {
								$response["error"] = TRUE;
								$response["error_msg"] = "Sua conta foi criada! Infelizmente não conseguimos lhe enviar o e-mail de ativação. Tente novamente mais tarde...";
								echo json_encode($response);
							}
							/* Envio de e-mail para que o assinante valide a inscrição */
						}
					}
				}
			}
		}
	} else {
		// Se não houve post retorna uma mensagem
		$response["error"] = TRUE;
		$response["error_msg"] = "Informe todos os dados solicitados!";
		echo json_encode($response);
	}
	
?>