<?php

//Problemas de acentuação, obedecendo ao padrão UTF-8 de todo o sistema
header('Content-Type: text/html;  charset=utf-8', true);

/* Ativa a exibição de erros na página */
/* Ativar apenas para testes pois pode exibir dados sigilosos que o usuário não pode ter acesso */
//error_reporting(E_ALL);
//ini_set('display_errors', 1);
/* Ativa a exibição de erros na página */

// Define data e hora da atividade no fuso horário brasileiro
date_default_timezone_set('America/Sao_Paulo');
$ano = date('Y');
 
require_once 'include/DB_Functions.php';
$db = new DB_Functions();
 
// json response array
$response = array("error" => FALSE);
 
if (isset($_POST['name']) && isset($_POST['email']) && isset($_POST['password'])) {
 
    // receiving the post params
    $name = utf8_decode($_POST['name']);
    $email = utf8_decode($_POST['email']);
    $password = utf8_decode($_POST['password']);
 
    // check if user is already existed with the same email
    if ($db->isUserExisted($email)) {
        // check if user is already actived
		if ($db->isUserActived($email)) {
			$response["error"] = TRUE;
			$response["error_msg"] = "Sua conta já está ativa.\nFaça login informando o email " . $email . " e a senha cadastrada.";
			echo json_encode($response);
        } else {
			$user = $db->getUserByEmail($email);
			if ($user) {
				// send a confirmation mail
				$id = utf8_encode($user["unique_id"]);
				$destinatario = utf8_encode($user["name"]);
				$correio = utf8_encode($user["email"]);
				$Subject = 'Confirme seu cadastro (+1 chance)';
				$Message = '<div><h4>Ol&aacute; '.$destinatario.'! Voc&ecirc; tentou se cadastrar no sistema <strong><a href="http://asv.ong.br/amazonrecycle/">Amazon Recycle</a></strong> com o e-mail <strong>'.$correio.'</strong></h4></div>
							<div>Este e-mail j&aacute; havia sido cadastrado anteriormente mas o cadastro ainda n&atilde;o havia sido confirmado. Ent&atilde;o, estamos re-enviando o link para que voc&ecirc; possa ativar sua conta e acessar o sistema. Esta &eacute; uma medida necess&aacute;ria para combater o <strong>SPAM</strong> na rede e impedir que terceiros cadastrem seu e-mail sem o seu consentimento.</div>
							<div>
							<font color="green">
							<h4>Para confirmar sua inscri&ccedil;&atilde;o, <a href="http://asv.ong.br/amazonrecycle/app/registerUserConfirm.php?code='.$id.'" target="_blank">clique aqui</a></h4>
							</font>
							<font color="red">
							<h4>Se voc&ecirc; n&atilde;o solicitou este cadastro(ou mesmo se desistiu de fazê-lo), pedimos desculpas pelo incômodo e por favor, <a href="http://asv.ong.br/amazonrecycle/app/registerUserDelete.php?code='.$id.'" target="_blank">clique aqui</a> para excluí-lo do sistema, evitando assim que voltemos a importuná-lo</h4>
							</font>
							</div>
							<div><h5><i>Ao confirmar sua inscri&ccedil;&atilde;o, voc&ecirc; aceita a <strong><a href="http://kurupyratech.ddns.net/politica-de-privacidade.php" target="_blank">Política de Privacidade</a></strong> e os <strong><a href="http://kurupyratech.ddns.net/termos-de-uso.php" target="_blank">Termos de Uso</a></strong> para os sistemas <strong><a href="http://kurupyratech.ddns.net/" target="_blank">KurupyraTech</a></strong> &copy;</i></h5></font></div>
							<div>
							<strong><h4><a href="http://asv.ong.br/amazonrecycle/" target="_blank">Amazon Recycle</a> &copy; '.$ano.'</strong></br>
							<div>Todos os direitos reservados!</div></h4>
							</div>';
				$MessageAlt = 'Clique no link a seguir ou copie e cole no navegador para confirmar o seu cadastro no sistema Amazon Recycle. http://asv.ong.br/amazonrecycle/newsletterRegisterConfirm.php?code='.$id.'. Para cancelar e excluir seu cadastro, clique ou cole no navegador o link http://asv.ong.br/amazonrecycle/app/registerUserDelete.php?code='.$id.' </br></br><strong><a href="http://asv.ong.br/amazonrecycle/">Amazon Recycle</a></strong> &copy; '.$ano.'</br>Todos os direitos reservados!</br></br>';
				/* Envio de e-mail para que o assinante valide a inscrição */
				require ('include/PHPMailer/class.phpmailer.php');
				$mail = new PHPMailer();
				//$ToEmail = 'ongasvbr@gmail.com';
				$mail->CharSet = 'UTF-8';
				$mail->From = 'ongasvbr@gmail.com';
				$mail->FromName = 'Amazon Recycle';
				$mail->IsSMTP();
				$mail->SMTPAuth = true; // turn of SMTP authentication
				$mail->Username = 'ongasvbr@gmail.com'; // SMTP username
				$mail->Password = 'asv100%Nossa'; // SMTP password
				$mail->SMTPSecure = 'tls';
				$mail->Host = 'smtp.gmail.com';
				$mail->Port = 587;
				//$mail->SMTPDebug = 2; // Enables SMTP debug information (for testing, remove this line on production mode)
				// 1 = errors and messages
				// 2 = messages only
				$mail->Sender = 'ongasvbr@gmail.com'; // $bounce_email;
				$mail->ConfirmReadingTo = 'ongasvbr@gmail.com';
				$mail->AddReplyTo('ongasvbr@gmail.com');
				$mail->IsHTML(true); //turn on to send html email
				$mail->Subject = $Subject;
				$mail->Body = $Message;
				$mail->AltBody = $MessageAlt;
				$mail->AddAddress($correio,$correio);
				if($mail->Send()){
					$response["error"] = TRUE;
					$response["error_msg"] = "Sua conta já havia sido criada mas ainda não foi ativada.\nConfirme seu cadastro clicando no link que enviamos para " . $email . "";
					echo json_encode($response);
				} else {
					$response["error"] = TRUE;
					$response["error_msg"] = "Sua conta já havia sido criada.\nInfelizmente não conseguimos enviar o link de ativação para o seu e-mail.\nTente novamente mais tarde.";
					echo json_encode($response);
				}
				/* Envio de e-mail para que o assinante valide a inscrição */
			} else {
				$response["error"] = TRUE;
				$response["error_msg"] = "Sua conta já havia sido criada.\nInfelizmente não conseguimos obter detalhes para enviar o link de ativação para o seu e-mail.\nTente novamente mais tarde.";
				echo json_encode($response);
			}
		}
    } else {
        // create a new user
        $user = $db->storeUser($name, $email, $password);
        if ($user) {
			// send a confirmation mail
			$id = utf8_encode($user["unique_id"]);
			$destinatario = utf8_encode($user["name"]);
			$correio = utf8_encode($user["email"]);
			$Subject = 'Confirme seu cadastro';
			$Message = '<div><h4>Ol&aacute; '.$destinatario.'! Voc&ecirc; se cadastrou no sistema <strong><a href="http://asv.ong.br/amazonrecycle/">Amazon Recycle</a></strong> com o e-mail <strong>'.$correio.'</strong></h4></div>
						 <div>Enviamos este e-mail para validar o seu cadastro. Esta &eacute; uma medida necess&aacute;ria para combater o <strong>SPAM</strong> na rede e impedir que terceiros cadastrem seu e-mail sem o seu consentimento.</div>
						 <div>
						 <font color="green">
						 <h4>Para confirmar sua inscri&ccedil;&atilde;o, <a href="http://asv.ong.br/amazonrecycle/app/registerUserConfirm.php?code='.$id.'" target="_blank">clique aqui</a></h4>
						 </font>
						 <font color="red">
						 <h4>Se voc&ecirc; n&atilde;o solicitou este cadastro(ou mesmo se desistiu de fazê-lo), pedimos desculpas pelo incômodo e por favor, <a href="http://asv.ong.br/amazonrecycle/app/registerUserDelete.php?code='.$id.'" target="_blank">clique aqui</a> para excluí-lo do sistema, evitando assim que voltemos a importuná-lo</h4>
						 </font>
						 </div>
						 <div><h5><i>Ao confirmar sua inscri&ccedil;&atilde;o, voc&ecirc; aceita a <strong><a href="http://kurupyratech.ddns.net/politica-de-privacidade.php" target="_blank">Política de Privacidade</a></strong> e os <strong><a href="http://kurupyratech.ddns.net/termos-de-uso.php" target="_blank">Termos de Uso</a></strong> para os sistemas <strong><a href="http://kurupyratech.ddns.net/" target="_blank">KurupyraTech</a></strong> &copy;</i></h5></font></div>
						 <div>
						 <strong><h4><a href="http://asv.ong.br/amazonrecycle/" target="_blank">Amazon Recycle</a> &copy; '.$ano.'</strong></br>
						 <div>Todos os direitos reservados!</div></h4>
						 </div>';
			$MessageAlt = 'Clique no link a seguir ou copie e cole no navegador para confirmar o seu cadastro no sistema Amazon Recycle. http://asv.ong.br/amazonrecycle/newsletterRegisterConfirm.php?code='.$id.'. Para cancelar e excluir seu cadastro, clique ou cole no navegador o link http://asv.ong.br/amazonrecycle/app/registerUserDelete.php?code='.$id.' </br></br><strong><a href="http://asv.ong.br/amazonrecycle/">Amazon Recycle</a></strong> &copy; '.$ano.'</br>Todos os direitos reservados!</br></br>';
			/* Envio de e-mail para que o assinante valide a inscrição */
			require ('include/PHPMailer/class.phpmailer.php');
			$mail = new PHPMailer();
			//$ToEmail = 'ongasvbr@gmail.com';
			$mail->CharSet = 'UTF-8';
			$mail->From = 'ongasvbr@gmail.com';
			$mail->FromName = 'Amazon Recycle';
			$mail->IsSMTP();
			$mail->SMTPAuth = true; // turn of SMTP authentication
			$mail->Username = 'ongasvbr@gmail.com'; // SMTP username
			$mail->Password = 'asv100%Nossa'; // SMTP password
			$mail->SMTPSecure = 'tls';
			$mail->Host = 'smtp.gmail.com';
			$mail->Port = 587;
			//$mail->SMTPDebug = 2; // Enables SMTP debug information (for testing, remove this line on production mode)
			// 1 = errors and messages
			// 2 = messages only
			$mail->Sender = 'ongasvbr@gmail.com'; // $bounce_email;
			$mail->ConfirmReadingTo = 'ongasvbr@gmail.com';
			$mail->AddReplyTo('ongasvbr@gmail.com');
			$mail->IsHTML(true); //turn on to send html email
			$mail->Subject = $Subject;
			$mail->Body = $Message;
			$mail->AltBody = $MessageAlt;
			$mail->AddAddress($correio,$correio);
			if($mail->Send()){
				// return user data stored successfully
				$response["error"] = FALSE;
				$response["uid"] = $user["unique_id"];
				$response["user"]["name"] = $user["name"];
				$response["user"]["email"] = $user["email"];
				$response["user"]["created_at"] = $user["created_at"];
				$response["user"]["updated_at"] = $user["updated_at"];
				echo json_encode($response);
			} else {
				// user failed to store
				$response["error"] = TRUE;
				$response["error_msg"] = "Sua conta foi criada.\nInfelizmente não conseguimos enviar o link de ativação para o seu e-mail.\nTente novamente mais tarde.";
				echo json_encode($response);
			}
			/* Envio de e-mail para que o assinante valide a inscrição */
        } else {
            // user failed to store
            $response["error"] = TRUE;
            $response["error_msg"] = "Ocorreu um erro ao criar sua conta.\nTente novamente mais tarde.";
            echo json_encode($response);
        }
    }
} else {
    $response["error"] = TRUE;
    $response["error_msg"] = "Informe todos os dados solicitados.";
    echo json_encode($response);
}
?>