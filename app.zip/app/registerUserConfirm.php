<?php

	//Problemas de acentuação, obedecendo ao padrão UTF-8 de todo o sistema
	header('Content-Type: text/html;  charset=utf-8', true);

	/* Ativa a exibição de erros na página */
	/* Ativar apenas para testes pois pode exibir dados sigilosos que o usuário não pode ter acesso */
	//error_reporting(E_ALL);
	//ini_set('display_errors', 1);
	/* Ativa a exibição de erros na página */

	// Define data e hora da atividade no fuso horário brasileiro
	date_default_timezone_set('America/Sao_Paulo');
	$SystemDateTime = date('Y-m-d H:i:s');
	$ano = date('Y');
	
	// Verifica se houve post (Impedir o acesso direto ao newsletterRegisterConfirmation.php)
	if (!empty($_POST) AND (empty($_POST['code']))) {
		echo"<script language='javascript' type='text/javascript'>alert('Nenhum dado foi informado!');window.location.href='/index.php';</script>";
	}
	
	// Parâmetro recebido do formulário na página principal
	$Valida = $_REQUEST['code'];
	
	// Parâmetros de conexão ao banco de dados
	$server = "localhost";
	$username = "3ch0n0m1z4r";
	$PW = "HaY23Zh4QBgN8v42";
	$DB = "3ch0n0m1z4r";

	// Realiza a conexão com o banco de dados
	$connection = mysqli_connect($server, $username, $PW, $DB);
	mysqli_set_charset('UTF8');

	// Verifica se a conexão foi bem-sucedida
	if($connection == false) {
		//die("Erro: " . mysqli_connect_error());
		die("Erro de conexão com o servidor.</br></br>
		Por favor, notifique o suporte!</br>
		Whatsapp: <a href='https://api.whatsapp.com/send?phone=5592994243062&text=Tentei%20ativar%20meu%20cadastro%20no%20sistema%20*Amazon Recycle*%20mas%20o%20servidor%20apresentou%20um%20erro%20de%20conexão%20com%20o%20Banco%20de%20Dados...'>+5592994240362</a></br>
		E-mail: <a href='mailto:ongasvbr@gmail.com?subject=Reportando%20erro%20no%20sistema&body=Tentei%20ativar%20meu%20cadastro%20no%20sistema%20Amazon Recycle%20mas%20o%20servidor%20apresentou%20um%20erro%20de%20conexão%20com%20o%20Banco%20de%20Dados...'>ongasvbr@gmail.com</a></br></br>
		<a href='http://asv.ong.br/amazonrecycle'>Clique aqui para voltar para o site</a>");
		//echo"<script language='javascript' type='text/javascript'>alert('Ocorreu um erro na conexão com o servidor. Tente novamente mais tarde!');window.location.href='index.php';</script>";
	} else {
		echo "Conectado ao Banco de Dados.</br>";
		// Verifica se o e-mail já foi validado
		$sqlSearch = "SELECT * FROM `users` WHERE (`unique_id` = '$Valida') LIMIT 1";
		if(mysqli_query($connection, $sqlSearch) == false) {
			//echo "Não foi possível validar o e-mail informado.</br>";
			die("Não foi possível verificar a conta informada.</br></br>
			Por favor, notifique o suporte!</br>
			Whatsapp: <a href='https://api.whatsapp.com/send?phone=5592994243062&text=Tentei%20ativar%20meu%20cadastro%20no%20sistema%20*Amazon Recycle*%20mas%20o%20servidor%20não%20conseguiu%20%realizar%20a%20%validação%20interna.O%20que%20isto%20significa?'>+5592994240362</a></br>
			E-mail: <a href='mailto:ongasvbr@gmail.com?subject=Reportando%20erro%20no%20sistema&body=Tentei%20ativar%20meu%20cadastro%20no%20sistema%20Amazon Recycle%20mas%20o%20servidor%20não%20conseguiu%20%realizar%20a%20%validação%20interna.O%20que%20isto%20significa?'>ongasvbr@gmail.com</a></br></br>
			<a href='http://asv.ong.br/amazonrecycle'>Clique aqui para voltar para o site</a>");
		} else {
			$resultSearch = mysqli_num_rows(mysqli_query($connection, $sqlSearch));
			if($resultSearch != 0) {
				echo "A conta foi localizada.</br>";
				// Verifica se o cadastro já foi validado
				$sqlObtainStatus = mysqli_fetch_assoc(mysqli_query($connection, $sqlSearch));
				$actived = $sqlObtainStatus['actived'];
				if($actived == 0) { // O e-mail não foi validado
					// Valida o cadastro
					$sqlValida = "UPDATE users SET actived='1', actived_at='$SystemDateTime' WHERE unique_id ='{$Valida}'";
					if(mysqli_query($connection, $sqlValida) == false) {
						//echo "Não foi possível validar o e-mail informado.</br>";
						die("Não foi possível confirmar o cadastro.</br></br>
						Por favor, notifique o suporte!</br>
						Whatsapp: <a href='https://api.whatsapp.com/send?phone=5592994243062&text=Tentei%20confirmar%20meu%20cadastro%20no%20sistema%20*Amazon Recycle*%20usando%20o%20link%20que%20recebi%20mas%20ocorreu%20um%20erro%20ao%20validar%20o%cadastro.'>+5592994240362</a></br>
						E-mail: <a href='mailto:ongasvbr@gmail.com?subject=Reportando%20erro%20no%20sistema&body=Tentei%20confirmar%20meu%20cadastro%20no%20sistema%20Amazon Recycle%20usando%20o%20link%20que%20recebi%20mas%20ocorreu%20um%20erro%20ao%20validar%20o%cadastro.'>ongasvbr@gmail.com</a></br></br>
						<a href='http://asv.ong.br/amazonrecycle'>Clique aqui para voltar para o site</a>");
					} else {
						echo "A conta foi ativada com sucesso.</br>";
						echo"<script language='javascript' type='text/javascript'>alert('Sua inscrição foi completada. Você já pode acessar o sistema... Obrigado!');window.location.href='/index.php';</script>";
					}
				}
				if($actived == 1) { // O e-mail já foi validado
					echo "A conta já estava ativa.</br>";
					echo"<script language='javascript' type='text/javascript'>alert('Sua inscrição já havia sido validada anteriormente. Você já pode acessar o sistema.');window.location.href='/index.php';</script>";
				}
			}
		}

		// Encerra a conexão com o banco de dados
		mysqli_close($connection);
	}

?>