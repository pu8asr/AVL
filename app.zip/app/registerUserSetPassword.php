<?php
require_once 'include/DB_Functions.php';
$db = new DB_Functions();
 
// json response array
$response = array("error" => FALSE);
 
if (isset($_POST['uid']) && isset($_POST['password'])) {
 
    // receiving the post params
    $uuid = utf8_decode($_POST['uid']);
    $password = utf8_decode($_POST['password']);
 
    // Update password
    if ($db->updatePassword($uuid, $password)) {
        // return user data stored successfully
		$response["error"] = FALSE;
		$response["success_msg"] = "Sua senha foi alterada.";
		echo json_encode($response);
    } else {
        // user failed to update
		$response["error"] = TRUE;
		$response["error_msg"] = "Não foi possível alterar sua senha.\nTente novamente mais tarde.";
		echo json_encode($response);
    }
} else {
    // required post params is missing
    $response["error"] = TRUE;
    $response["error_msg"] = "Você não informou a senha.";
    echo json_encode($response);
}
?>