<?php

header("Content-Type: text/html;  charset=UFT-8", true);

// A sessão precisa ser iniciada em cada página diferente
if (!isset($_SESSION)) session_start();

$nivel_necessario = 1;

// Verifica se não há a variável da sessão que identifica o usuário
if (!isset($_SESSION['UsuarioID']) OR ($_SESSION['UsuarioNivel'] < $nivel_necessario)) {
	// Destrói a sessão por segurança
	session_destroy();
	// Redireciona o visitante de volta pro login
	header("Location: login.php"); exit;
}

	// Define as variàveis
	$id_pedido = $_REQUEST['pedido'];
		
	// Conecta ao Banco de Dados
	include "conexao.php";
	
	// Verifica se a solicitação foi gravada
	 if($atende = mysql_query("DELETE FROM pedidos WHERE id='{$id_pedido}'")){
		// if($atende = mysql_query("UPDATE pedidos SET played='1' WHERE id='{$id_pedido}'")){
		echo"<script language='javascript' type='text/javascript'>alert('Pedido atendido.');window.location.href='manager.php';</script>";
	} else {
		echo"<script language='javascript' type='text/javascript'>alert('Erro ao finalizar pedido.');window.location.href='manager.php';</script>";
	}

?>