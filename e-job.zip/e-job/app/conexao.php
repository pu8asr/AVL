<?php

// Tenta se conectar ao servidor MySQL
mysql_connect('localhost', 'ejob', 'kptechjob') or trigger_error(mysql_error());
// Tenta se conectar a um banco de dados MySQL
mysql_select_db('ejob') or trigger_error(mysql_error());

?>