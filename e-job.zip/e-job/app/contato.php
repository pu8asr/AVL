<!DOCTYPE HTML>
<!--
	Ion by TEMPLATED
	templated.co @templatedco
	Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
-->
<html>
	<head>
		<title>Rádio Eletro Mix Digital FM</title>
		<!--
			CODIFICAÇÃO UTF-8 permite conteúdo com acentuação
		-->
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="author" content="Airam - airamcosta@gmail.com" />
		<meta name="description" content="Rádio Eletro Mix Digital, Manaus, Novo Aleixo" />
		<meta name="keywords" content="Radio, Eletro, Digital, Mix, Cristiano Heroz Ferraz" />
		<!--[if lte IE 8]><script src="js/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<link rel="stylesheet" type="text/css" href="css/system.css" />
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
			<link rel="stylesheet" type="text/css" href="css/system.css" />
		</noscript>		
	</head>
	<body id="top">

		<!-- Menu -->
			<header id="header" class="skel-layers-fixed">
				<h1><a href="#">Obrigado por sua audiência</a></h1>
				<nav id="nav">
					<ul>
						<li><a href="pedir.php" target="principal" class="button special">Peça sua música</a></li>
						<li><a href="pedidos.php" target="principal" class="button special">Pedidos</a></li>
						<li><a href="https://goo.gl/Lrzkqn" target="principal" class="button special">Whatsapp Group</a></li>
					</ul>
				</nav>
			</header>
			
		<!-- Body -->
			<font color="Black">
			
			<h2>Formulário de contato</h2>
		<center>
			
			<form class="form" action="enviar_email.php" width="30" method="post">
			<fieldset>
				<legend>Informe seus dados</legend></br>
					<label>Nome: 
						<input type="text" name="nome" id="nome" class="btmspace-15" maxlength="30" placeholder="Nome e Sobrenome por favor" autofocus required />
					</label>
					<label>E-mail: 
						<input type="text" name="email" id="email" class="btmspace-15" maxlength="70" placeholder="E-mail válido por favor" required />
					</label>
					<label>Telefone: 
						<input type="text" name="telefone" id="telefone" class="btmspace-15" maxlength="40" placeholder="Whatsapp preferencialmente e informe o DDD" required />
					</label>
					<label>Mensagem: 
						<textarea rows="7" cols="30" type="text" name="mensagem" id="mensagem" class="btmspace-15" maxlength="300" placeholder="Digite a sua mensagem aqui por favor" required /></textarea>
					</label>
			
					<!-- Botão -->
					<center></br>
						<input type="submit" class="submit" value=" Enviar "/>
					</center>

			</form>
		
		</center>
		</font></br></br></br></br></br></br></br></br>

	</body>
</html>