<?php

$nome = mysql_real_escape_string($_POST['nome']);
$email = mysql_real_escape_string($_POST['email']);
$telefone = mysql_real_escape_string($_POST['telefone']);
$mensagem = mysql_real_escape_string($_POST['mensagem']);

// Função que envia e-mail pelo PHPMailer usando Yahoo
 function sendEmail($FromEmail,$Subject,$Message,$FromName,$ToEmail) {
 
		 require ("PHPMailer/class.phpmailer.php");
		 
		 $mail = new PHPMailer();
		 
		 $mail->From     = $FromEmail;
		 $mail->FromName = $FromName;
		 
		 $mail->IsSMTP(); 
		 
		 $mail->SMTPAuth = true;     // turn of SMTP authentication
		 $mail->Username = "airam_costa@yahoo.com.br";  // SMTP username
		 $mail->Password = "Carpe Diem"; // SMTP password
		 $mail->SMTPSecure = "ssl";
		
		 $mail->Host = "smtp.mail.yahoo.com";
		 $mail->Port = 465;
		 
		 $mail->SMTPDebug  = 2; // Enables SMTP debug information (for testing, remove this line on production mode)
		 // 1 = errors and messages
		 // 2 = messages only
		  
		 $mail->Sender   =  $FromEmail;// $bounce_email;
		 $mail->ConfirmReadingTo  = $FromEmail;
		 
		 $mail->AddReplyTo($FromEmail);
		 $mail->IsHTML(true); //turn on to send html email
		 $mail->Subject = $Subject;
		
		 $mail->Body     =  $Message;
		 $mail->AltBody  =  "ALTERNATIVE MESSAGE FOR TEXT WEB BROWSER LIKE SQUIRRELMAIL";
		 
		 $mail->AddAddress($ToEmail,$ToEmail);
			   
		 if($mail->Send()){
		  $mail->ClearAddresses();
		  echo"<script language='javascript' type='text/javascript'>alert('Obrigado pelo contato! Responderemos em breve...');window.location.href='pedidos.php';</script>";
		 } else {
			 echo"<script language='javascript' type='text/javascript'>alert('Ocorreu um erro! Tente mais tarde...');window.location.href='pedidos.php';</script>";
		 }
 
 }
 
 //if(empty($nome)){
	 //echo"<script language='javascript' type='text/javascript'>alert('Por favor informe seu nome.');window.location.href='contato.php';</script>";
 //} else
 //if (empty($email)){
	 //echo"<script language='javascript' type='text/javascript'>alert('Por favor informe seu e-mail.');window.location.href='contato.php';</script>";
 //} else
 //if (empty($telefone)){
	 //echo"<script language='javascript' type='text/javascript'>alert('Por favor informe seu telefone para contato.');window.location.href='contato.php';</script>";
 //} else
 //if (empty($mensagem)){
	 //echo"<script language='javascript' type='text/javascript'>alert('Qual o motivo do seu contato?');window.location.href='contato.php';</script>";
 //} else {
	 // Enviar um email ao usuário para confirmação e ativar o cadastro! (define apenas a mensagem)
	 $FromEmail	=	'airam_costa@yahoo.com.br';
	 $Subject	=	'Contato realizado pelo App Radio Eletro Mix';
	 $MessageCadastro	=	'Você recebeu uma mensagem de '.$nome.',<br />
							E-mail: '.$email.',<br />
							Telefone: '.$telefone.',<br />
							Mensagem: </br>'.$mensagem.'</br>';
	 $FromName	=	'App Radio Eletro Mix';
	 $ToEmail	=	'fabricadepublicidade@hotmail.com';
	 sendEmail($FromEmail,$Subject,$MessageCadastro,$FromName,$ToEmail);
 //}
	 

?>