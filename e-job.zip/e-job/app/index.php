<?php

	//Problemas de acentuação, obedecendo ao padrão UTF-8 de todo o sistema
	header('Content-Type: text/html;  charset=utf-8', true);

	/* Ativa a exibição de erros na página */
	/* Ativar apenas para testes pois pode exibir dados sigilosos que o usuário não pode ter acesso */
	//error_reporting(E_ALL);
	//ini_set('display_errors', 1);
	/* Ativa a exibição de erros na página */
	
	// Define data e hora da atividade no fuso horário brasileiro
	date_default_timezone_set('America/Manaus');
	$ano = date('Y');
	
?>

<!DOCTYPE html>
<html lang="pt-BR">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="KurupyraTech" />
	<meta name="description" content="Sistema de Gerenciamento de Chamados HelpDesk" />
	<meta name="keywords" content="HelpDesk, Chamados, Gerenciador, Sistema" />
    <meta name="authorUrl" content="http://kurupyratech.ddns.net">
    <link rel="icon" href="assets/img/favicon.ico">

    <title>e-Job KurupyraTech</title>
</head>

<frameset rows="40,*" framespacing="0" border="0" frameborder="0">
  <frame src="http://streaming08.hstbr.net/player/fabricadepublicidade" noresize scrolling="no" name="frameradio" id="frameradio" />
  <frame src="pedidos.php" noresize scrolling="auto" name="principal" id="principal" />
  <noframes>
  <body>

  <p>Esta página usa quadros mas seu navegador não aceita quadros.</p>

  </body>
  </noframes>

</html>
