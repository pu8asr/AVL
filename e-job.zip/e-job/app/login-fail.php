<!DOCTYPE HTML>
<!--
	Ion by TEMPLATED
	templated.co @templatedco
	Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
-->
<html>
	<head>
		<title>e-Job</title>
		<!--
			CODIFICAÇÃO UTF-8 permite conteúdo com acentuação
		-->
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="author" content="KurupyraTech" />
		<meta name="description" content="Sistema de Gerenciamento de Chamados HelpDesk" />
		<meta name="keywords" content="HelpDesk, Chamados, Gerenciador, Sistema" />
		<meta name="authorUrl" content="http://kurupyratech.ddns.net">
		<!--[if lte IE 8]><script src="js/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<link rel="stylesheet" type="text/css" href="css/system.css" />
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
		</noscript>		
	</head>
	<body id="top">

		<!-- Header -->
			<header id="header" class="skel-layers-fixed">
				<img width="100px" height="50px" src="logo-mobile.jpg">
				<!--<h1><a href="#">e-Job</a></h1>-->
				<nav id="nav">
					<ul>
						<li><a href="manager.php" target="_self" class="button special">Acessar Sistema</a></li>
					</ul>
				</nav>
			</header>

		<!-- One -->
			<section id="one" class="wrapper style1">
				<header class="major">
					<h2>Falha ao logar</h2>
					<p>Os dados informados são inválidos</p>
					<p align="center">
						<!-- <a href="password-recovery.php" target="_self" class="link">Recuperar dados de acesso</a> -->
					</p>
				</header>
			</section>
			
		<!-- Footer -->
			<footer id="footer">
				<div class="container">
					
					<ul class="copyright">
						<li>KurupyraTech &copy; <?php echo $data = date("Y"); ?>.</br>Todos os direitos reservados.</li>
					</ul>
				</div>
			</footer>

	</body>
</html>