<?php
	header("Content-Type: text/html;  charset=ISO-8859-1", true);
?>

<!DOCTYPE HTML>
<!--
	Ion by TEMPLATED
	templated.co @templatedco
	Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
-->
<html>
	<head>
		<title>e-Job</title>
		<!--
			CODIFICA��O UTF-8 permite conte�do com acentua��o
		-->
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="author" content="KurupyraTech" />
		<meta name="description" content="Sistema de Gerenciamento de Chamados HelpDesk" />
		<meta name="keywords" content="HelpDesk, Chamados, Gerenciador, Sistema" />
		<meta name="authorUrl" content="http://kurupyratech.ddns.net">
		<!--[if lte IE 8]><script src="js/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<link rel="stylesheet" type="text/css" href="css/system.css" />
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
			<link rel="stylesheet" type="text/css" href="css/system.css" />
		</noscript>		
	</head>
	<body id="top">

		<!-- One -->
			<section id="one" class="wrapper style1">
				<header class="major">
					<center>
					<img src="logo-mobile.jpg">
						<form class="form" action="valida_login.php" method="post">
							<fieldset>
								<legend>Informe seus dados de acesso</legend></br>
									<label>Usu�rio: 
										<input type="text" name="usuario" id="txUsuario" class="entrada" maxlength="25" placeholder="Digite seu usu�rio aqui" autofocus/>
									</label>
									<label>Senha: 
										<input type="password" name="senha" id="txSenha" class="entrada" maxlength="40" placeholder="******" />
									</label>
			
								<!-- Bot�o -->
								<center>
									<input type="submit" class="submit" value="ENTRAR"/>
								</center>
								<p align="center"></br>
									<!-- <a href="password-recovery.php" target="_self" class="link">Recuperar dados de acesso</a> -->
								</p>
								<center><h4><font color="blue"><a href='http://kurupyratech.ddns.net' target='_blank'><strong>Powered By KurupyraTech</strong></a></font></h4></center>
						</form>
					</center>
				</header>
			</section>			
			
		<!-- Footer -->
			<footer id="footer">
				<div class="container">
					
					<ul class="copyright">
						<li>KurupyraTech &copy; <?php echo $data = date("Y"); ?>.</br>Todos os direitos reservados.</li>
					</ul>
				</div>
			</footer>

	</body>
</html>