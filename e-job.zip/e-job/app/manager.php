<?php

header("Content-Type: text/html;  charset=UFT-8", true);

// A sessão precisa ser iniciada em cada página diferente
if (!isset($_SESSION)) session_start();

$nivel_necessario = 1;

// Verifica se não há a variável da sessão que identifica o usuário
if (!isset($_SESSION['UsuarioID']) OR ($_SESSION['UsuarioNivel'] < $nivel_necessario)) {
	// Destrói a sessão por segurança
	session_destroy();
	// Redireciona o visitante de volta pro login
	header("Location: login.php"); exit;
}

	include "conexao.php";

?>

<!DOCTYPE HTML>
<!--
	Ion by TEMPLATED
	templated.co @templatedco
	Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
-->
<html>
	<head>
		<title>e-Job</title>
		<!--
			CODIFICAÇÃO UTF-8 permite conteúdo com acentuação
		-->
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="author" content="KurupyraTech" />
		<meta name="description" content="Sistema de Gerenciamento de Chamados HelpDesk" />
		<meta name="keywords" content="HelpDesk, Chamados, Gerenciador, Sistema" />
		<meta name="authorUrl" content="http://kurupyratech.ddns.net">
		<!--[if lte IE 8]><script src="js/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<link rel="stylesheet" type="text/css" href="css/system.css" />
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
			<link rel="stylesheet" type="text/css" href="css/system.css" />
		</noscript>		
	</head>
	<body id="top">

		<!-- Menu -->
			<header id="header" class="skel-layers-fixed">
				<img width="100px" height="50px" src="logo-mobile.jpg">
				<!--<h1><a href="#">e-Job</a></h1>-->
				<nav id="nav">
					<ul>
					<?php
						if ($_SESSION['UsuarioNivel'] == 1){
							//echo '<li><a href="logout.php" target="principal" class="button special">Sair do sistema</a></li>';
						};
						if ($_SESSION['UsuarioNivel'] == 2){
							//echo '<li><a href="regiterJob.php" target="principal" class="button special">Abrir chamado</a></li>';
						};
						if ($_SESSION['UsuarioNivel'] == 3){
							echo '<li><a href="regiterJob.php" target="principal" class="button special">Abrir chamado</a></li>';
						};
						if ($_SESSION['UsuarioNivel'] == 4){
							echo '<li><a href="managerClientes.php" target="principal" class="button special">Gerenciar Clientes</a></li>';
							echo '<li><a href="managerOperadores.php" target="principal" class="button special">Gerenciar Operadores</a></li>';
						};
					?>
						<li><a href="logout.php" target="principal" class="button special">Sair do sistema</a></li>
					</ul>
				</nav>
			</header>
			
		<!-- Body -->
			<font color="Black">

		<h2>Solicitações</h2>
		<center>
		<?php

			$sql = "SELECT * FROM pedidos WHERE played=0 ORDER BY data DESC";
			$query = mysql_query($sql);
			$num_pedidos = mysql_num_rows($query);
			
			if ($num_pedidos != 0){
				echo "<table><tr><td><strong>Nome</strong></td><td><strong>Local</strong></td><td><strong>Música</strong></td><td><strong>Artista</strong></td><td><strong>Dedicatória</strong></td><td><strong>Data</strong></td><td><center><strong>Atender</strong></center></td></tr>";
				while($linha = mysql_fetch_array($query)){
						$imagem = "atender.png";
						$link = "atender.php?pedido=";
					echo '<tr><td>' . $linha['nome'] . '</td><td>' . $linha['local'] . '</td><td>' . $linha['musica'] . '</td><td>' . $linha['artista'] . '</td><td>' . $linha['dedicatoria'] . '</td><td>' . $linha['data'] . '</td><td><center><a href="' . $link . $linha['id'] . '"><img src="' . $imagem . '"></a></center>       </td></tr>';
				}
				echo "</table>";
				
				?>
				</br>
				<h4><font color="blue"><a href='http://kurupyratech.ddns.net' target='_blank'><strong>Powered By KurupyraTech</strong></a></font></h4>
		<?php
			} else {
				echo "<center>";
				echo "<h3><font color='blue'>Não temos chamados abertos</font></h3>";
				//echo "<h4><font color='blue'><a href='pedir.php' target='_self'><strong>Peça a sua música agora!</strong></a></font></h4>";
				echo "</center>";
			}
			
			echo "<meta HTTP-EQUIV='refresh' CONTENT='30;URL=manager.php'>";
		?>
		</center>
		</font>

	</body>
</html>