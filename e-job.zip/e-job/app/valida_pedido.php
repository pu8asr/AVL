<?php

	// Define as variàveis
	$nome = $_POST['nome'];
	$local = $_POST['local'];
	$musica = $_POST['musica'];
	$artista = $_POST['artista'];
	$dedicatoria = $_POST['dedicatoria'];
	//Insere no banco de dados a data do cadastro
	//date_default_timezone_set('America/Sao_Paulo');
    //$data_sistema = date('Y-m-d H:i:s');
	
//	if(empty($nome)){
//		echo"<script language='javascript' type='text/javascript'>alert('Por favor, informe seu nome!');window.location.href='pedr.php';</script>";
//	} elseif(empty($localidade)){
//		echo"<script language='javascript' type='text/javascript'>alert('Gostariamos de saber onde temos ouvintes. Poderia nos ajudar?');window.location.href='pedr.php';</script>";
//	} elseif(empty($musica)){
//		echo"<script language='javascript' type='text/javascript'>alert('Que musica voce gostaria de ouvir aqui?');window.location.href='pedr.php';</script>";
//	} else {
		
		// Conecta ao Banco de Dados
	include "conexao.php";
	
	// Verifica se a solicitação foi gravada
	$sql = "INSERT INTO pedidos(nome, local, musica, artista, dedicatoria) VALUES ('$nome', '$local', '$musica', '$artista', '$dedicatoria')";
	if (mysql_query($sql)){
		echo"<script language='javascript' type='text/javascript'>alert('Recebemos seu pedido.');window.location.href='pedidos.php';</script>";
	} else {
		echo"<script language='javascript' type='text/javascript'>alert('Tente novamente mais tarde.');window.location.href='pedr.php';</script>";
	}
		
//	}

?>