<?php
 
/**
 * Database config variables
 */
define('DB_HOST', "localhost");
define('DB_USER', "3ch0n0m1z4r");
define('DB_PASSWORD', "HaY23Zh4QBgN8v42");
define('DB_DATABASE', "3ch0n0m1z4r");
?>