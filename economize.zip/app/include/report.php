<?php
// Mensagens de alertas e erros
DEFINE ('DB_CONNECTION_ERROR', 'Erro de conexão com o servidor.</br></br>
	Por favor, notifique o suporte!</br>
	Whatsapp: <a href="https://api.whatsapp.com/send?phone=5592994243062&textOi%20Suporte%20Economize,%20o%20servidor%20está%20com%20erro%20de%20conexão...">+5592994240362</a></br>
	E-mail: <a href="mailto:economize.suporte@gmail.com?subject=Oi%20Suporte%20Economize,%20o%20servidor%20está%20com%20erro%20de%20conexão...">economize.suporte@gmail.com</a>');

DEFINE ('VALIDATION_DATA_ERROR', 'Não foi possível validar o e-mail informado.</br></br>
	Por favor, notifique o suporte!</br>
	Whatsapp: <a href="https://api.whatsapp.com/send?phone=5592994243062&textOi%20Suporte%20Economize,%20o%20servidor%20está%20com%20erro%20de%20conexão...">+5592994240362</a></br>
	E-mail: <a href="mailto:economize.suporte@gmail.com?subject=Oi%20Suporte%20Economize,%20o%20servidor%20está%20com%20erro%20de%20conexão...">economize.suporte@gmail.com</a>');
?>