<?php

	//Problemas de acentuação, obedecendo ao padrão UTF-8 de todo o sistema
	header('Content-Type: text/html;  charset=utf-8', true);

	/* Ativa a exibição de erros na página */
	/* Ativar apenas para testes pois pode exibir dados sigilosos que o usuário não pode ter acesso */
	//error_reporting(E_ALL);
	//ini_set('display_errors', 1);
	/* Ativa a exibição de erros na página */
	
	// Define data e hora da atividade no fuso horário brasileiro
	date_default_timezone_set('America/Sao_Paulo');
	$ano = date('Y');
	
	// Verifica se houve post (Impedir o acesso direto ao contactForm.php)
	if (!empty($_POST) AND (empty($_POST['name']) OR empty($_POST['email']) OR empty($_POST['telephone']) OR empty($_POST['subject']) OR empty($_POST['message']))) {
		//echo"<script language='javascript' type='text/javascript'>alert('Nome, E-mail, Assunto e Mensagem são necessários!');window.location.href='index.php';</script>";
		die('Todos os campos são necessários!');
	}

	/* Este trecho foi substituído pelo trecho acima que verifica se houve post, evitando acesso direto ao contactForm.php
	if( file_exists($php_mail_form_library = 'PHPMailer/class.phpmailer.php' )) {
		include( $php_mail_form_library );
	} else {
		//die( 'Unable to load the PHP Mail Form Library!');
		die("Não podemos receber sua mensagem no momento.</br></br>
		Por favor, notifique o suporte!</br>
		Whatsapp: <a href='https://api.whatsapp.com/send?phone=5592994243062&text=Oi%20Suporte%20Economize,%20o%20formulário%20de%20contato%20do%20site%20está%20com%20erros'>+5592994240362</a></br>
		E-mail: <a href='mailto:economize.suporte@gmail.com?subject=Erro%20no%20formulário%20de%20contato%20do%20site'>economize.suporte@gmail.com</a>");
	}
	*/
	
	$Nome = htmlentities($_POST['name']);
	$Correio = $_POST['email'];
	$Telefone = $_POST['telephone'];
	$Assunto = htmlentities($_POST['subject']);
	$Texto = htmlentities($_POST['message']);
	$MsgMontada = '<div>Voc&ecirc; recebeu uma mensagem enviada por um visitante do site <strong><a href="http://economize.net.br">Economize</a></strong>.</div>
	<div><h3>Segue os detalhes</h3></div>
	<div><strong>Nome:</strong> '.$Nome.'</div>
	<div><strong>E-mail:</strong> <a href="mailto:'.$Correio.'?subject=Economize%20-%20Resposta%20da%20sua%20solicita&ccedil;&atilde;o">'.$Correio.'</a> <i>(clique no e-mail para responder)</i></div>
	<div><strong>Tefefone:</strong> <a href="https://api.whatsapp.com/send?phone=55'.$Telefone.'&text=Ol&aacute;%20'.$Nome.'!%20Estou%20entrando%20em%20contato%20para%20tratar%20da%20sua%20solicita&ccedil;&atilde;o%20feita%20pelo%20formul&aacute;rio%20de%20contao%20no%20site%20Economize.">'.$Telefone.'</a> <i>(clique no n&uacute;mero, se houver, para responder pelo Whatsapp)</i></div>
	<div><strong>Assunto:</strong> '.$Assunto.'</div>
	<div><strong>Mensagem:</strong> '.$Texto.'</div>
	<div>
		<strong><h4><a href="http://economize.net.br/">Economize</a> &copy; '.$ano.'</strong>
		<div>Todos os direitos reservados!</div></h4>
	</div>';
	
	// Enviar um email ao usuário para confirmação de cadastro ativo
	require ('app/include/PHPMailer/class.phpmailer.php');
	$mail = new PHPMailer();
	$ToEmail = 'economize.suporte@gmail.com';
	$mail->CharSet = 'UTF-8';
	$mail->From = 'airam_costa@yahoo.com.br';
	$mail->FromName = 'Economize';
	$mail->IsSMTP();
	$mail->SMTPAuth = true; // turn of SMTP authentication
	$mail->Username = 'airam_costa@yahoo.com.br'; // SMTP username
	$mail->Password = 'Carpe Diem'; // SMTP password
	$mail->SMTPSecure = 'ssl';
	$mail->Host = 'smtp.mail.yahoo.com';
	$mail->Port = 465;
	//$mail->SMTPDebug = 2; // Enables SMTP debug information (for testing, remove this line on production mode)
	// 1 = errors and messages
	// 2 = messages only
	$mail->Sender = 'airam_costa@yahoo.com.br'; // $bounce_email;
	$mail->ConfirmReadingTo = 'airam_costa@yahoo.com.br';
	$mail->AddReplyTo('airam_costa@yahoo.com.br');
	$mail->IsHTML(true); //turn on to send html email
	$mail->Subject = 'Contato realizado pelo site';
	$mail->Body = $MsgMontada;
	$mail->AltBody = $MsgMontada;
	$mail->AddAddress($ToEmail,$ToEmail);
	if($mail->Send()){
		$mail->ClearAddresses();
		die('Sua mensagem foi enviada. Obrigado!');
	} else {
		die('Não conseguimos enviar sua mensagem.</br></br>
		Alternativamente, você pode enviar uma mensagem pelos canais abaixo.</br>
		Whatsapp: <a href="https://api.whatsapp.com/send?phone=5592994243062&text=Oi%20Suporte%20Economize,%20Estou%20enviando%20esta%20mensagem%20pelo%20Whatsapp%20porque%20não%20consegui%20enviar%20pelo%20formulário%20de%20contato%20do%20site">+5592994240362</a></br>
		E-mail: <a href="mailto:economize.suporte@gmail.com?subject=Reportando%20erro%20no%20sistema&body=Estou%20enviando%20este%20e-mail%20porque%20não%20consegui%20enviar%20pelo%20formulário%20de%20contato%20do%20site">economize.suporte@gmail.com</a>');
	}

?>