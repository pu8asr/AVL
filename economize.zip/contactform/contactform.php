<?php
  /**
  * Requires the PHP Mail Form library
  * The PHP Mail Form library is available only in the pro version of the template
  * The library should be uploaded to: lib/php-mail-form/php-mail-form.php
  * For more info and help: https://templatemag.com/php-mail-form/
  */
  // Verifica se houve POST e se o usuário ou a senha é(são) vazio(s)
if (!empty($_POST) AND (empty($_POST['name']) or empty($_POST['email']) or empty($_POST['subject']) or empty($_POST['message']))) {
	die('Todos os campos devem ser informados');
} else {
  
/* Início da função que envia e-mail pelo PHPMailer usando Yahoo */
 function sendEmailContact($FromEmail,$Subject,$Message,$FromName,$ToEmail) {
	 require ("/PHPMailer/class.phpmailer.php");
		 
	$mail = new PHPMailer();
		 
	$mail->From     = $FromEmail;
	$mail->FromName = $FromName;
		 
	$mail->IsSMTP(); 
		 
	$mail->SMTPAuth = true;     // turn of SMTP authentication
	$mail->Username = "airam_costa@yahoo.com.br";  // SMTP username
	$mail->Password = "Carpe Diem"; // SMTP password
	$mail->SMTPSecure = "ssl";
		
	$mail->Host = "smtp.mail.yahoo.com";
	$mail->Port = 465;
		 
	//$mail->SMTPDebug  = 2; // Enables SMTP debug information (for testing, remove this line on production mode)
	// 1 = errors and messages
	// 2 = messages only
		  
	$mail->Sender   =  $FromEmail;// $bounce_email;
	$mail->ConfirmReadingTo  = $FromEmail;
		 
	$mail->AddReplyTo($FromEmail);
	$mail->IsHTML(true); //turn on to send html email
	$mail->Subject = $Subject;
		
	$mail->Body     =  $Message;
	$mail->AltBody  =  "Formulário de contato site Economize SQUIRRELMAIL";
		 
	$mail->AddAddress($ToEmail,$ToEmail);
			   
	if($mail->Send()){
		$mail->ClearAddresses();
		die('Sua mensagem foi enviada!');
	}
}
/* Fim da função que envia e-mail pelo PHPMailer usando Yahoo */

	$name = mysql_real_escape_string($_POST['name']);
	$email = mysql_real_escape_string($_POST['name']);
	$subject = mysql_real_escape_string($_POST['subject']);
	$message = mysql_real_escape_string($_POST['message']);
	
	// Enviar um email ao usuário para confirmação de cadastro ativo
	$FromEmail	=	$email;
	$Subject	=	$subject;
	$Message	=	$message;
	$FromName	=	$name;
	$ToEmail	=	$email;
		
	// Envia o e-mail
	$response  = sendEmailContact($FromEmail,$Subject,$Message,$FromName,$ToEmail);

}

?>
