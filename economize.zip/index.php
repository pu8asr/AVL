<?php

	//Problemas de acentuação, obedecendo ao padrão UTF-8 de todo o sistema
	header('Content-Type: text/html;  charset=utf-8', true);

	/* Ativa a exibição de erros na página */
	/* Ativar apenas para testes pois pode exibir dados sigilosos que o usuário não pode ter acesso */
	//error_reporting(E_ALL);
	//ini_set('display_errors', 1);
	/* Ativa a exibição de erros na página */
	
	// Define data e hora da atividade no fuso horário brasileiro
	date_default_timezone_set('America/Sao_Paulo');
	$ano = date('Y');
	
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>

  <!-- Publicidade - Google Adsense -->
  <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
  <script>
     (adsbygoogle = window.adsbygoogle || []).push({
          google_ad_client: "ca-pub-2373559965014283",
          enable_page_level_ads: true
     });
  </script>

  <!-- Global site tag (gtag.js) - Google Analytics -->
  <script async src="https://www.googletagmanager.com/gtag/js?id=G-99RHM56TPS"></script> <script> window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', 'G-99RHM56TPS'); </script>

  <title>Economize</title>
  <meta charset="utf-8">
  <!--<meta http-equiv="Content-Type" content="text/html charset=utf-8">
  <meta http-equiv="Content-Language" content="pt-BR">-->
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="economize, android, app, preços, compras, produtos, estabelecimentos, economia, pechincha, pesquisa, consulta" name="keywords">
  <meta content="Economize é uma rede onde os usuários cooperam mutuamente informando valores de produtos e avaliando estabelecimentos, tornando mais ágil a pesquisa de preços antes e durante as compras." name="description">

  <!-- Favicons -->
  <link href="img/favicon.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="lib/ionicons/css/ionicons.min.css" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="css/style.css" rel="stylesheet">

  <!-- Aviso da Política de Privacidade  e Termos de Uso -->
  <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/cookieconsent@3/build/cookieconsent.min.css" />
  
</head>

<body>
  <div id="h">
    <div class="container">
      <div class="row">
        <div class="col-md-8 col-md-offset-2">
		<h1>FALTAM APENAS</h1>
          <div class="countdown-header">
            <div class="countdown" data-date="2019/12/01"></div>
          </div>
          <h1>PARA <bold>VOCÊ</bold> ECONOMIZAR</h1>
        </div>
      </div>
      <!--/row-->
      <div class="row">
        <div class="col-md-4 col-md-offset-4">
          <img src="img/phones.png" class="img-responsive aligncenter" alt="">
        </div>
      </div>
      <!--/row-->
    </div>
    <!--/container-->
  </div>
  <!--/H-->

  <div id="g">
    <div class="container">
      <div class="row">
        <div class="col-md-8 col-md-offset-2 centered">
          <h2>Estamos trabalhando duro para disponibilizar esta poderosa ferramenta de economia para você.</h2>
          <div class="col-md-6 col-md-offset-3">
            <form role="form" action="newsletterRegister.php" method="post" enctype="plain">
              <input type="text" name="email" id="txEmail" class="subscribe-input" value="" onblur="checarEmail();" onkeyup="minuscula(this)" placeholder="Informe seu e-mail..." required>
              <button class='btn btn-conf btn-go' type="submit" name="submit">Avise-me quando estiver pronto</button>
            </form>
          </div>
        </div>
        <!--/col-md-8-->
      </div>
      <!--/row-->
    </div>
    <!--/container-->
  </div>
  <!--/G-->

  <div class="container ptb">
    <div class="row centered">
      <div class="col-md-4">
        <i class="ion-ios7-bolt-outline"></i>
        <h4>INOVADOR</h4>
        <p>Engenharia social para possibilitar que você economize de verdade.</p>
      </div>
      <!--/col-md-4-->
      <div class="col-md-4">
        <i class="ion-ios7-infinite-outline"></i>
        <h4>ILIMITADO</h4>
        <p>Utilize quando quiser, onde quiser e pelo tempo que quiser gratuitamente.</p>
      </div>
      <!--/col-md-4-->
      <div class="col-md-4">
        <i class="ion-ios7-glasses-outline"></i>
        <h4>ECONOMIA</h4>
        <p>O trabalho de pesquisar preços antes e durante as compras é agilizado.</p>
      </div>
      <!--/col-md-4-->
    </div>
    <!--/row-->
  </div>
  <!--/container-->

  <div id="contact">
    <div class="container">
      <div class="row">
        <div class="col-md-8 col-md-offset-2">
          <h2 class="centered">Formulário de contato</h2>
          <form class="contact-form php-mail-form" role="form" action="contactForm.php" method="POST">

            <div class="form-group">
              <input type="name" name="name" class="form-control" id="contact-name" placeholder="Seu nome" maxlength="30" data-rule="minlen:4" data-msg="Digite pelo menos 4 caracteres" >
              <div class="validate"></div>
            </div>
            <div class="form-group">
              <input type="email" name="email" class="form-control" id="contact-email" onblur="checarEmail();" onkeyup="minuscula(this)" placeholder="Seu e-mail" maxlength="50" data-rule="email" data-msg="Por favor digite um e-mail válido">
			  <input type="telephone" name="telephone" class="form-control" id="contact-telephone" onkeypress="return SomenteNumero(event)" placeholder="Seu Whatsapp com DDD" maxlength="11" data-rule="minlen:11" data-msg="Todo número no Brasil (com DDD) é composto por 11 números">
              <div class="validate"></div>
            </div>
            <div class="form-group">
              <input type="text" name="subject" class="form-control" id="contact-subject" placeholder="Assunto" maxlength="300" data-rule="minlen:8" data-msg="Por favor digite pelo menos 8 caracteres">
              <div class="validate"></div>
            </div>

            <div class="form-group">
              <textarea class="form-control" name="message" id="contact-message" placeholder="Sua Mensagem" rows="5" data-rule="required" data-msg="Por favor escreva algo para nós"></textarea>
              <div class="validate"></div>
            </div>

            <div class="loading"></div>
            <div class="error-message">Ocorreu um erro. Desculpe!</div>
            <div class="sent-message">Sua mensagem foi enviada. Obrigado!</div>

            <div class="form-send">
              <button type="submit" class="btn btn-large">Enviar</button>
            </div>

          </form>

        </div>
      </div>
    </div>
  </div>
  <!-- / contact -->
  
  <!-- knowledge -->
  <div class="container ptb">
    <div class="row centered">
		<div class="col-md-8 col-md-offset-2 centered">
			<h2>Base de Conhecimento</h2></br>
		</div>
		<?php
			// Parâmetros de conexão ao banco de dados
			$server = "localhost";
			$username = "3ch0n0m1z4r";
			$PW = "HaY23Zh4QBgN8v42";
			$DB = "3ch0n0m1z4r";

			// Realiza a conexão com o banco de dados
			$connection = mysqli_connect($server, $username, $PW, $DB);
			mysqli_set_charset('UTF8');

			// Verifica se a conexão foi bem-sucedida
			if($connection == false) {
				echo '<div class="col-md-6 col-md-offset-3">';
				echo '<h4>Erro de conexão com o servidor</h4>';
				echo '<div class="row">';
				echo '<p>Por favor, utilize o formulário acima ou as informações a seguir para notificar o suporte!</p>';
				echo '<p align="justify">Whatsapp: <a href="https://api.whatsapp.com/send?phone=5592994243062&text=Ocorreu%20um%20erro%20de%20conexão%20com%20o%20banco%20de%20dados%20ao%20tentar%20carregar%20a%20base%20de%20conhecimento%20do%20sistema%20*Economize*%20na%20página%20inicial%20do%20site.">+5592994240362</a></p>';
				echo 'E-mail: <a href="mailto:economize.suporte@gmail.com?subject=Reportando%20erro%20no%20sistema&body=Ocorreu%20um%20erro%20de%20conexão%20com%20o%20banco%20de%20dados%20ao%20tentar%20carregar%20a%20base%20de%20conhecimento%20do%20sistema%20Economize%20na%20página%20inicial%20do%20site.">economize.suporte@gmail.com</a></p>';
				echo '</div>';
				echo '</div>';
			} else {
				// Busca as informações da tabela knowledge
				$sqlSearch = "SELECT * FROM `knowledge`";
				$querySearch = mysqli_query($connection, $sqlSearch);
				if($querySearch == false) {
					echo '<div class="col-md-6 col-md-offset-3">';
					echo '<h4>Não foi possível obter a base de conhecimento</h4>';
					echo '<div class="row">';
					echo '<p>Por favor, utilize o formulário acima ou as informações a seguir para notificar o suporte!</p>';
					echo '<p align="justify">Whatsapp: <a href="https://api.whatsapp.com/send?phone=5592994243062&text=Ocorreu%20um%20erro%20ao%20carregar%20a%20base%20de%20conhecimento%20do%20sistema%20*Economize*%20na%20página%20inicial%20do%20site.">+5592994240362</a></p>';
					echo '<p>E-mail: <a href="mailto:economize.suporte@gmail.com?subject=Reportando%20erro%20no%20sistema&body=Ocorreu%20um%20erro%20ao%20carregar%20a%20base%20de%20conhecimento%20do%20sistema%20Economize%20na%20página%20inicial%20do%20site.">economize.suporte@gmail.com</a></p>';
					echo '</div>';
					echo '</div>';
				} else {
					// Verifica se há informações disponíveis
					$knowledgeCount = mysqli_num_rows($querySearch);
					if($knowledgeCount != 0) {
						while($row = mysqli_fetch_array($querySearch)){
							$id = $row['id'];
							$pergunta = utf8_encode($row['item']);
							$resposta = utf8_encode($row['description']);
							echo '<div class="col-md-6 col-md-offset-3" onclick="ocultarExibir('.$id.');">';
							echo '<h4>'.$pergunta.'</h4>';
							echo '<div class="ion-ios7-bolt-outline" id='.$id.' style="display:none"><p align="justify">'.$resposta.'</p></div>';
							echo '</div>';
						}
					} else {
						echo '<h4>Não há informações disponíveis!</h4>';
						echo '<p>Utilize o formulário acima para enviar dúvidas, críticas e/ou sugestões.</p>';
						echo '<p>Sua mensagem poderá ser incluída na base de conhecimento.</p>';
						echo '<p>Afinal de contas, a sua dúvida pode ser a dúvida de mais alguém, não é mesmo?!.</p>';
					}
				}
			}
		?>
    </div>
    <!--/row-->
  </div>
  <!--/knowledge-->

  <div id="copyrights">
    <div class="container">
      <p><strong><a href="http://economize.net.br/">Economize</a></strong> &copy; <?php echo $ano; ?></br>Todos os direitos reservados</p>
      <div class="credits">
        <!--<p>Desenvolvido e Hospedado por <a href="http://kurupyratech.ddns.net/">KurupyraTech</a></p>-->
		<p><a href="http://kurupyratech.ddns.net/politica-de-privacidade.php" target="_blank">Política de Privacidade</a> | <a href="http://kurupyratech.ddns.net/termos-de-uso.php" target="_blank">Termos de Uso</a></p>
      </div>
    </div>
  </div>
  <!-- / copyrights -->

  <!-- JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.min.js"></script>
  <script src="lib/php-mail-form/validate.js"></script>
  <script src="lib/countdown/jquery.plugin.min.js"></script>
  <script src="lib/countdown/jquery.countdown.min.js"></script>

  <!-- Template Main Javascript File -->
  <script src="js/main.js"></script>
  
  <!-- Valida e Verifica Campos E-mail exibindo alerta ao usuário -->
  <script src="js/emailInput.js"></script>
  
  <!-- Valida a entrada de apenas números em campos como telefone -->
  <script src="js/numbersOnly.js"></script>

  <!-- Exibir/Ocultar respostas da Base de Conhecimento -->
  <script src="js/knowledge.js"></script>

  <!-- Aviso da Política de Privacidade  e Termos de Uso -->
  <script src="https://cdn.jsdelivr.net/npm/cookieconsent@3/build/cookieconsent.min.js" data-cfasync="false"></script> <script> window.cookieconsent.initialise({ "palette": { "popup": { "background": "#252e39" }, "button": { "background": "#14a7d0" } }, "content": { "message": "Ao utilizar este site você concorda com a Política de Privacidade e os Termos de Uso para os os sistemas KurupyraTech.", "dismiss": "OK", "link": "Saiba mais", "href": "http://kurupyratech.ddns.net/politica-de-privacidade.php" } }); </script>

  <!-- Go to www.addthis.com/dashboard to customize your tools -->
  <script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5db50c69a845f456"></script>

</body>
</html>