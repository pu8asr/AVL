<?php

/* Início do script que detecta proxy, mostra ip real da conexão e salva em log */

   // By @Kouback_TR_
   // http://twitter.com/kouback_tr_
   
// Variáveis Globais
//$ip = getenv('HTTP_X_REAL_IP');
//$ipreal = getenv('HTTP_X_FORWARDED_FOR');
//$navegador = getenv('HTTP_USER_AGENT');
$ip_visitante = $_SERVER['REMOTE_ADDR'];
$user_agent_visitante = $_SERVER['HTTP_USER_AGENT'];
$remote_host_visitante = $_SERVER['REMOTE_HOST'];
$remote_port_visitante = $_SERVER['REMOTE_PORT'];

date_default_timezone_set('America/Manaus');
$data_sistema = date('d-m-y H:i:s');

$string = <<<EOF
==============================================================================
IP: $ip_visitante
Navegador: $user_agent_visitante
Porta: $remote_port_visitante
Data/Hora: $data_sistema | UTC 04:00 (Hora de Manaus)
==============================================================================
EOF;

$arquivo = fopen("log/log.txt", "a+");
$dados_visitante = fwrite($arquivo, $string);
fclose($arquivo);
/* Fim do script que detecta proxy, mostra ip real da conexão e salva em log */

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
  <title>Economize</title>
  <meta charset="utf-8">
  <meta http-equiv="Content-Language" content="pt-br">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="economize, android, app, preços, compras, produtos, estabelecimentos, economia, pechincha, pesquisa, consulta" name="keywords">
  <meta content="Economize é um app de engenharia social disponível gratuitamente para Android na Google Play. O sistema permite que os usuários possam pesquisar os valores de produtos em estabelecimentos na sua localidade..." name="description">

  <!-- Favicons -->
  <link href="img/favicon.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="lib/ionicons/css/ionicons.min.css" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="css/style.css" rel="stylesheet">

  <!-- =======================================================
    Template Name: Opening
    Template URL: https://templatemag.com/opening-website-under-construction-template/
    Author: TemplateMag.com
    License: https://templatemag.com/license/
  ======================================================= -->
</head>

<body>
  <div id="h">
    <div class="container">
      <div class="row">
        <div class="col-md-8 col-md-offset-2">
          <div class="countdown-header">
            <div class="countdown" data-date="2019/12/01"></div>
          </div>
          <h1>BREVEMENTE <bold>VOCÊ</bold> ECONOMIZARÁ</h1>
        </div>
      </div>
      <!--/row-->
      <div class="row">
        <div class="col-md-4 col-md-offset-4">
          <img src="img/phones.png" class="img-responsive aligncenter" alt="">
        </div>
      </div>
      <!--/row-->
    </div>
    <!--/container-->
  </div>
  <!--/H-->

  <div id="g">
    <div class="container">
      <div class="row">
        <div class="col-md-8 col-md-offset-2 centered">
          <h2>Estamos trabalhando duro para disponibilizar esta poderosa ferramenta de economia para você.</h2>
          <div class="col-md-6 col-md-offset-3">
            <form role="form" action="newsletter.php" method="post" enctype="plain">
              <input type="text" name="email" id="txEmail" class="subscribe-input" value="" placeholder="Informe seu endereço de e-mail..." required>
              <button class='btn btn-conf btn-go' type="submit" name="submit">Avise-me quando estiver pronto</button>
            </form>
          </div>
        </div>
        <!--/col-md-8-->
      </div>
      <!--/row-->
    </div>
    <!--/container-->
  </div>
  <!--/G-->

  <div class="container ptb">
    <div class="row centered">
      <div class="col-md-4">
        <i class="ion-ios7-bolt-outline"></i>
        <h4>INOVADOR</h4>
        <p>Engenharia social para possibilitar que você economize de verdade.</p>
      </div>
      <!--/col-md-4-->
      <div class="col-md-4">
        <i class="ion-ios7-infinite-outline"></i>
        <h4>ILIMITADO</h4>
        <p>Utilize quando quiser, onde quiser e pelo tempo que quiser gratuitamente.</p>
      </div>
      <!--/col-md-4-->
      <div class="col-md-4">
        <i class="ion-ios7-glasses-outline"></i>
        <h4>ECONOMIA</h4>
        <p>O trabalho de pesquisar preços antes e durante as compras é agilizado.</p>
      </div>
      <!--/col-md-4-->
    </div>
    <!--/row-->
  </div>
  <!--/container-->

  <div id="contact">
    <div class="container">
      <div class="row">
        <div class="col-md-8 col-md-offset-2">
          <h2 class="centered">Formulário de contato</h2>
          <form class="contact-form php-mail-form" role="form" action="newsletter.php" method="POST">

            <div class="form-group">
              <input type="name" name="name" class="form-control" id="contact-name" placeholder="Seu nome" data-rule="minlen:4" data-msg="Por favor, insira ao menos 5 caracteres" >
              <div class="validate"></div>
            </div>
            <div class="form-group">
              <input type="email" name="email" class="form-control" id="contact-email" placeholder="Seu endereço de e-mail" data-rule="email" data-msg="Por favor, insira um e-mail válido">
              <div class="validate"></div>
            </div>
            <div class="form-group">
              <input type="text" name="subject" class="form-control" id="contact-subject" placeholder="Assunto da mensagem" data-rule="minlen:4" data-msg="Por favor, insira ao menos 9 caracteres">
              <div class="validate"></div>
            </div>

            <div class="form-group">
              <textarea class="form-control" name="message" id="contact-message" placeholder="Sua mensagem" rows="5" data-rule="required" data-msg="Por favor, escreva algo para nós"></textarea>
              <div class="validate"></div>
            </div>

            <div class="loading"></div>
            <div class="error-message"></div>
            <div class="sent-message">Sua mensagem foi enviada. Agradecemos o contato!</div>

            <div class="form-send">
              <button type="submit" class="btn btn-large">Enviar mensagem</button>
            </div>

          </form>

        </div>
      </div>
    </div>
  </div>
  <!-- / contact -->

  <div id="copyrights">
    <div class="container">
      <p>
        &copy; Copyrights <strong>Economize</strong>. Todos os direitos reservados
      </p>
      <div class="credits">
        <!--
          You are NOT allowed to delete the credit link to TemplateMag with free version.
          You can delete the credit link only if you bought the pro version.
          Buy the pro version with working PHP/AJAX contact form: https://templatemag.com/opening-website-under-construction-template/
          Licensing information: https://templatemag.com/license/
        -->
        Desenvolvido e Hospedado por <a href="http://kurupyratech.ddns.net/">KurupyraTech</a>
      </div>
    </div>
  </div>
  <!-- / copyrights -->

  <!-- JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.min.js"></script>
  <script src="lib/php-mail-form/validate.js"></script>
  <script src="lib/countdown/jquery.plugin.min.js"></script>
  <script src="lib/countdown/jquery.countdown.min.js"></script>

  <!-- Template Main Javascript File -->
  <script src="js/main.js"></script>

</body>
</html>
