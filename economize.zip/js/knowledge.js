// Exibir/Ocultar o conteúdo da DIV na Knowledge
var visibilidade = true;
function ocultarExibir(id){
    if(visibilidade){
		document.getElementById(id).style.display = "none";
		visibilidade = false;
	} else {
		document.getElementById(id).style.display = "block";
		visibilidade = true;
	}
}