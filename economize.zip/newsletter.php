<?php
/* Ativa a exibição de erros na página */
//error_reporting(E_ALL);
//ini_set('display_errors', 1);
/* Ativa a exibição de erros na página */

//$server = "localhost";
//$username = "3ch0n0m1z4r";
//$PW = "HaY23Zh4QBgN8v42";
//$DB = "3ch0n0m1z4r";

include 'app/include/DB_Config.php' //Parâmetros para conexão
include 'app/include/report.php'; //Mensagens de erro

$connection = mysqli_connect('DB_HOST', 'DB_USER', 'DB_PASSWORD', 'DB_DATABASE');

if($connection == false) {
	//die("Erro: " . mysqli_connect_error());
	die('DB_CONNECTION_ERROR');
	//echo"<script language='javascript' type='text/javascript'>alert('Ocorreu um erro na conexão com o servidor. Tente novamente mais tarde!');window.location.href='index.php';</script>";
} else {
	echo "Conectado ao Banco de Dados.</br>";
}

$Email = $_POST["email"];

$sqlSearch = "SELECT * FROM `newsletter` WHERE (`email` = '$Email') LIMIT 1";
if(mysqli_query($connection, $sqlSearch) == false) {
	//die(mysqli_error($connection));
	//die("Não foi possível validar o e-mail informado. Tente novamente mais tarde!);
	die('VALIDATION_DATA_ERROR');
} else {
	$resultSearch = mysqli_query($connection, $sqlSearch);
	if (mysqli_num_rows($resultSearch) != 0) {
		echo "O e-mail já consta na newsletter.</br>";
		echo"<script language='javascript' type='text/javascript'>alert('Seu e-mail já estava cadastrado em nossa newsletter.');window.location.href='index.php';</script>";
	} else {
		$sqlInsert = "INSERT INTO `newsletter` (`id`, `email`) VALUES (NULL, '$Email');";
		
		if(mysqli_query($connection, $sqlInsert) == false) {
			die(mysqli_error($connection));
		} else {
			echo "E-mail adicionado na newsletter.</br>";
			echo"<script language='javascript' type='text/javascript'>alert('Em breve voê receberá nossos informativos.');window.location.href='index.php';</script>";
		}
	}
}







mysqli_close($connection);

?>