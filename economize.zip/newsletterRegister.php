<?php

	//Problemas de acentuação, obedecendo ao padrão UTF-8 de todo o sistema
	header('Content-Type: text/html;  charset=utf-8', true);

	/* Ativa a exibição de erros na página */
	/* Ativar apenas para testes pois pode exibir dados sigilosos que o usuário não pode ter acesso */
	//error_reporting(E_ALL);
	//ini_set('display_errors', 1);
	/* Ativa a exibição de erros na página */

	// Define data e hora da atividade no fuso horário brasileiro
	date_default_timezone_set('America/Sao_Paulo');
	$SystemDateTime = date('Y-m-d H:i:s');
	$ano = date('Y');
	
	// Verifica se houve post (Impedir o acesso direto ao newsletterRegister.php)
	if (!empty($_POST) AND (empty($_POST['email']))) {
		echo"<script language='javascript' type='text/javascript'>alert('Nenhum e-mail foi informado!');window.location.href='index.php';</script>";
	}
	
	// Parâmetro recebido do formulário na página principal
	$Email = utf8_decode($_POST['email']);
	
	// Gera o unique_email_id
	$unique_email_id = substr(base64_encode(sha1($Email)), 0,20);
	
	// Parâmetros de conexão ao banco de dados
	$server = "localhost";
	$username = "3ch0n0m1z4r";
	$PW = "HaY23Zh4QBgN8v42";
	$DB = "3ch0n0m1z4r";

	// Realiza a conexão com o banco de dados
	$connection = mysqli_connect($server, $username, $PW, $DB);
	mysqli_set_charset('UTF8');

	// Verifica se a conexão foi bem-sucedida
	if($connection == false) {
		//die("Erro: " . mysqli_connect_error());
		die("Erro de conexão com o servidor.</br></br>
		Por favor, notifique o suporte!</br>
		Whatsapp: <a href='https://api.whatsapp.com/send?phone=5592994243062&text=Tentei%20cadastrar%20meu%20e-mail%20na%20newsletter%20do%20sistema%20*Economize*%20mas%20o%20servidor%20apresentou%20um%20erro%20de%20conexão%20com%20o%20Banco%20de%20Dados...'>+5592994240362</a></br>
		E-mail: <a href='mailto:economize.suporte@gmail.com?subject=Reportando%20erro%20no%20sistema&body=Tentei%20cadastrar%20meu%20e-mail%20na%20newsletter%20do%20sistema%20Economize%20mas%20o%20servidor%20apresentou%20um%20erro%20de%20conexão%20com%20o%20Banco%20de%20Dados...'>economize.suporte@gmail.com</a></br></br>
		<a href='http://economize.net.br'>Clique aqui para voltar para o site</a>");
		//echo"<script language='javascript' type='text/javascript'>alert('Ocorreu um erro na conexão com o servidor. Tente novamente mais tarde!');window.location.href='index.php';</script>";
	} else {
		echo "Conectado ao Banco de Dados.</br>";
		
		// Validação do e-mail antes de inserir
		$sqlSearch = "SELECT * FROM `newsletter` WHERE (`email` = '$Email') LIMIT 1";
		if(mysqli_query($connection, $sqlSearch) == false) {
			//echo "Não foi possível validar o e-mail informado.</br>";
			die("Não foi possível validar o e-mail informado.</br></br>
			Por favor, notifique o suporte!</br>
			Whatsapp: <a href='https://api.whatsapp.com/send?phone=5592994243062&text=Tentei%20cadastrar%20meu%20e-mail%20na%20newsletter%20do%20sistema%20*Economize*%20mas%20o%20servidor%20não%20conseguiu%20validar%20o%20meu%20e-mail.%20O%20que%20isto%20significa?'>+5592994240362</a></br>
			E-mail: <a href='mailto:economize.suporte@gmail.com?subject=Reportando%20erro%20no%20sistema&body=Tentei%20cadastrar%20meu%20e-mail%20na%20newsletter%20do%20sistema%20Economize%20mas%20o%20servidor%20não%20conseguiu%20validar%20o%20meu%20e-mail.%20O%20que%20isto%20significa?'>economize.suporte@gmail.com</a></br></br>
			<a href='http://economize.net.br'>Clique aqui para voltar para o site</a>");
		} else {
			// Verifica se o e-mail já foi adastrado
			$resultSearch = mysqli_num_rows(mysqli_query($connection, $sqlSearch));
			if($resultSearch != 0) {
				// Já foi cadastrado
				echo "O e-mail já consta na newsletter.</br>";
				
				// Verificações se o cadastro foi validado e envia e-mail de validação caso ainda não tenha sido validado
				$sqlObtainStatus = mysqli_fetch_assoc(mysqli_query($connection, $sqlSearch));
				$code = $sqlObtainStatus['unique_email_id'];
				$actived = $sqlObtainStatus['actived'];

				if($actived == '0') {
					echo "Porém a inscrição ainda não foi validada.</br>";
					
					// Dados para re-envio do e-mail de validação do cadastro
					$Mensagem = '<div><strong>Voc&ecirc; ainda n&atilde;o confirmou sua inscri&ccedil;&atilde;o!<strong></div>
								 <div><h4>Recebemos uma solicita&ccedil;&atilde;o de inscri&ccedil;&atilde;o na Newsletter do sistema <strong><a href="http://economize.net.br/">Economize</a></strong> para o e-mail <strong>'.$Email.'</strong></h4></div>
									 <div>S&oacute; lhe enviaremos comunicados, mediante a sua aprova&ccedil;&atilde;o por meio da valida&ccedil;&atilde;o desta inscri&ccedil;&atilde;o. Esta medida &eacute; necess&aacute;ria para combater o <strong>SPAM</strong> na rede e impedir que terceiros cadastrem seu e-mail sem o seu consentimento.</div>
									 <div>
										<font color="green">
											<h4>Para confirmar sua inscri&ccedil;&atilde;o, <a href="http://economize.net.br/newsletterRegisterConfirm.php?code='.$unique_email_id.'" target="_blank">clique aqui</a></h4>
										</font>
										<font color="red">
											<h4>Se voc&ecirc; n&atilde;o solicitou a inscri&ccedil;&atilde;o do seu e-mail em nossa newsletter, pedimos desculpas pelo incoveniente e por favor, <a href="http://economize.net.br/newsletterRegisterDelete.php?code='.$unique_email_id.'" target="_blank">clique aqui</a> para excluir seu e-mail de nossa lista</h4>
										</font>
									 </div>
									 <div><h5><i>Ao confirmar sua inscri&ccedil;&atilde;o na newsletter, voc&ecirc; aceita a <strong><a href="http://kurupyratech.ddns.net/politica-de-privacidade.php" target="_blank">Política de Privacidade</a></strong> e os <strong><a href="http://kurupyratech.ddns.net/termos-de-uso.php" target="_blank">Termos de Uso</a></strong> para os sistemas <strong><a href="http://kurupyratech.ddns.net/" target="_blank">KurupyraTech</a></strong> &copy;</i></h5></font></div>
									 <div>
										 <strong><h4><a href="http://economize.net.br/" target="_blank">Economize</a> &copy; '.$ano.'</strong></br>
										 <div>Todos os direitos reservados!</div></h4>
									 </div>';
					$MensagemAlt = 'Clique no link a seguir ou copie e cole no navegador para confirmar o recebimento da Newsletter do sistema Economize. http://economize.net.br/newsletterRegisterConfirm.php?code='.$unique_email_id.'. Para cancelar, clique ou cole no navegador o link http://economize.net.br/newsletterRegisterDelete.php?code='.$unique_email_id.' </br></br><strong><a href="http://economize.net.br/">Economize</a></strong> &copy; '.$ano.'</br>Todos os direitos reservados!</br></br>';

					/* Re-envio de e-mail para que o assinante valide a inscrição */
					require ('app/include/PHPMailer/class.phpmailer.php');
					$mail = new PHPMailer();
					//$ToEmail = 'economize.suporte@gmail.com';
					$mail->CharSet = 'UTF-8';
					$mail->From = 'economize.suporte@gmail.com';
					$mail->FromName = 'Economize';
					$mail->IsSMTP();
					$mail->SMTPAuth = true; // turn of SMTP authentication
					$mail->Username = 'economize.suporte@gmail.com'; // SMTP username
					$mail->Password = 'Carpe Diem'; // SMTP password
					$mail->SMTPSecure = 'tls';
					$mail->Host = 'smtp.gmail.com';
					$mail->Port = 587;
					//$mail->SMTPDebug = 2; // Enables SMTP debug information (for testing, remove this line on production mode)
					// 1 = errors and messages
					// 2 = messages only
					$mail->Sender = 'economize.suporte@gmail.com'; // $bounce_email;
					$mail->ConfirmReadingTo = 'economize.suporte@gmail.com';
					$mail->AddReplyTo('economize.suporte@gmail.com');
					$mail->IsHTML(true); //turn on to send html email
					$mail->Subject = 'Newsletter';
					$mail->Body = $Mensagem;
					$mail->AltBody = $MensagemAlt;
					$mail->AddAddress($Email,$Email);
					if($mail->Send()){
						echo "O e-mail para validação da inscrição foi re-enviado!</br>";
						echo"<script language='javascript' type='text/javascript'>alert('Seu e-mail já estava cadastrado, porém ainda não havia sido validado! Confirme sua inscrição clicando no link que re-enviamos para o seu e-mail.');window.location.href='index.php';</script>";
					} else {
						echo "O e-mail para validação da inscrição não pôde ser enviado!</br>";
						echo"<script language='javascript' type='text/javascript'>alert('Detectamos que seu e-mail já estava cadastrado, porém ainda não confirmado. Infelizmente não conseguimos re-enviar um e-mail para confirmar sua inscrição. Pedimos desculpas pelo incoveniente! Por favor tente novamente mais tarde...');window.location.href='index.php';</script>";
					}
					/* Re-envio de e-mail para que o assinante valide a inscrição */
				}

				if($actived == '1') {
					echo "A inscrição já foi validada.</br>";
					echo"<script language='javascript' type='text/javascript'>alert('Sua inscrição já havia sido validada anteriormente. Não se preocupe! Você receberá nossos informativos...');window.location.href='index.php';</script>";
				}
				
			} else {
				// Não foi cadastrado ainda
				$sqlInsert = "INSERT INTO `newsletter` (`id`, `unique_email_id`, `email`, `created_at`) VALUES (NULL, '$unique_email_id', '$Email', '$SystemDateTime')";
				if(mysqli_query($connection, $sqlInsert) == false) {
					die("Não foi possível cadastrar o e-mail informado.</br></br>
					Por favor, notifique o suporte!</br>
					Whatsapp: <a href='https://api.whatsapp.com/send?phone=5592994243062&text=Tentei%20cadastrar%20meu%20e-mail%20na%20newsletter%20do%20sistema%20*Economize*.%20Meu%20e-mail%20foi%20validado%20mas%20o%20sistema%20não%20conseguiu%20adicioná-lo.%20O%20que%20isto%20significa?'>+5592994240362</a></br>
					E-mail: <a href='mailto:economize.suporte@gmail.com?subject=Reportando%20erro%20no%20sistema&body=Tentei%20cadastrar%20meu%20e-mail%20na%20newsletter%20do%20sistema%20*Economize*.%20Meu%20e-mail%20foi%20validado%20mas%20o%20sistema%20não%20conseguiu%20adicioná-lo.%20O%20que%20isto%20significa?'>economize.suporte@gmail.com</a></br></br>
					<a href='http://economize.net.br'>Clique aqui para voltar para o site</a>");
				} else {
					echo "E-mail adicionado na newsletter.</br>";
					
					// Obtém o unique_email_id que foi gravado na tabela e não o gerado no código (para evitar erros)
					$sqlSearchCode = "SELECT * FROM `newsletter` WHERE (`email` = '$Email') LIMIT 1";
					if(mysqli_query($connection, $sqlSearchCode) == false) {
						//echo "Não foi possível validar o e-mail informado.</br>";
						die("Não foi possível obter o código da ação.</br></br>
						Por favor, notifique o suporte!</br>
						Whatsapp: <a href='https://api.whatsapp.com/send?phone=5592994243062&text=Cadastrei%20meu%20e-mail%20na%20newsletter%20do%20sistema%20*Economize*%20mas%20o%20servidor%20não%20conseguiu%20obter%20o%20c&oacute;digo%20para%20enviar%20o%20e-mail%20para%valida&ccedil;&atilde;o%20do%cadastro.%20O%20que%20isto%20significa?'>+5592994240362</a></br>
						E-mail: <a href='mailto:economize.suporte@gmail.com?subject=Reportando%20erro%20no%20sistema&body=Cadastrei%20meu%20e-mail%20na%20newsletter%20do%20sistema%20*Economize*%20mas%20o%20servidor%20não%20conseguiu%20obter%20o%20c&oacute;digo%20para%20enviar%20o%20e-mail%20para%valida&ccedil;&atilde;o%20do%cadastro.%20O%20que%20isto%20significa?'>economize.suporte@gmail.com</a></br></br>
						<a href='http://economize.net.br'>Clique aqui para voltar para o site</a>");
					} else {
						// Obtém o código direto da tabela
						$sqlObtainCode = mysqli_fetch_assoc(mysqli_query($connection, $sqlSearch));
						$code = $sqlObtainCode['unique_email_id'];
						
						// Dados para envio do e-mail de validação do cadastro
						$Mensagem = '<div><h4>Recebemos uma solicita&ccedil;&atilde;o de inscri&ccedil;&atilde;o na Newsletter do sistema <strong><a href="http://economize.net.br/">Economize</a></strong> para o e-mail <strong>'.$Email.'</strong></h4></div>
									 <div>S&oacute; lhe enviaremos comunicados, mediante a sua aprova&ccedil;&atilde;o por meio da valida&ccedil;&atilde;o desta inscri&ccedil;&atilde;o. Esta medida &eacute; necess&aacute;ria para combater o <strong>SPAM</strong> na rede e impedir que terceiros cadastrem seu e-mail sem o seu consentimento.</div>
									 <div>
										<font color="green">
											<h4>Para confirmar sua inscri&ccedil;&atilde;o, <a href="http://economize.net.br/newsletterRegisterConfirm.php?code='.$unique_email_id.'" target="_blank">clique aqui</a></h4>
										</font>
										<font color="red">
											<h4>Se voc&ecirc; n&atilde;o solicitou a inscri&ccedil;&atilde;o do seu e-mail em nossa newsletter, pedimos desculpas pelo incoveniente e por favor, <a href="http://economize.net.br/newsletterRegisterDelete.php?code='.$unique_email_id.'" target="_blank">clique aqui</a> para excluir seu e-mail de nossa lista</h4>
										</font>
									 </div>
									 <div><h5><i>Ao confirmar sua inscri&ccedil;&atilde;o na newsletter, voc&ecirc; aceita a <strong><a href="http://kurupyratech.ddns.net/politica-de-privacidade.php" target="_blank">Política de Privacidade</a></strong> e os <strong><a href="http://kurupyratech.ddns.net/termos-de-uso.php" target="_blank">Termos de Uso</a></strong> para os sistemas <strong><a href="http://kurupyratech.ddns.net/" target="_blank">KurupyraTech</a></strong> &copy;</i></h5></font></div>
									 <div>
										 <strong><h4><a href="http://economize.net.br/" target="_blank">Economize</a> &copy; '.$ano.'</strong></br>
										 <div>Todos os direitos reservados!</div></h4>
									 </div>';
						$MensagemAlt = 'Clique no link a seguir ou copie e cole no navegador para confirmar o recebimento da Newsletter do sistema Economize. http://economize.net.br/newsletterRegisterConfirm.php?code='.$unique_email_id.'. Para cancelar, clique ou cole no navegador o link http://economize.net.br/newsletterRegisterDelete.php?code='.$unique_email_id.' </br></br><strong><a href="http://economize.net.br/">Economize</a></strong> &copy; '.$ano.'</br>Todos os direitos reservados!</br></br>';
	
						/* Envio de e-mail para que o assinante valide a inscrição */
						require ('app/include/PHPMailer/class.phpmailer.php');
						$mail = new PHPMailer();
						//$ToEmail = 'economize.suporte@gmail.com';
						$mail->CharSet = 'UTF-8';
						$mail->From = 'economize.suporte@gmail.com';
						$mail->FromName = 'Economize';
						$mail->IsSMTP();
						$mail->SMTPAuth = true; // turn of SMTP authentication
						$mail->Username = 'economize.suporte@gmail.com'; // SMTP username
						$mail->Password = 'Carpe Diem'; // SMTP password
						$mail->SMTPSecure = 'tls';
						$mail->Host = 'smtp.gmail.com';
						$mail->Port = 587;
						//$mail->SMTPDebug = 2; // Enables SMTP debug information (for testing, remove this line on production mode)
						// 1 = errors and messages
						// 2 = messages only
						$mail->Sender = 'economize.suporte@gmail.com'; // $bounce_email;
						$mail->ConfirmReadingTo = 'economize.suporte@gmail.com';
						$mail->AddReplyTo('economize.suporte@gmail.com');
						$mail->IsHTML(true); //turn on to send html email
						$mail->Subject = 'Newsletter';
						$mail->Body = $Mensagem;
						$mail->AltBody = $MensagemAlt;
						$mail->AddAddress($Email,$Email);
						if($mail->Send()){
							echo "O e-mail para validação da inscrição foi enviado!</br>";
							echo"<script language='javascript' type='text/javascript'>alert('Confirme sua inscrição clicando no link que enviamos para o seu e-mail.');window.location.href='index.php';</script>";
						} else {
							echo "O e-mail para validação da inscrição não pôde ser enviado!</br>";
							echo"<script language='javascript' type='text/javascript'>alert('Seu e-mail foi cadastrado mas não conseguimos lhe enviar um e-mail para confirmar sua inscrição. Pedimos desculpas pelo incoveniente! Por favor tente novamente mais tarde!');window.location.href='index.php';</script>";
						}
						/* Envio de e-mail para que o assinante valide a inscrição */
					}
				}
			}
		}

		// Encerra a conexão com o banco de dados
		mysqli_close($connection);
	}

?>