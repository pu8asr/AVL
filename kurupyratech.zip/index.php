<?php

	//Problemas de acentuação, obedecendo ao padrão UTF-8 de todo o sistema
	//header('Content-Type: text/html;  charset=utf-8', true);

	/* Ativa a exibição de erros na página */
	/* Ativar apenas para testes pois pode exibir dados sigilosos que o usuário não pode ter acesso */
	//error_reporting(E_ALL);
	//ini_set('display_errors', 1);
	/* Ativa a exibição de erros na página */
	
	// Define data e hora da atividade no fuso horário brasileiro
	date_default_timezone_set('America/Manaus');
	$ano = date('Y');
	
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
	<!-- Global site tag (gtag.js) - Google Analytics -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=G-HS8BMTH14R"></script> <script> window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', 'G-HS8BMTH14R'); </script>
	
	<title>KurupyraTech</title>
    <meta charset="utf-8">
	<meta http-equiv="Content-Language" content="pt-BR">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="KurupyraTech é uma abstração criada com o propósito de prover soluções tecnológicas que proporcinem qualidade de vida e bem-estar social...">
    <meta name="author" content="Airam Saile Ripardo Costa - airamcosta@gmail.com">
    <meta name="authorUrl" content="https://www.facebook.com/airam.ripardo">
    
    <!--Fav and touch icons-->
    <link rel="shortcut icon" href="favicon.ico">
    <link rel="icon" href="favicon.ico" type="image/x-icon" />

    <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>

    <!-- Theme CSS -->
    <link href="css/agency.min.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js" integrity="sha384-0s5Pv64cNZJieYFkXYOTId2HMA2Lfb6q2nAcx2n0RTLUnCAoTTsS0nKEO27XyKcY" crossorigin="anonymous"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js" integrity="sha384-ZoaMbDF+4LeFxg6WdScQ9nnR1QC2MIRxA1O9KWEXQwns1G8UNyIEZIQidzb0T1fo" crossorigin="anonymous"></script>
    <![endif]-->

</head>

<body id="page-top" class="index">

    <!-- Navigation -->
    <nav id="mainNav" class="navbar navbar-default navbar-custom navbar-fixed-top">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span> Menu <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand page-scroll" href="#page-top">KurupyraTech</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="hidden">
                        <a href="#page-top"></a>
                    </li>
                    <li>
                        <a class="page-scroll" href="https://play.google.com/store/apps/dev?id=7362431501385880583" target="_blank">Google Play</a>
                    </li>
					<li>
                        <a class="page-scroll" href="#about">Sobre</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#services">Sistemas</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#contact">Contato</a>
					</li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
	
	<!-- Systems Section -->
    <section id="services">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Sistemas</h2>
                    <h3 class="section-subheading text-muted">Conheça nossos sistemas.</h3>
                </div>
            </div>
            <div class="row text-center">
                <div class="col-md-4">
                    <span class="fa-stack fa-4x">
						<a href="http://economize.net.br" target="_blank">
							<i class="fa fa-circle fa-stack-2x text-primary"></i>
							<i class="fa fa-shopping-cart fa-stack-1x fa-inverse"></i>
						</a>
                    </span>
                    <h4 class="service-heading">Economize</h4>
                    <p class="text-muted">Uma rede nacional criada para compartilhar em tempo real as informações sobre preços de produtos, proporcionando economia real(de tempo e de dinheiro) aos usuários.</p>
                </div>
            </div>
        </div>
	</section>
	
	<!-- About Section -->
    <section id="about">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Sobre</h2>
                    <h3 class="section-subheading text-muted">
                    KurupyraTech é uma abstração do folclore brasileiro criado com o obejtivo de desenvolver sistemas gratuítos e/ou de preços acessíveis que proporcionem bem-estar social e melhor qualidade de vida aos usuários.
                    </h3>
					<p>O Curupira é um ser mitológico do folclore brasileiro que defende a fauna e a flora.</p>
					<p>É um ser que tem os pés virados para trás e utiliza isto a seu favor para enganar àqueles que ao verem suas pegadas, acreditam que ele está indo em uma direção, quando na verdade, está indo em outra.</p>
					<p>Assim como as pessoas não acreditam que o Curupira exista, muitos também não acreditam que seja possível oferecer produtos de software gratuitos e/ou com preços acessíveis mantendo a qualidade dos sistemas de valores absurdamente caros.</p>
					<p>Então, como forma de gerar uma conscientização, um brasileiro apaixonado por tecnologia, criou esta abstração do folclore brasileiro para criar sistemas gratuitos ou de baixo custo que contribuam para uma melhor qualidade de vida e bem-estar social, mantendo a qualidade.</p>
					<p>Conheça nossos sistemas. Se você deseja criar um site, hospedar ou registrar um domínio ou até mesmo desenvolver um aplicativo para celular para sua webrádio ou para promover o seu négócio, utilize o formulário abaixo e nos envie sua necessidade. Teremos o maior prazer em lhe atender...</p>
                </div>
            </div>
        </div>
    </section>
	
    <!-- Contact Section -->
    <section id="contact">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Fale Conosco</h2>
                    <h3 class="section-subheading text-muted"><a href="https://chat.whatsapp.com/DZrlB0RnUuR1d4PK5aKHBL" target="_blank">Responderemos o mais breve possível.</a></h3>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <form method="post" action="mail/contact_me.php">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Seu Nome *" maxlength="30" id="name" name="name" required data-validation-required-message="Por favor, informe seu nome.">
                                    <p class="help-block text-danger"></p>
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control" onblur="checarEmail();" onkeyup="minuscula(this)" placeholder="Seu E-mail *" maxlength="50" name="email" id="email" required data-validation-required-message="Por favor informe seu e-mail.">
                                    <p class="help-block text-danger"></p>
                                </div>
                                <div class="form-group">
                                    <input type="tel" class="form-control" onkeypress="return SomenteNumero(event)" placeholder="Seu Whatsapp *" maxlength="11" id="phone" name="phone" required data-validation-required-message="Por favor informe seu número de Whatsapp (incluindo o DDD).">
                                    <p class="help-block text-danger"></p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <textarea class="form-control" placeholder="Sua Menssagem *" maxlength="300" id="message" name="message" required data-validation-required-message="Por favor digite sua mensagem."></textarea>
                                    <p class="help-block text-danger"></p>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-lg-12 text-center">
                                <div id="success"></div>
                                <button type="submit" class="btn btn-xl">Enviar</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <span class="copyright">KurupyraTech &copy; <?php echo $ano; ?></span>
                </div>
                <div class="col-md-4">
                    <ul class="list-inline social-buttons">
                        <!--<li><a href="https://www.facebook.com/airam.ripardo" target="_blank"><i class="fa fa-facebook"></i></a></li>-->
                    </ul>
                </div>
                <div class="col-md-4">
                    <ul class="list-inline quicklinks">
                        <li><a href="politica-de-privacidade.php" target="_self">Política de Privacidade</a></li>
                        <li><a href="termos-de-uso.php" target="_self">Termos de Uso</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>

    <!-- jQuery -->
    <script src="vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js" integrity="sha384-mE6eXfrb8jxl0rzJDBRanYqgBxtJ6Unn4/1F7q4xRRyIw7Vdg9jP4ycT7x1iVsgb" crossorigin="anonymous"></script>

    <!-- Contact Form JavaScript -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>
	<script src="js/emailInput.js"></script>
	<script src="js/numbersOnly.js"></script>

    <!-- Theme JavaScript -->
    <script src="js/agency.min.js"></script>
    
</body>

</html>