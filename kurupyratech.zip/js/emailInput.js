// Email tudo minúsculo
function minuscula(z){
    v = z.value.toLowerCase(); //toUpperCase é Maiúscula
	z.value = v;
	z.value = z.value.replace(/[' ']/g,''); // remove os espaços em branco
}

// Valida E-mail
function verifica() {
  if (document.forms[0].email.value.length == 0) {
    alert('Por favor, informe o seu e-mail.');
	document.frmEnvia.email.focus();
    return false;
  }
  return true;
}
 
function checarEmail(){
if( document.forms[0].email.value=="" 
   || document.forms[0].email.value.indexOf('@')==-1 
     || document.forms[0].email.value.indexOf('.')==-1 )
	{
	   alert( "Se você informou um e-mail inválido, não poderemos lhe responder!" );
	   return false;
	}
}