<?php
 
 
 function sendEmail($FromEmail,$Subject,$Message,$FromName,$ToEmail) {
 
		 require ("class.phpmailer.php");
		 
		 $mail = new PHPMailer();
		 
		 $mail->From     = $FromEmail;
		 $mail->FromName = $FromName;
		 
		 $mail->IsSMTP(); 
		 
		 $mail->SMTPAuth = true;     // turn of SMTP authentication
		 $mail->Username = "airam_costa@yahoo.com.br";  // SMTP username
		 $mail->Password = "Carpe Diem"; // SMTP password
		 $mail->SMTPSecure = "ssl";
		
		 $mail->Host = "smtp.mail.yahoo.com";
		 $mail->Port = 465;
		 
		 $mail->SMTPDebug  = 2; // Enables SMTP debug information (for testing, remove this line on production mode)
		 // 1 = errors and messages
		 // 2 = messages only
		  
		 $mail->Sender   =  $FromEmail;// $bounce_email;
		 $mail->ConfirmReadingTo  = $FromEmail;
		 
		 $mail->AddReplyTo($FromEmail);
		 $mail->IsHTML(true); //turn on to send html email
		 $mail->Subject = $Subject;
		
		 $mail->Body     =  $Message;
		 $mail->AltBody  =  "ALTERNATIVE MESSAGE FOR TEXT WEB BROWSER LIKE SQUIRRELMAIL";
		 
		 $mail->AddAddress($ToEmail,$ToEmail);
			   
		 if($mail->Send()){
		  $mail->ClearAddresses();  
		 }
 
 }

 
 $FromEmail	=	'airam_costa@yahoo.com.br';
 $Subject	=	'Alerta Boleto Fistel - http://pu8asr.ddns.net:1080/boleto-fistel';
 $Message	=	'Teste de envio de email com PHPMailer do WebServer Raspberry';
 $FromName	=	'Boleto Fistel';
 $ToEmail	=	'airamcosta@gmail.com';
 
 $response  = sendEmail($FromEmail,$Subject,$Message,$FromName,$ToEmail);
 
 print_r($response);
 
 
 
?>  
