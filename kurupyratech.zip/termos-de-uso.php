<!DOCTYPE html>
<html lang="pt-br">

<head>
	<!-- Global site tag (gtag.js) - Google Analytics -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=G-HS8BMTH14R"></script> <script> window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', 'G-HS8BMTH14R'); </script>

	<title>KurupyraTech - Termos de Uso</title>
    <meta charset="utf-8">
	<meta http-equiv="Content-Language" content="pt-br">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Conheça os termos de uso dos sistemas KurupyraTech">
    <meta name="author" content="Airam Saile Ripardo Costa - airamcosta@gmail.com">
    <meta name="authorUrl" content="https://www.facebook.com/airam.ripardo">
    
    <!--Fav and touch icons-->
    <link rel="shortcut icon" href="favicon.ico">
    <link rel="icon" href="favicon.ico" type="image/x-icon" />

    <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>

    <!-- Theme CSS -->
    <link href="css/agency.min.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js" integrity="sha384-0s5Pv64cNZJieYFkXYOTId2HMA2Lfb6q2nAcx2n0RTLUnCAoTTsS0nKEO27XyKcY" crossorigin="anonymous"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js" integrity="sha384-ZoaMbDF+4LeFxg6WdScQ9nnR1QC2MIRxA1O9KWEXQwns1G8UNyIEZIQidzb0T1fo" crossorigin="anonymous"></script>
    <![endif]-->

</head>
  <body>
  
  <section id="services">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
					<h2 class="section-heading">Termos de Uso</h2>
                    <h3 class="section-subheading text-muted">Termos de uso aceitável dos sistemas <a href='http://kurupyratech.ddns.net' target='_self'>KurupyraTech</a></h3>
					<p><i>O Curupira é um ser mitológico que defende a fauna e flora da floresta e que tem seus pés virados para trás. Quando uma pessoa vê as pegadas do mesmo na floresta, imagina que ele está indo, quando na verdade está vindo.</i></p>
					<p>A KurupyraTech é uma abstração utilizada por <strong>Airam Saile Ripardo Costa</strong> (profissional da tecnologia da informação) para criar soluções tecnológicas acessíveis, que proporcinem qualidade de vida e bem-estar social, assim, enquanto pode-se pensar que estamos indo, na verdade já estamos voltando...</p>
					<p>As opiniões e informações enviadas pelos internautas, não refletem a opinião da KurupyraTech ou de seu idealizador, que se isenta de qualquer responsabilidade sobre as sugestões enviadas por seus usuários e parceiros.</p>
					<p>As informações aqui contidas são meramente informativas.</p>
					<p>As informações deste website podem conter imprecisões ou erros de digitação, contudo ressalta-se o compromisso com a qualidade de todos os serviços prestados.</p>
					<p>As informações podem ser alteradas ou atualizadas a qualquer tempo, sem qualquer aviso. Fica portanto, o usuário incumbido da responsabilidade de consultar regularmente a <strong>Política de Privacidade</strong> bem como os <strong>Termos de Uso</strong> para os sistemas KurupyraTech.</p>
					<p><strong>Se você não concordar com estes termos ou com a <a href="politica-de-privacidade.php" target="_self">Política de Privacidade</a>, por favor não utilize os sistemas KurupyraTech.</strong></p>
					</br></br></br>
					
					<h3 class="section-subheading text-muted">Exclusão de Garantias e Responsabilidade</a></h3>
					<p>Por razões técnicas e de operação, não é possível garantir a disponibilidade e continuidade de nossos serviços/sistemas, bem como evitar possíveis falhas.</p>
					<p>Todos os serviços oferecidos pelo de nossos sistemas, são disponibilizados no estado em que se encontram.</p>
					<p>Os usuários ficam desde já advertidos a procederem com sua própria diligência ao utilizar nossos sistemas/serviços.</p>
					<p>Eximimo-nos e nos exoneramos, em toda a extensão permitida pelo ordenamento jurídico brasileiro e qualquer outro aplicável, de qualquer responsabilidade pelos danos de qualquer natureza, lucros cessantes e danos emergentes, que possam ser ocasionados ou decorrer da falta de continuidade ou funcionamento de serviços/sistemas.</p>
					<p>Disponibilizamos em nossos sistemas, meios de contato pelo qual poderão ser denunciados abusos e violações de direitos. Uma vez que os abusos forem comprovados e atendam ao requisito do <strong>fumus boni iurus</strong>, procederemos a retirada desses conteúdos.</p>
					</br></br></br>
					
					<h3 class="section-subheading text-muted">Da cópia ou reprodução</a></h3>
					<p>Não permitimos cópia ou reprodução de nossos sistemas, mesmo que parcialmente.</p>
					<p>
						<lu>
							<li>a) É vedado ao USUÁRIO modificar, copiar, distribuir, transmitir, exibir, realizar, reproduzir, publicar, disponibilizar, licenciar ou criar obras derivadas a partir das informações coletadas nos sistemas KurupyraTech, bem como transferir ou vender tais informações, software, produtos ou serviços, sob pena de violação do presente termo e infração legal (Vide <a href='http://www.planalto.gov.br/ccivil_03/leis/l9609.htm' target='_blank'>Lei de Software</a> e <a href='http://www.planalto.gov.br/ccivil_03/leis/l9279.htm' target='_blank'>Lei de Propriedade Industrial</a>).</li>
							<li>c) divulgar conteúdo ou arquivos sem autorização;</li>
							<li>d) liberar acesso a terceiros de forma ilícita e/ou não autorizada.</li>
						</lu>
					</p>
					</br></br></br>
					
					<h3 class="section-subheading text-muted">Links externos</a></h3>
					<p>Permitimos a divulgação de links para acesso aos nossos sistemas em outros sistemas.</p>
					<p>Esses links podem consistir em banners (propagandas, publicidade etc.), botões, diretórios e ferramentas de busca que permitem aos usuários terem acesso aos nossos sistemas.</p>
					<p>Os resultados e utilização dessas ferramentas são de responsabilidade direta de seus criadores.</p>
					<p>Não controlamos os resultados dessas ferramentas, que podem direcionar o usuário a páginas com conteúdos ilícitos ou contrários à moral e aos bons costumes.</p>
					<p>Não comercializamos produtos ou serviços de terceiros.</p>
					<p>Nos eximimos e exoneramo-nos, em toda a extensão permitida pelo ordenamento jurídico brasileiro e qualquer outro aplicável, de qualquer responsabilidade pelos danos de qualquer natureza, lucros cessantes e danos emergentes, que possam ser ocasionados ou decorrer de:</p>
					<p>
						<ul>
							<li>(A) do funcionamento, disponibilidade, acessibilidade ou continuidade de páginas externas ao seu domínio;</li>
							<li>(B) da manutenção dos serviços, informação, dados, arquivos, produtos e qualquer tipo de material existente nas páginas externas;</li>
							<li>(C) da prestação ou transmissão dos serviços, informação, dados, arquivos, produtos e qualquer tipo de material existente nos sites linkados;</li>
							<li>(D) da qualidade, legalidade, confiabilidade e utilidade dos serviços, informação, dados, arquivos, produtos e qualquer tipo de material existete em páginas externas, dicas ou qualquer outro conteúdo fora de nossos sistemas.</li>
						</ul>
					</p>
					</br></br></br>
					
					<h3 class="section-subheading text-muted">Usuários</a></h3>
					<p>Nos esforçamos para controlar o acesso e a utilização que os usuários fazem dos conteúdos disponibilizados por meio de nossos sistemas e reservamo-nos o direito de suspender, bloquear ou excluir qualquer usuário identificado ou com suspeita de ação ilícita que atente contra a boa-fé, que empregue engenharia reversa em nossos sistemas, enfim, que dê qualquer destinação diferente daquela para qual o sistema foi criado/desenvolvido.</p>
					<p>Não garantimos que os usuários estejam em conformidade com a lei, com o presente Termos de Uso ou com quaisquer outros instrumentos normativos aplicáveis, ou da moral e dos bons costumes geralmente aceitos pela ordem pública.</p>
					<p>Não verificamos e não possuímos qualquer obrigação de verificar a identidade dos usuários nem a veracidade, completude, autenticidade dos dados que os usuários fornecem sobre si em qualquer circunstância.</p>
					<p>Somente forneceremos quaisquer destes dados mediante ordem judicial legalmente válida.</p>
					<p>Dessa forma nos eximimos e nos exoneramos, em toda a extensão permitida pelo ordenamento jurídico brasileiro e qualquer outro aplicável, de qualquer responsabilidade e por quaisquer danos e prejuízos de qualquer natureza que possam surgir devido à utilização indevida da personalidade de terceiros efetuada por um usuário em qualquer classe ou situação dentro dos sistemas KurupyraTech.</p>
					</br></br></br>
					
					<h3 class="section-subheading text-muted">Lei e Foro aplicáveis</a></h3>
					<p>Estes Termos de Uso são regidos pelas leis brasileiras.</p>
					<p>KurupyraTech consiste em um serviço de interesse privado, que pode gerar uma relação de consumo regida pelo <a href='http://www.planalto.gov.br/ccivil_03/leis/l8078.htm' target='_blank'>Código de Defesa do Consumidor</a>.</p>
					<p>Qualquer ação judicial envolvendo KurupyraTech deverá ser proposta obrigatoriamente no foro da cidade de Manaus - Amazonas, com exclusão de qualquer outro, por mais privilegiado que seja.</p>
					</br></br></br>
					
				</div>
			</div>
		</div>
	</section>

  </body>
</html>