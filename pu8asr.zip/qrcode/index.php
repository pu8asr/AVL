<!-- http://www.thiengo.com.br -->
<!-- Por: Vin�cius Thiengo -->
<!-- Em: 19/12/2013 -->
<!-- Vers�o: 1.0 -->
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="pt-br" xml:lang="pt-br">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="Gerador de QRCode. Crie seus pr�prios QRCode facilmente... http://pu8asr.ddns.net">
		<meta name="author" content="Airam Saile Ripardo Costa - airamcosta@gmail.com">
		<meta name="authorUrl" content="http://pu8asr.ddns.net">
		<link rel="icon" href="assets/img/favicon.ico">
		
		<!-- Page-levels do Google Adsense -->
    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({
          google_ad_client: "ca-pub-2373559965014283",
          enable_page_level_ads: true
     });
</script>
    <!-- Fim do Page-levels do Google Adsense -->
	
		<title>Gerador de QrCode</title>
	</head>
	
	
	
	<body>
		<h1>"Uma imagem vale mais que mil palavras (literalmente)..."</h1>
		
		<form>
			<fieldset>
				<input type="text" id="texto" placeholder="Texto" />
				<select id="nivel">
					<option value="L">Nivel redundancia L</option>
					<option value="M">Nivel redundancia M</option>
					<option value="Q">Nivel redundancia Q</option>
					<option value="H">Nivel redundancia H</option>
				</select>
				<select id="pixels">
					<option value="4">quadradinho de 4px</option>
					<option value="8">quadradinho de 8px</option>
					<option value="10">quadradinho de 10px</option>
					<option value="16">quadradinho de 16px</option>
				</select>
				<label>
					<input type="radio" name="img" value="J" />
					JPEG
				</label>
				<label>
					<input type="radio" name="img" value="P" checked="checked" />
					PNG
				</label>
				<!--<br />-->
				<button type="button" id="botao">Gerar QRCode</button>
			</fieldset>
		</form>
		
		<?php
			$aux = 'qr_img0.50j/php/qr_img.php?';
			$aux .= 'd=https://api.whatsapp.com/send?phone=559294243062&text=Airam,%20estou%20gerando%20QRCode%20no%20seu%20site.&';
			$aux .= 'e=H&';
			$aux .= 's=10&';
			$aux .= 't=J';
		?>
		<div style="float: left; border: 1px solid #000;">
			<img src="<?php echo $aux; ?>" />
		</div>
		
		<script type="text/javascript" src="http://code.jquery.com/jquery-1.10.2.min.js"></script>
		<script type="text/javascript">
			$('#botao').click(function(e){
				e.preventDefault();
				var texto = $('#texto').val();
				var nivel = $('#nivel').val();
				var pixels = $('#pixels').val();
				var tipo = $('input[name="img"]:checked').val();
				
				if(texto.length == 0){
					alert('Informe um texto');
					return(false);
				}
				//alert('qr_img0.50j/php/qr_img.php?d='+texto+'&e='+nivel+'&s='+pixels+'&t='+tipo);
				alert('QRCode gerado com sucesso!'); // Substitui o texto acima
				$('img').attr('src', 'qr_img0.50j/php/qr_img.php?d='+texto+'&e='+nivel+'&s='+pixels+'&t='+tipo);
			});
		</script>
		</br></br>
		<p>&nbsp;&nbsp;Informe o conte&uacute;do no campo texto</p>
		<p>&nbsp;&nbsp;Escolha as op&ccedil;&otilde;es de personaliza&ccedil;&atilde;o</p>
		<p>&nbsp;&nbsp;Clique no bot&atilde;o "Gerar QRCode"</p>
		<p>&nbsp;&nbsp;Clique com o bot&atilde;o auxiliar do mouse sobre a imagem</p>
		<p>&nbsp;&nbsp;Escolha a op&ccedil;&atilde;o "Salvar imagem como..."</p>
		</br></br>
		<!--<p>&nbsp;&nbsp;Escaneie o QRCode para entrar em contato comigo pelo Whatsapp.</p>-->
		<p>&nbsp;&nbsp;<a href="https://play.google.com/store/apps/details?id=com.google.zxing.client.android" target="_blank">Baixe o BarCode Scanner para Android e descubra o conte&uacute;do da imagem</a></p>
	</body>
</html>