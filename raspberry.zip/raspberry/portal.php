<?php

header("Content-Type: text/html;  charset=UFT-8", true);

include "../boleto-fistel/conexaodb.php";

// Tabela de configuações do sistema
$query_configuracoes = mysql_query("SELECT * FROM configuracoes");
$escreve_configuracao=mysql_fetch_array($query_configuracoes);
$valor = $escreve_configuracao['valor'];

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Este é um site hospedado num Raspberry Pi B+ onde funciona um link do Echolink. http://pu8asr.ddns.net">
    <meta name="author" content="Airam Saile Ripardo Costa - airamcosta@gmail.com">
    <meta name="authorUrl" content="http://pu8asr.ddns.net">
    <link rel="icon" href="assets/img/favicon.ico">
	
	<!-- Page-levels do Google Adsense -->
    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({
          google_ad_client: "ca-pub-2373559965014283",
          enable_page_level_ads: true
     });
</script>
    <!-- Fim do Page-levels do Google Adsense -->

    <title>Raspberry WebServer</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="assets/css/ionicons.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">


    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="assets/js/ie10-viewport-bug-workaround.js"></script>

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	
  </head>

  <body>
    <?php include_once("analyticstracking.php") ?>

    <!-- ChatBot em http://rebot.me -->
    	        <script type="text/javascript">
		var headID = document.getElementsByTagName("head")[0];
		var newCss = document.createElement('link');
		newCss.rel = 'stylesheet';
		newCss.type = 'text/css';
		window._botUsername = '613264';
		window._botName = 'Posso ajudar?';
		newCss.href = "http://rebot.me/assets/css/bot.css";
		var newScript = document.createElement('script');
		newScript.src = "http://rebot.me/assets/js/bot.js";
		newScript.type = 'text/javascript';
		headID.appendChild(newScript);
		headID.appendChild(newCss);
		</script>
    <!-- Fim do ChatBot -->

    <div id="h">
      <div class="logo">PU8ASR.DDNS.NET</div>
      <div class="social hidden-xs">
	<!-- Inicio Visitantes OnLine -->
	<script>var _uox = _uox || {};(function() {var s=document.createElement("script");
s.src="http://static.usuarios-online.com/uo2.min.js";document.getElementsByTagName("head")[0].appendChild(s);})();</script>
<a href="http://www.usuarios-online.com/pt/" data-id="46f236dd90b736cc2c406adbc710e8d2" data-type="default" target="_blank" id="uox_link">visitantes online</a>
	<!-- Fim Visitantes OnLine -->

        <a href="https://twitter.com/@airamcosta" target="_blank"><i class="ion-social-twitter"></i></a>
        <a href="https://www.instagram.com/airamripardo/" target="_blank"><i class="ion-social-instagram"></i></a>
        <a href="https://www.facebook.com/airam.ripardo" target="_blank"><i class="ion-social-facebook"></i></a>
      </div>
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-md-offset-2 centered">
            <h1>WebServer Raspberry Pi B+<br/><br/>Linux Raspbian, Apache, PHP, MySQL, SVXLINK (Echolink para Linux)</h1>
            <!--<h3>Abaixo estão alguns sites nos quais estou trabalhando...</h3>-->
            <div class="mtb">
              <form role="form" action="register.php" method="post" enctype="plain"> 
                <!--<input type="email" name="email" class="subscribe-input" placeholder="Enter your e-mail address..." required>-->
                <!--<button class='btn btn-conf btn-green' type="submit">Gás Liquefeito de Petróleo - GLP-JIT</button>
                <button class='btn btn-conf btn-green' type="submit">JS Serviços Diversos</button></br></br>
                <button class='btn btn-conf btn-green' type="submit">Receptor FlightFeeder ADS-B com MLAT da FlightAware</button>
                <button class='btn btn-conf btn-green' type="submit">Receptor MarineTraffic</button>
              </form>-->
            </div><!--/mt-->
            <!--<h6>Este equipamento conta ainda com suporte a PHP, Banco de dados MySQL, Estação do Echolink PU8ASRL utilizando SVXLINK.<br>Todo este sistema está funcionando sob a plataforma Raspberry Pi B+ com o sistema operacional Raspbian Wheezy.</h6>-->
          </div>
        </div><!--/row-->
      </div><!--/container-->
    </div><!-- /H -->

    <!-- Código da WebRadio Radioamador em Shoutcast.com -->
    <!--    <embed src="https://flashplayer.estadovirtual.com.br/shoutcast/player.swf"  width="400" height="30" align="" quality=high  bgcolor=#FFFFFF type="application/x-shockwave-flash" pluginspage="https://www.adobe.com/go/getflashplayer_br" flashvars="radiourl=http://listen.shoutcast.com/radioamador&radio=Radioamador "></embed> -->
    <!-- Fim do Códifo da WebRadio -->

    <!-- Início do Código do Google Translate -->
	<div align="right" id="google_translate_element"></div><script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'pt', layout: google.translate.TranslateElement.FloatPosition.TOP_LEFT, gaTrack: true, gaId: 'UA-101144970-1'}, 'google_translate_element');
}
</script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
                        
    <!-- Fim do Código do Google Translate -->

    <div class="container ptb">
      <div class="row">
        <div class="col-md-6">
          <h2>Simulado para exame de radioamador</h2>
          <p class="mt">Um preparatório gratuito com normas, resoluções e testes para você que pretente prestar exame para obtenção do COER.</p>
          <p class="store">
            <!--<a href="#"><img src="assets/img/app-store.png" height="50" alt=""></a>-->
            <a href="https://play.google.com/store/apps/details?id=com.SimuladoRadioamador" target="_blank"><img src="assets/img/google-play.png" height="50" alt=""></a>
          </p>
        </div>
        <div class="col-md-6">
          <img src="assets/img/phone.png" class="img-responsive mt" alt="">
        </div>
      </div><!--/row-->
    </div><!--/container-->

    <div id="sep">
      <div class="container">
        <div class="row centered">
          <div class="col-md-8 col-md-offset-2">
            <h1>Botelo Fistel</h1>
            <h4>Todos os anos, de Janeiro a Março, radioamadores, operadores da faixa do cidadão, emissoras de radio-difusão e TV (amadoras ou não), bem como todos aqueles que exploram o serviço de rádiocomunicação ou radio-difusão tem que pagar as taxas popularmente conhecidas como Fistel. A Anatel, agência subordinada ao Ministério da Comunicações, responsável pela emissão dos boletos, não envia mais os mesmos pelo correio, então resta ao contribuinte retirá-lo pela internet, mas muitos encontram dificuldades. Sabia que você pode receber seus boletos no seu e-mail?!</h4>
            <!--<p><button class="btn btn-conf-2 btn-green">Saiba mais</button></p>-->
          </div><!--/col-md-8-->
        </div>
      </div>
    </div><!--/sep-->

    <div class="container ptb">
      <div class="row centered">
        <h2 class="mb">Mais informações sobre o Fistel<br/>(outras formas de conseguir seus boletos)</h2>
        <div class="col-md-4">
          <div class="price-table">
              <div class="p-head">
                <p><strong><a href="https://conferenciamanaus.wordpress.com/2014/06/25/anatel-fistel-descobrindo-meu-numero/" target="_blank">Número do Fistel</a></strong></p>
              </div>
              <div class="p-body">
                <ul class="features">
                  <li></br>Cada indicativo está vinculado a um número de inscrição no Fistel. Um CPF ou CNPJ pode possuir mais de um número de Fistel. Você precisará do seu número de Fistel para obter seus boletos.</br></br></li>
                </ul>
                <div class="price">
                  <span class="sub">R$</span>
                  <span class="detail">0,00</span>
                  <span class="sub">/mês.</span>
                </div><!--/price-->
                <!--<button class="btn btn-conf-2 btn-green">Saiba mais</button>-->
              </div><!--/p-body-->
          </div><!--/price-table-->
        </div><!--/col-md-4-->

         <div class="col-md-4">
          <div class="price-table">
              <div class="p-head">
                <p><strong><a href="https://conferenciamanaus.wordpress.com/2012/01/11/anatel-fistel-imprima-o-boleto-sem-ter-senha-de-acesso/" target="_blank">Boleto Online</a></strong></p>
              </div>
              <div class="p-body">
                <ul class="features">
                  <li></br>Você pode imprimir seus boletos diretamente no site da Anatel gratuitamente. Não é necessário senha para fazer isso. Basta informar o número do Fistel e seu CPF.</br></br></br></li>
                </ul>
                <div class="price">
                  <span class="sub">R$</span>
                  <span class="detail">0,00</span>
                  <span class="sub">/mês</span>
                </div><!--/price-->
                <!--<button class="btn btn-conf-2 btn-green">Saiba mais</button>-->
              </div><!--/p-body-->
          </div><!--/price-table-->
        </div><!--/col-md-4-->

         <div class="col-md-4">
          <div class="price-table">
              <div class="p-head">
                <p><strong><a href="https://conferenciamanaus.wordpress.com/2017/03/13/anatel-fistel-receba-o-boleto-no-seu-e-mail/" target="_blank">Boleto no seu E-mail</a></strong></p>
              </div>
              <div class="p-body">
                <ul class="features">
                  <li>Algumas pessoas por dificuldades técnicas ou outros motivos quaisquer, não conseguem imprimir os boletos. Então, enviamos os boletos diretamente para o seu e-mail e você paga apenas um valor por CPF ou CNPJ, independente da quantidade de indicativos, estações ou anos que possam estar em atraso.</li>
                </ul>
                <div class="price">
                  <span class="sub">R$</span>
                  <span class="detail"><?php echo $valor?></span>
                  <span class="sub">/CPF ou CNPJ</span>
                </div><!--/price-->
                <!--<button class="btn btn-conf-2 btn-green">Saiba mais</button>-->
              </div><!--/p-body-->
          </div><!--/price-table-->
        </div><!--/col-md-4-->
      </div><!--/row-->
    </div><!--/container-->

    <div id="g">
      <div class="container">
        <div class="row sponsor centered">
          <div class="col-sm-2 col-sm-offset-1">
            <img src="assets/img/client1.png" alt="">
          </div>
          <div class="col-sm-2">
            <img src="assets/img/client3.png" alt="">
          </div>
          <div class="col-sm-2">
            <img src="assets/img/client2.png" alt="">
          </div>
          <div class="col-sm-2">
            <img src="assets/img/client4.png" alt="">
          </div>
          <div class="col-sm-2">
            <img src="assets/img/client5.png" alt="">
          </div>
        </div><!--/row-->
      </div>
    </div><!--/g-->

    <div class="container ptb">
      <div class="row">
        <div class="col-md-6">
          <iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/videoseries?list=PLXMJj8G516Xpd8fiygQuFu_KMF8SIjgKy" frameborder="0" allowfullscreen></iframe>
        </div>
        <div class="col-md-6">
          <h2>Echolink no Raspberry - Curso Completo</h2>
          <p class="mt">Um curso completo para você que deseja economizar espaço, energia elétrica e de banda de internet.</p>
          <p><a href="https://goo.gl/VrwSgX" target="_blank">Baixe o instalador fácil(Português do Brasil) - outros idiomas na descrição do vídeo</a></p>
          <p><a href="https://goo.gl/qy85x3" target="_blank">Increva-se no canal no YouTube</a></p>
          <p><a href="https://goo.gl/ZHkPSw" target="_blank">Participe do grupo "Echolink no Raspberry" no Whatsapp</a></p>
		  <p><a href="https://www.magazinevoce.com.br/magazineairamripardo/" target="_blank">Compre seu Raspberry e acessórios na minha loja</a></p>
        </div>       
      </div><!--/row-->
    </div><!--/container-->
	
	<div class="container ptb">
      <div class="row">
        <div class="col-md-6">
          <h2>Banda Larga de Radioamador</h2>
          <p class="mt">É possivel a criação de uma rede de banda larga de altíssima velocidade que pode ser utilizada em situações de emergência, busca e salvamento, dentre outros... e, pode ser operado/mantido por operadores de todas as classes segundo legislação vigente, pois opera nas faixas superiores da banda de 13cm (2.4Ghz) as quais radioamadores já possuem autorização para explorar.</p>
          <p><a href="https://goo.gl/qy85x3" target="_blank">Increva-se no canal no YouTube</a></p>
		  <p><a href="../mesh" target="_blank">Leia mais</a></p>
        </div>
        <div class="col-md-6">
          <iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?list=PLXMJj8G516Xodeb3kMl5jy-5Yf4U-H579" frameborder="0" allowfullscreen></iframe>
        </div>
      </div><!--/row-->
    </div><!--/container-->

    <div class="container ptb">
      <div class="row">
        <div class="col-md-6">
	  <iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/P_pEAeW_zbc" frameborder="0" allowfullscreen></iframe>
        </div>
        <div class="col-md-6">
          <h2>Professor Morse</h2>
          <p class="mt">Um curso completo para você que deseja aprender o Código Morse exigido para obtenção do COER classe B.</br>Estude sozinho em casa ou transmita via rádio para os seus amigos.</p>
          <p><a href="https://conferenciamanaus.wordpress.com/2014/06/18/clube-do-cw-professor-morse/" target="_blank">Veja mais na Conferência Manaus</a></p>
          <p><a href="https://goo.gl/qy85x3" target="_blank">Increva-se no canal no YouTube</a></p>
          <p><a href="../download/ProfessorMorse_VersaoAvaliacao_1_0.zip" target="_blank">Baixe o programa completo para Windows</a></p>
        </div>       
      </div><!--/row-->
    </div><!--/container-->

    <div id="green">
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-md-offset-3 centered">
            <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
              <!-- Wrapper for slides -->
              <div class="carousel-inner">
                <div class="item active">
                  <h3>A Conferência Amazônica é um projeto para interligar os estados que compõem a Amazônia Brasileira por meio do uso da Tecnologia VoIP (voz sobre IP) como suporte às comunicações por rádio-frequência.</h3>
                  <h5><tgr>http://conferenciaamazonica.wordpress.com</tgr></h5>
                </div>
                <div class="item">
                  <h3>A Conferência Manaus é fruto do esforço de radioamadores em manter ativas as frequências principalmente em VHF na cidade de Manaus, capital do estado do Amazonas. A evolução desse projeto resultou na Conferência Amazônica.</h3>
                  <h5><tgr>http://conferenciamanaus.wordpress.com</tgr></h5>
                </div>
                <div class="item">
                  <h3>Meu canal no Youtube é apenas uma parte da minha história. Lá gosto de compartilhar idéias...</h3>
                  <h5><tgr>http://goo.gl/qy85x3</tgr></h5>
                </div>
                <div class="item">
                  <h3>Criei um fórum com o objetivo de ser tornar no maior ponto de encontro de informações na lingua portuguesa sobre antenas, transceptores, raspberry, arduino, eletrônica...</h3>
                  <h5><tgr>http://radioamador.forumeiros.com/</tgr></h5>
                </div>
                <div class="item">
                  <h3>Um grupo no Whatsapp voltado exclusivamente para troca de idéias e informações sobre Echolink no Raspberry</h3>
                  <h5><tgr>http://goo.gl/lXUf40</tgr></h5>
                </div>
              </div>
            </div><!--/Carousel-->

          </div>
        </div><!--/row-->
      </div><!--/container-->
    </div><!--/green-->

    <!-- Twitter Feeds -->
    <div class="container ptb">
      <div class="row">
        <div class="col-md-6">
	  <a class="twitter-timeline" href="https://twitter.com/airamcosta" data-height="500">Tweets by airamcosta</a> <script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
        </div>
        <div class="col-md-6">
	  <h2>Sobre este WebServer</h2>
	  <h3>Pi: Tecnologia barata, acessível e funcional</h3>
          <p class="mt">Este WebServer é um servidor pessoal e de produção utilizado no desenvolvimento de algumas tecnologias e sites dos quais alguns estão disponíveis para seu acesso.</p>
          <p><a href="../voip/" target="_blank">PABX VOIP com Asterisk no Raspberry Pi</a></p>
          <p><a href="../boleto-fistel/" target="_blank">Boleto Fistel - Despacho de Boletos do Fistel</a></p>
		  <p><a href="../qi/" target="_blank">Teste seu coeficiente de inteligência</a></p>
		  <p><a href="https://pt.flightaware.com/adsb/stats/user/AiramCosta" target="_blank">Receptor Aeronático FlightAware com Raspberry</a></p>
		  <p><a href="https://www.marinetraffic.com/en/ais/details/stations/2957/_:9b1efe3da512ee1258de4a33dbe30a42" target="_blank">Receptor Marítimo MarineTraffic com Raspberry</a></p>
        </div>       
      </div><!--/row-->
    </div><!--/container-->
    <!-- Twitter Feeds -->
	
	<!-- Teste de QI de Einstein -->
    <div class="container ptb">
      <div class="row centered">
        <iframe src="../qi/" width="100%" height="700" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" name="qi"></iframe>
      </div><!--/row-->
    </div><!--/container-->
    <!-- Teste de QI de Einstein -->
	
	<!-- Gerador de QRCode -->
    <div class="container ptb">
      <div class="row centered">
        <h2 class="mb">Gerador de QRCode</h2>
        <iframe src="../qrcode/" width="100%" height="700" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" name="qrcode"></iframe>
      </div><!--/row-->
    </div><!--/container-->
    <!-- Gerador de QRCode -->

    <div id="f">
      <div class="container">
        <div class="row centered">
          <h2>Fale comigo</h2>
          <h5><a href="mailto:airamcosta@gmail.com" target="_blank">airamcosta@gmail.com</a> | Whatsapp: (92) 99424-3062 | Telegram (92) 98202-0298</br>Skype: airamcosta | Zello: Airam - PU8ASR | <a href="http://zello.me/k/Coo9" target="_blank">Conferência Amazônica no Zello</a> | <a href="http://zello.me/k/Codk" target="_blank">Conferência Manaus no Zello</a></br></br>Rua Lírio-Branco, nº 8, Quadra A4 - Conjunto Parque das Garças, Novo Aleixo - CEP: 69098-352</br>Manaus - Amazonas - Brasil</h5>

          <p class="mt">
            <a href="https://twitter.com/@airamcosta" target="_blank"><i class="ion-social-twitter"></i></a>
            <!--<a href="#"><i class="ion-social-dribbble"></i></a>-->
            <a href="https://www.instagram.com/airamripardo/" target="_blank"><i class="ion-social-instagram"></i></a>
            <a href="https://www.facebook.com/airam.ripardo" target="_blank"><i class="ion-social-facebook"></i></a>
            <!--<a href="#"><i class="ion-social-pinterest"></i></a>-->
            <!--<a href="#"><i class="ion-social-tumblr"></i></a>-->
          </p>
          <h6 class="mt">COPYRIGHT 2017 - PU8ASR.DDNS.NET</h6>
        </div><!--/row-->
      </div><!--/container-->
    </div><!--/F-->

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/retina-1.1.0.js"></script>
    
    <!-- Go to www.addthis.com/dashboard to customize your tools -->
    <script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5940d46ab5e45214"></script>
  </body>
</html>
